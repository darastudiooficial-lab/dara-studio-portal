import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Download, FileText, PenTool, FolderOpen } from "lucide-react";

interface FileItem {
  id: string;
  name: string;
  type: "drawing" | "file";
  project_name: string;
  date: string;
  url: string;
  version?: number;
}

const Files = () => {
  const { user } = useAuth();
  const [files, setFiles] = useState<FileItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      if (!user) return;
      const { data: profile } = await supabase.from("profiles").select("company_id").eq("id", user.id).single();
      if (!profile?.company_id) { setLoading(false); return; }
      const { data: projects } = await supabase.from("projects")
        .select("id, name, display_address").eq("company_id", profile.company_id);
      if (!projects || projects.length === 0) { setLoading(false); return; }
      const ids = projects.map(p => p.id);
      const projectMap = Object.fromEntries(projects.map(p => [p.id, p.display_address || p.name || "Untitled"]));

      const [fRes, dRes] = await Promise.all([
        supabase.from("project_files").select("*").in("project_id", ids).order("created_at", { ascending: false }),
        supabase.from("drawing_versions").select("*").in("project_id", ids).eq("is_current", true).order("created_at", { ascending: false }),
      ]);

      const items: FileItem[] = [];
      (fRes.data || []).forEach(f => items.push({
        id: f.id, name: f.file_name, type: "file", project_name: projectMap[f.project_id] || "Unknown",
        date: f.created_at, url: f.file_url,
      }));
      (dRes.data || []).forEach(d => items.push({
        id: d.id, name: d.drawing_name, type: "drawing", project_name: projectMap[d.project_id] || "Unknown",
        date: d.created_at, url: d.file_url, version: d.version_number,
      }));
      items.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      setFiles(items);
      setLoading(false);
    };
    fetch();
  }, [user]);

  if (loading) return <div className="p-6 lg:p-8 space-y-4"><Skeleton className="h-10 w-48" /><Skeleton className="h-64" /></div>;

  return (
    <div className="p-6 lg:p-8 space-y-6">
      <div>
        <h1 className="text-2xl font-serif font-bold text-foreground">Files</h1>
        <p className="text-sm text-muted-foreground">{files.length} files available</p>
      </div>

      {files.length === 0 ? (
        <Card className="border-dashed border-2">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <FolderOpen className="h-12 w-12 text-muted-foreground/40 mb-4" />
            <p className="text-muted-foreground">No files available yet</p>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-none shadow-sm overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>File</TableHead>
                <TableHead>Project</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Date</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {files.map(f => (
                <TableRow key={f.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {f.type === "drawing" ? <PenTool className="h-4 w-4 text-primary" /> : <FileText className="h-4 w-4 text-muted-foreground" />}
                      <span className="font-medium">{f.name}</span>
                      {f.version && <Badge variant="secondary" className="text-[10px]">v{f.version}</Badge>}
                    </div>
                  </TableCell>
                  <TableCell className="text-muted-foreground">{f.project_name}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{f.type === "drawing" ? "Drawing" : "Document"}</Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">{new Date(f.date).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <Button size="sm" variant="ghost" asChild>
                      <a href={f.url} target="_blank" rel="noopener noreferrer"><Download className="h-4 w-4" /></a>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  );
};

export default Files;
