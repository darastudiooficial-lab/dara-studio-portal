import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Send,
  Paperclip,
  TicketPlus,
  Clock,
  CheckCircle2,
  AlertCircle,
  Search,
  ChevronDown,
  WifiOff,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useSearchParams } from "react-router-dom";

const conversations = [
  { id: 1, address: "Geral", lastMsg: "Olá! Preciso de uma atualização.", time: "10:30", unread: 2 },
  { id: 2, address: "41 Bowdoin Ave - Dorchester, MA", lastMsg: "As plantas foram enviadas.", time: "Ontem", unread: 0 },
  { id: 3, address: "88 Dover St - Boston, MA", lastMsg: "Aguardando aprovação da etapa.", time: "Seg", unread: 1 },
  { id: 4, address: "215 Hampton Rd - Brookline, MA", lastMsg: "Moodboard atualizado.", time: "Qui", unread: 0 },
];

const messagesData: Record<number, Array<{ id: number; text: string; sent: boolean; time: string }>> = {
  1: [
    { id: 1, text: "Olá! Como está o andamento do projeto?", sent: true, time: "10:28" },
    { id: 2, text: "Oi João! Estamos finalizando o detalhamento. Enviaremos os renders em breve.", sent: false, time: "10:30" },
    { id: 3, text: "Ótimo, obrigado pela atualização!", sent: true, time: "10:31" },
  ],
  2: [
    { id: 1, text: "As plantas da Bowdoin Ave foram atualizadas.", sent: false, time: "14:00" },
    { id: 2, text: "Perfeito, vou revisar hoje.", sent: true, time: "14:15" },
  ],
  3: [
    { id: 1, text: "O levantamento do Dover St está completo.", sent: false, time: "09:00" },
  ],
  4: [
    { id: 1, text: "O moodboard da Hampton Rd foi atualizado com as novas referências.", sent: false, time: "11:30" },
  ],
};

const tickets = [
  { id: "TK-001", subject: "Revisão da planta baixa", category: "Revisão de Projeto", status: "Em Análise", date: "15/03/2026" },
  { id: "TK-002", subject: "Dúvida sobre materiais", category: "Dúvida", status: "Aberto", date: "12/03/2026" },
  { id: "TK-003", subject: "Urgência na entrega", category: "Urgente", status: "Resolvido", date: "08/03/2026" },
];

const statusIcon: Record<string, React.ReactNode> = {
  Aberto: <Clock className="h-3.5 w-3.5" />,
  "Em Análise": <AlertCircle className="h-3.5 w-3.5" />,
  Resolvido: <CheckCircle2 className="h-3.5 w-3.5" />,
};

const statusColor: Record<string, string> = {
  Aberto: "bg-amber-100 text-amber-700 border-amber-200",
  "Em Análise": "bg-blue-100 text-blue-700 border-blue-200",
  Resolvido: "bg-emerald-100 text-emerald-700 border-emerald-200",
};

const projectToConv: Record<string, number> = {
  "1": 2,
  "2": 3,
  "3": 4,
};

// Simulate offline status
const isStudioOnline = false;

export default function Messages() {
  const [searchParams] = useSearchParams();
  const projectParam = searchParams.get("project");
  const tabParam = searchParams.get("tab");

  const initialConv = projectParam ? (projectToConv[projectParam] || 1) : 1;

  const [activeConv, setActiveConv] = useState(initialConv);
  const [newMsg, setNewMsg] = useState("");
  const [showTicketForm, setShowTicketForm] = useState(tabParam === "tickets");
  const [expandedTicket, setExpandedTicket] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState(tabParam === "tickets" ? "tickets" : "chat");

  useEffect(() => {
    if (projectParam) {
      const convId = projectToConv[projectParam] || 1;
      setActiveConv(convId);
    }
    if (tabParam === "tickets") {
      setActiveTab("tickets");
      setShowTicketForm(true);
    }
  }, [projectParam, tabParam]);

  const activeConvData = conversations.find((c) => c.id === activeConv);
  const currentMessages = messagesData[activeConv] || [];

  return (
    <div className="space-y-6 max-w-6xl">
      <h1 className="text-2xl md:text-3xl font-display font-semibold">Mensagens</h1>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="chat">Chat</TabsTrigger>
          <TabsTrigger value="tickets">Tickets</TabsTrigger>
        </TabsList>

        <TabsContent value="chat">
          {/* Offline banner */}
          {!isStudioOnline && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-3 p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-sm mb-4"
            >
              <WifiOff className="h-4 w-4 shrink-0" />
              <p>
                Estamos fora do horário comercial. Sua mensagem foi registrada como um ticket e responderemos em breve.
              </p>
            </motion.div>
          )}

          <Card className="border overflow-hidden">
            <div className="flex h-[500px]">
              {/* Contacts */}
              <div className="w-72 border-r flex flex-col shrink-0 hidden md:flex">
                <div className="p-3 border-b">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input placeholder="Buscar conversa..." className="pl-8 h-9 text-sm" />
                  </div>
                </div>
                <div className="flex-1 overflow-auto">
                  {conversations.map((conv) => (
                    <button
                      key={conv.id}
                      onClick={() => setActiveConv(conv.id)}
                      className={`w-full text-left p-3 border-b transition-colors ${
                        activeConv === conv.id ? "bg-secondary" : "hover:bg-secondary/50"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm truncate">{conv.address}</span>
                        <span className="text-[11px] text-muted-foreground shrink-0 ml-2">{conv.time}</span>
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-xs text-muted-foreground truncate pr-2">{conv.lastMsg}</span>
                        {conv.unread > 0 && (
                          <span className="bg-primary text-primary-foreground text-[10px] font-bold h-4 min-w-4 flex items-center justify-center rounded-full px-1">
                            {conv.unread}
                          </span>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Chat area */}
              <div className="flex-1 flex flex-col">
                <div className="p-3 border-b flex items-center justify-between bg-card">
                  <div>
                    <span className="font-display font-semibold text-sm block">
                      {activeConvData?.address}
                    </span>
                  </div>
                  <Button variant="ghost" size="sm" className="text-xs gap-1.5" onClick={() => { setActiveTab("tickets"); setShowTicketForm(true); }}>
                    <TicketPlus className="h-3.5 w-3.5" /> Abrir Ticket
                  </Button>
                </div>
                <div className="flex-1 overflow-auto p-4 space-y-3">
                  {currentMessages.map((msg) => (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${msg.sent ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm ${
                          msg.sent
                            ? "bg-primary text-primary-foreground rounded-br-md"
                            : "bg-secondary text-secondary-foreground rounded-bl-md"
                        }`}
                      >
                        <p>{msg.text}</p>
                        <p className={`text-[10px] mt-1 ${msg.sent ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                          {msg.time}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
                <div className="p-3 border-t flex gap-2">
                  <Button variant="ghost" size="icon" className="shrink-0">
                    <Paperclip className="h-4 w-4" />
                  </Button>
                  <Input
                    placeholder="Escreva uma mensagem..."
                    className="flex-1"
                    value={newMsg}
                    onChange={(e) => setNewMsg(e.target.value)}
                  />
                  <Button size="icon" className="shrink-0">
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="tickets">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">Gerencie seus tickets de suporte</p>
              <Button size="sm" className="gap-1.5" onClick={() => setShowTicketForm(!showTicketForm)}>
                <TicketPlus className="h-4 w-4" /> Novo Ticket
              </Button>
            </div>

            <AnimatePresence>
              {showTicketForm && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}>
                  <Card className="border">
                    <CardHeader><CardTitle className="text-base font-display">Abrir Ticket Formal</CardTitle></CardHeader>
                    <CardContent className="space-y-3">
                      <Input placeholder="Assunto" />
                      <Select>
                        <SelectTrigger><SelectValue placeholder="Categoria" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="duvida">Dúvida</SelectItem>
                          <SelectItem value="urgente">Urgente</SelectItem>
                          <SelectItem value="revisao">Revisão de Projeto</SelectItem>
                        </SelectContent>
                      </Select>
                      <Select>
                        <SelectTrigger><SelectValue placeholder="Projeto relacionado" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="bowdoin">41 Bowdoin Ave - Dorchester, MA</SelectItem>
                          <SelectItem value="dover">88 Dover St - Boston, MA</SelectItem>
                          <SelectItem value="hampton">215 Hampton Rd - Brookline, MA</SelectItem>
                        </SelectContent>
                      </Select>
                      <Textarea placeholder="Descreva sua solicitação..." rows={3} />
                      <div className="flex gap-2 justify-end">
                        <Button variant="outline" size="sm" onClick={() => setShowTicketForm(false)}>Cancelar</Button>
                        <Button size="sm" onClick={() => setShowTicketForm(false)}>Enviar Ticket</Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="space-y-3">
              {tickets.map((ticket) => (
                <Card key={ticket.id} className="border cursor-pointer hover:shadow-sm transition-shadow" onClick={() => setExpandedTicket(expandedTicket === ticket.id ? null : ticket.id)}>
                  <CardContent className="pt-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="text-xs font-mono text-muted-foreground">{ticket.id}</span>
                        <span className="font-medium text-sm">{ticket.subject}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className={`text-[11px] gap-1 ${statusColor[ticket.status]}`}>
                          {statusIcon[ticket.status]} {ticket.status}
                        </Badge>
                        <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${expandedTicket === ticket.id ? "rotate-180" : ""}`} />
                      </div>
                    </div>
                    <AnimatePresence>
                      {expandedTicket === ticket.id && (
                        <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                          <div className="mt-3 pt-3 border-t text-sm text-muted-foreground space-y-1">
                            <p>Categoria: {ticket.category}</p>
                            <p>Data: {ticket.date}</p>
                            <p>Aguardando resposta da equipe DARA Studio.</p>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
