import { useState } from "react";
import { motion } from "framer-motion";
import {
  FileText,
  Image,
  Download,
  Eye,
  Folder,
  ChevronRight,
  X,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const folders = [
  {
    name: "Cozinha Weston",
    files: [
      { name: "Planta Baixa v3.pdf", type: "pdf", size: "2.4 MB", date: "12/03/2026" },
      { name: "Render 3D - Vista Frontal.jpg", type: "image", size: "5.1 MB", date: "10/03/2026" },
      { name: "Orçamento Materiais.pdf", type: "pdf", size: "890 KB", date: "08/03/2026" },
    ],
  },
  {
    name: "Reforma Dover",
    files: [
      { name: "Levantamento Inicial.pdf", type: "pdf", size: "1.8 MB", date: "05/03/2026" },
      { name: "Fotos do Local.jpg", type: "image", size: "12.3 MB", date: "03/03/2026" },
    ],
  },
  {
    name: "Sala Estar Hampton",
    files: [
      { name: "Moodboard.jpg", type: "image", size: "3.7 MB", date: "14/03/2026" },
      { name: "Estudo Preliminar.pdf", type: "pdf", size: "4.2 MB", date: "11/03/2026" },
      { name: "Especificações Técnicas.pdf", type: "pdf", size: "1.1 MB", date: "09/03/2026" },
    ],
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  visible: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.06, duration: 0.35 } }),
};

export default function Files() {
  const [previewFile, setPreviewFile] = useState<string | null>(null);

  return (
    <div className="space-y-6 max-w-6xl">
      <div>
        <h1 className="text-2xl md:text-3xl font-display font-semibold">Arquivos</h1>
        <p className="text-muted-foreground mt-1">Acesse e faça download dos documentos dos seus projetos.</p>
      </div>

      {previewFile && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 z-50 bg-foreground/60 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setPreviewFile(null)}
        >
          <div className="bg-card rounded-xl shadow-2xl p-6 max-w-lg w-full text-center" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-sm">{previewFile}</h3>
              <Button variant="ghost" size="icon" onClick={() => setPreviewFile(null)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <div className="bg-muted rounded-lg h-64 flex items-center justify-center">
              <p className="text-muted-foreground text-sm">Pré-visualização de "{previewFile}"</p>
            </div>
            <Button className="mt-4 gap-2">
              <Download className="h-4 w-4" /> Download
            </Button>
          </div>
        </motion.div>
      )}

      <div className="space-y-4">
        {folders.map((folder, fi) => (
          <motion.div key={folder.name} custom={fi} initial="hidden" animate="visible" variants={fadeUp}>
            <Card className="border">
              <CardContent className="pt-4">
                <div className="flex items-center gap-2 mb-3">
                  <Folder className="h-4 w-4 text-primary" />
                  <h3 className="font-display font-semibold text-sm">{folder.name}</h3>
                  <Badge variant="secondary" className="text-[11px]">{folder.files.length} arquivos</Badge>
                </div>
                <div className="space-y-2">
                  {folder.files.map((file) => (
                    <div
                      key={file.name}
                      className="flex items-center justify-between p-2.5 rounded-lg hover:bg-secondary/50 transition-colors group"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {file.type === "pdf" ? (
                          <FileText className="h-4 w-4 text-destructive shrink-0" />
                        ) : (
                          <Image className="h-4 w-4 text-blue-500 shrink-0" />
                        )}
                        <div className="min-w-0">
                          <p className="text-sm font-medium truncate">{file.name}</p>
                          <p className="text-[11px] text-muted-foreground">{file.size} · {file.date}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setPreviewFile(file.name)}>
                          <Eye className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Download className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
