import { useState } from "react";
import { motion } from "framer-motion";
import {
  FolderKanban,
  Receipt,
  DollarSign,
  FileDown,
  Plus,
  MessageSquare,
  CheckCircle2,
  Circle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useNavigate } from "react-router-dom";
import NewEstimateModal from "@/components/NewEstimateModal";

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.08, duration: 0.4 } }),
};

const summaryCards = [
  { title: "Projetos Ativos", value: "3", icon: FolderKanban, change: "+1 este mês" },
  { title: "Faturas Pendentes", value: "2", icon: Receipt, change: "R$ 4.200" },
  { title: "Total Investido", value: "R$ 38.500", icon: DollarSign, change: "desde Jan/2024" },
  { title: "Arquivos Disponíveis", value: "47", icon: FileDown, change: "12 novos" },
];

const projects = [
  {
    address: "41 Bowdoin Ave - Dorchester, MA",
    service: "New Construction Single Family",
    phase: 3,
    phases: ["Levantamento", "Estudo Preliminar", "Detalhamento", "Entrega Final"],
  },
  {
    address: "88 Dover St - Boston, MA",
    service: "Commercial Office Renovation",
    phase: 1,
    phases: ["Levantamento", "Estudo Preliminar", "Detalhamento", "Entrega Final"],
  },
  {
    address: "215 Hampton Rd - Brookline, MA",
    service: "Interior Design - Living Room",
    phase: 2,
    phases: ["Levantamento", "Estudo Preliminar", "Detalhamento", "Entrega Final"],
  },
];

export default function Dashboard() {
  const navigate = useNavigate();
  const [estimateOpen, setEstimateOpen] = useState(false);

  return (
    <div className="space-y-8 max-w-6xl">
      <div>
        <h1 className="text-2xl md:text-3xl font-display font-semibold">Bem-vindo, João</h1>
        <p className="text-muted-foreground mt-1">Aqui está o resumo dos seus projetos com a DARA Studio.</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card, i) => (
          <motion.div key={card.title} custom={i} initial="hidden" animate="visible" variants={fadeUp}>
            <Card className="border bg-card hover:shadow-md transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-body font-medium text-muted-foreground">{card.title}</CardTitle>
                <card.icon className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-display font-bold">{card.value}</div>
                <p className="text-xs text-muted-foreground mt-1">{card.change}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-3">
        <Button onClick={() => setEstimateOpen(true)} className="gap-2">
          <Plus className="h-4 w-4" /> Novo Estimate
        </Button>
        <Button variant="outline" onClick={() => navigate("/invoices")} className="gap-2">
          <Receipt className="h-4 w-4" /> Ver Minhas Faturas
        </Button>
        <Button variant="outline" onClick={() => navigate("/messages")} className="gap-2">
          <MessageSquare className="h-4 w-4" /> Suporte / Mensagens
        </Button>
      </div>

      {/* Project Timelines */}
      <div className="space-y-4">
        <h2 className="text-lg font-display font-semibold">Linha do Tempo dos Projetos</h2>
        <div className="grid gap-4">
          {projects.map((project, i) => (
            <motion.div key={project.address} custom={i + 4} initial="hidden" animate="visible" variants={fadeUp}>
              <Card className="border bg-card">
                <CardContent className="pt-5">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-display font-semibold text-base">{project.address}</h3>
                    <span className="text-xs font-medium text-primary bg-primary/10 px-2.5 py-1 rounded-full">
                      Fase {project.phase}/{project.phases.length}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">{project.service}</p>
                  <Progress value={(project.phase / project.phases.length) * 100} className="h-2 mb-3" />
                  <div className="flex items-center gap-1 flex-wrap">
                    {project.phases.map((phase, idx) => (
                      <div key={phase} className="flex items-center gap-1">
                        {idx < project.phase ? (
                          <CheckCircle2 className="h-3.5 w-3.5 text-primary" />
                        ) : (
                          <Circle className="h-3.5 w-3.5 text-muted-foreground/40" />
                        )}
                        <span className={`text-xs ${idx < project.phase ? "text-foreground font-medium" : "text-muted-foreground"}`}>
                          {phase}
                        </span>
                        {idx < project.phases.length - 1 && <span className="text-muted-foreground/30 mx-1">›</span>}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      <NewEstimateModal open={estimateOpen} onOpenChange={setEstimateOpen} />
    </div>
  );
}
