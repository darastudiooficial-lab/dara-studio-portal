import { useState } from "react";
import { motion } from "framer-motion";
import { Download, CreditCard, CheckCircle2, Clock, AlertTriangle, Upload, Building2, QrCode } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";

const invoices = [
  { id: "INV-2026-001", project: "41 Bowdoin Ave - Dorchester, MA", date: "01/04/2026", due: "15/04/2026", amount: "R$ 2.800", status: "Pendente" },
  { id: "INV-2026-002", project: "88 Dover St - Boston, MA", date: "15/03/2026", due: "30/03/2026", amount: "R$ 1.400", status: "Pendente" },
  { id: "INV-2025-014", project: "41 Bowdoin Ave - Dorchester, MA", date: "01/03/2026", due: "15/03/2026", amount: "R$ 2.800", status: "Pago" },
  { id: "INV-2025-013", project: "215 Hampton Rd - Brookline, MA", date: "15/02/2026", due: "01/03/2026", amount: "R$ 3.500", status: "Pago" },
  { id: "INV-2025-012", project: "41 Bowdoin Ave - Dorchester, MA", date: "01/02/2026", due: "15/02/2026", amount: "R$ 2.800", status: "Pago" },
];

const statusConfig: Record<string, { icon: React.ReactNode; class: string }> = {
  Pago: { icon: <CheckCircle2 className="h-3.5 w-3.5" />, class: "bg-emerald-100 text-emerald-700 border-emerald-200" },
  Pendente: { icon: <Clock className="h-3.5 w-3.5" />, class: "bg-amber-100 text-amber-700 border-amber-200" },
  Atrasado: { icon: <AlertTriangle className="h-3.5 w-3.5" />, class: "bg-red-100 text-red-700 border-red-200" },
};

export default function Invoices() {
  const [paymentModal, setPaymentModal] = useState<string | null>(null);
  const [uploadedFile, setUploadedFile] = useState<string | null>(null);

  const payingInvoice = paymentModal ? invoices.find((inv) => inv.id === paymentModal) : null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file.name);
      toast.success(`Comprovante "${file.name}" anexado com sucesso!`);
    }
  };

  const handlePaymentSubmit = (method: string) => {
    toast.success(`Pagamento via ${method} para ${paymentModal} registrado!`, {
      description: "A equipe DARA Studio será notificada.",
    });
    setPaymentModal(null);
    setUploadedFile(null);
  };

  return (
    <div className="space-y-6 max-w-6xl">
      <div>
        <h1 className="text-2xl md:text-3xl font-display font-semibold">Faturas</h1>
        <p className="text-muted-foreground mt-1">Gerencie seus pagamentos e baixe recibos.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { title: "Total Pago", value: "R$ 9.100", sub: "3 faturas" },
          { title: "Pendente", value: "R$ 4.200", sub: "2 faturas" },
          { title: "Próximo Vencimento", value: "30/03/2026", sub: "INV-2026-002" },
        ].map((card, i) => (
          <motion.div key={card.title} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}>
            <Card className="border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-body font-medium text-muted-foreground">{card.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl font-display font-bold">{card.value}</div>
                <p className="text-xs text-muted-foreground">{card.sub}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card className="border overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Fatura</TableHead>
                <TableHead>Projeto</TableHead>
                <TableHead>Emissão</TableHead>
                <TableHead>Vencimento</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invoices.map((inv) => {
                const sc = statusConfig[inv.status];
                return (
                  <TableRow key={inv.id}>
                    <TableCell className="font-mono text-xs">{inv.id}</TableCell>
                    <TableCell className="font-medium text-sm">{inv.project}</TableCell>
                    <TableCell className="text-sm">{inv.date}</TableCell>
                    <TableCell className="text-sm">{inv.due}</TableCell>
                    <TableCell className="font-semibold text-sm">{inv.amount}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={`text-[11px] gap-1 ${sc.class}`}>
                        {sc.icon} {inv.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        {inv.status === "Pendente" && (
                          <Button
                            size="sm"
                            variant="default"
                            className="gap-1.5 text-xs"
                            onClick={() => setPaymentModal(inv.id)}
                          >
                            <CreditCard className="h-3.5 w-3.5" /> Pagar
                          </Button>
                        )}
                        <Button variant="ghost" size="sm" className="gap-1.5 text-xs">
                          <Download className="h-3.5 w-3.5" /> Recibo
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* Payment Modal */}
      <Dialog open={paymentModal !== null} onOpenChange={() => { setPaymentModal(null); setUploadedFile(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display">Pagar Fatura {payingInvoice?.id}</DialogTitle>
            <DialogDescription>
              {payingInvoice?.project} — {payingInvoice?.amount}
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="card" className="mt-2">
            <TabsList className="w-full">
              <TabsTrigger value="card" className="flex-1 gap-1.5 text-xs">
                <CreditCard className="h-3.5 w-3.5" /> Cartão (Stripe)
              </TabsTrigger>
              <TabsTrigger value="bank" className="flex-1 gap-1.5 text-xs">
                <Building2 className="h-3.5 w-3.5" /> Depósito (EUA)
              </TabsTrigger>
              <TabsTrigger value="pix" className="flex-1 gap-1.5 text-xs">
                <QrCode className="h-3.5 w-3.5" /> PIX (Brasil)
              </TabsTrigger>
            </TabsList>

            <TabsContent value="card" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label>Número do Cartão</Label>
                <Input placeholder="4242 4242 4242 4242" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>Validade</Label>
                  <Input placeholder="MM/AA" />
                </div>
                <div className="space-y-2">
                  <Label>CVV</Label>
                  <Input placeholder="123" />
                </div>
              </div>
              <Button className="w-full gap-2" onClick={() => handlePaymentSubmit("Cartão")}>
                <CreditCard className="h-4 w-4" /> Pagar {payingInvoice?.amount}
              </Button>
            </TabsContent>

            <TabsContent value="bank" className="space-y-4 mt-4">
              <Card className="border bg-secondary/30">
                <CardContent className="pt-4 space-y-2 text-sm">
                  <p className="font-semibold">Bank Transfer Details (USA)</p>
                  <p>Bank: Chase Bank</p>
                  <p>Routing: 021000021</p>
                  <p>Account: 1234567890</p>
                  <p>Beneficiary: DARA Studio LLC</p>
                </CardContent>
              </Card>
              <div className="space-y-2">
                <Label>Upload do Comprovante</Label>
                <div className="border-2 border-dashed rounded-lg p-4 text-center cursor-pointer hover:bg-secondary/30 transition-colors">
                  <input type="file" className="hidden" id="bank-receipt" onChange={handleFileUpload} accept="image/*,.pdf" />
                  <label htmlFor="bank-receipt" className="cursor-pointer">
                    <Upload className="h-6 w-6 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">
                      {uploadedFile || "Clique para enviar o comprovante"}
                    </p>
                  </label>
                </div>
              </div>
              <Button className="w-full gap-2" onClick={() => handlePaymentSubmit("Depósito Bancário")} disabled={!uploadedFile}>
                <Building2 className="h-4 w-4" /> Confirmar Pagamento
              </Button>
            </TabsContent>

            <TabsContent value="pix" className="space-y-4 mt-4">
              <Card className="border bg-secondary/30">
                <CardContent className="pt-4 text-center space-y-3">
                  <p className="font-semibold text-sm">Chave PIX</p>
                  <div className="bg-muted rounded-lg p-3">
                    <p className="font-mono text-xs break-all">financeiro@darastudio.com.br</p>
                  </div>
                  <div className="bg-muted rounded-lg h-32 flex items-center justify-center">
                    <QrCode className="h-16 w-16 text-muted-foreground/40" />
                  </div>
                  <p className="text-xs text-muted-foreground">Escaneie o QR Code ou copie a chave acima</p>
                </CardContent>
              </Card>
              <div className="space-y-2">
                <Label>Upload do Comprovante PIX</Label>
                <div className="border-2 border-dashed rounded-lg p-4 text-center cursor-pointer hover:bg-secondary/30 transition-colors">
                  <input type="file" className="hidden" id="pix-receipt" onChange={handleFileUpload} accept="image/*,.pdf" />
                  <label htmlFor="pix-receipt" className="cursor-pointer">
                    <Upload className="h-6 w-6 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">
                      {uploadedFile || "Clique para enviar o comprovante"}
                    </p>
                  </label>
                </div>
              </div>
              <Button className="w-full gap-2" onClick={() => handlePaymentSubmit("PIX")} disabled={!uploadedFile}>
                <QrCode className="h-4 w-4" /> Confirmar Pagamento
              </Button>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
}
