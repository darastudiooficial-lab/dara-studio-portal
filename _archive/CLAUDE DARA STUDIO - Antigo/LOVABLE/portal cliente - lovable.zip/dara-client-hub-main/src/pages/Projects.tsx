import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  CheckCircle2,
  Circle,
  Eye,
  ThumbsUp,
  FolderOpen,
  MessageSquare,
  TicketPlus,
  ChevronDown,
  ArrowRight,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import RevisionTicketModal from "@/components/RevisionTicketModal";

const projects = [
  {
    id: 1,
    address: "41 Bowdoin Ave - Dorchester, MA",
    service: "New Construction Single Family",
    phase: 3,
    phases: ["Levantamento", "Estudo Preliminar", "Detalhamento", "Entrega Final"],
    status: "Em andamento",
    files: [
      { name: "Planta Baixa v3.pdf", type: "pdf" as const, size: "2.4 MB", date: "12/03/2026" },
      { name: "Render 3D - Vista Frontal.jpg", type: "image" as const, size: "5.1 MB", date: "10/03/2026" },
      { name: "Orçamento Materiais.pdf", type: "pdf" as const, size: "890 KB", date: "08/03/2026" },
    ],
  },
  {
    id: 2,
    address: "88 Dover St - Boston, MA",
    service: "Commercial Office Renovation",
    phase: 1,
    phases: ["Levantamento", "Estudo Preliminar", "Detalhamento", "Entrega Final"],
    status: "Em andamento",
    files: [
      { name: "Levantamento Inicial.pdf", type: "pdf" as const, size: "1.8 MB", date: "05/03/2026" },
      { name: "Fotos do Local.jpg", type: "image" as const, size: "12.3 MB", date: "03/03/2026" },
    ],
  },
  {
    id: 3,
    address: "215 Hampton Rd - Brookline, MA",
    service: "Interior Design - Living Room",
    phase: 2,
    phases: ["Levantamento", "Estudo Preliminar", "Detalhamento", "Entrega Final"],
    status: "Em andamento",
    files: [
      { name: "Moodboard.jpg", type: "image" as const, size: "3.7 MB", date: "14/03/2026" },
      { name: "Estudo Preliminar.pdf", type: "pdf" as const, size: "4.2 MB", date: "11/03/2026" },
      { name: "Especificações Técnicas.pdf", type: "pdf" as const, size: "1.1 MB", date: "09/03/2026" },
    ],
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  visible: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.08, duration: 0.35 } }),
};

export default function Projects() {
  const navigate = useNavigate();
  const [expandedProject, setExpandedProject] = useState<number | null>(null);
  const [revisionModal, setRevisionModal] = useState<number | null>(null);

  const handleApprove = (address: string, phase: string) => {
    toast.success(`Etapa "${phase}" do projeto "${address}" aprovada com sucesso!`, {
      description: "A equipe DARA Studio foi notificada.",
    });
  };

  const revisionProject = revisionModal !== null ? projects.find((p) => p.id === revisionModal) : null;

  return (
    <div className="space-y-6 max-w-6xl">
      <div>
        <h1 className="text-2xl md:text-3xl font-display font-semibold">Projetos</h1>
        <p className="text-muted-foreground mt-1">Acompanhe e aprove as etapas dos seus projetos.</p>
      </div>

      <div className="grid gap-4">
        {projects.map((project, i) => (
          <motion.div key={project.id} custom={i} initial="hidden" animate="visible" variants={fadeUp}>
            <Card className="border hover:shadow-md transition-shadow">
              <CardContent className="pt-5 space-y-4">
                {/* Progress bar */}
                <div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
                    <span>Progresso</span>
                    <span>{Math.round((project.phase / project.phases.length) * 100)}%</span>
                  </div>
                  <Progress value={(project.phase / project.phases.length) * 100} className="h-2" />
                </div>

                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="font-display font-semibold text-lg">{project.address}</h3>
                    <p className="text-sm text-muted-foreground mt-0.5">{project.service}</p>
                  </div>
                  <Badge variant="outline" className="shrink-0 bg-primary/10 text-primary border-primary/20">
                    {project.status}
                  </Badge>
                </div>

                <div className="flex items-center gap-2 pt-1 flex-wrap">
                  <Button size="sm" className="gap-1.5" onClick={() => handleApprove(project.address, project.phases[project.phase - 1])}>
                    <ThumbsUp className="h-3.5 w-3.5" /> Aprovar Etapa
                  </Button>
                  <Button variant="outline" size="sm" className="gap-1.5" onClick={() => navigate(`/projects/${project.id}`)}>
                    <ArrowRight className="h-3.5 w-3.5" /> Ver Projeto
                  </Button>
                  <Button variant="outline" size="sm" className="gap-1.5" onClick={() => navigate(`/messages?project=${project.id}`)}>
                    <MessageSquare className="h-3.5 w-3.5" /> 💬 Chat
                  </Button>
                  <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setRevisionModal(project.id)}>
                    <TicketPlus className="h-3.5 w-3.5" /> 🎫 Abrir Ticket
                  </Button>
                  <Button
                    variant="outline" size="sm" className="gap-1.5"
                    onClick={() => setExpandedProject(expandedProject === project.id ? null : project.id)}
                  >
                    <Eye className="h-3.5 w-3.5" /> 👁️ Detalhes
                    <ChevronDown className={`h-3 w-3 transition-transform ${expandedProject === project.id ? "rotate-180" : ""}`} />
                  </Button>
                </div>

                <AnimatePresence>
                  {expandedProject === project.id && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                      <div className="pt-3 border-t space-y-3">
                        <div className="flex items-center gap-1 flex-wrap">
                          {project.phases.map((phase, idx) => (
                            <div key={phase} className="flex items-center gap-1">
                              {idx < project.phase ? <CheckCircle2 className="h-3.5 w-3.5 text-primary" /> : <Circle className="h-3.5 w-3.5 text-muted-foreground/40" />}
                              <span className={`text-xs ${idx < project.phase ? "text-foreground font-medium" : "text-muted-foreground"}`}>{phase}</span>
                              {idx < project.phases.length - 1 && <span className="text-muted-foreground/30 mx-1">›</span>}
                            </div>
                          ))}
                        </div>
                        <div className="grid grid-cols-2 gap-3 text-sm">
                          <div>
                            <p className="text-muted-foreground text-xs">Fase Atual</p>
                            <p className="font-medium">{project.phases[project.phase - 1]}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground text-xs">Arquivos</p>
                            <p className="font-medium">{project.files.length} documentos</p>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {revisionProject && (
        <RevisionTicketModal
          open={revisionModal !== null}
          onOpenChange={(open) => { if (!open) setRevisionModal(null); }}
          projectAddress={revisionProject.address}
          projectFiles={revisionProject.files}
        />
      )}
    </div>
  );
}
