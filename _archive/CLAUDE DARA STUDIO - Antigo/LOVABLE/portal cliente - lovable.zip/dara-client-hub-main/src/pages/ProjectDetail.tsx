import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  CheckCircle2,
  Circle,
  ThumbsUp,
  FileText,
  Image,
  Download,
  Eye,
  Upload,
  Send,
  Paperclip,
  TicketPlus,
  CreditCard,
  Building2,
  QrCode,
  Camera,
  Clock,
  X,
  MessageSquare,
  Pencil,
  Save,
  CloudDownload,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import RevisionTicketModal from "@/components/RevisionTicketModal";

interface ProjectFile {
  name: string;
  type: "pdf" | "image";
  size: string;
  postedDate: string;
  readDate?: string;
  downloadedDate?: string;
}

const projectsData = [
  {
    id: 1,
    address: "41 Bowdoin Ave - Dorchester, MA",
    service: "New Construction Single Family",
    phase: 3,
    phases: ["Levantamento", "Estudo Preliminar", "Detalhamento", "Entrega Final"],
    status: "Em andamento",
    client: "João da Silva",
    company: "Silva Holdings LLC",
    email: "joao@email.com",
    phone: "(11) 99999-0001",
    country: "Brasil",
    language: "Português",
    sqft: 2000,
    levels: "Ground + 2nd Floor",
    startDate: "15/01/2026",
    contractValue: "$4,800.00",
    files: [
      { name: "Planta Baixa v3.pdf", type: "pdf" as const, size: "2.4 MB", postedDate: "12/03/2026", readDate: "12/03/2026", downloadedDate: "13/03/2026" },
      { name: "Render 3D - Vista Frontal.jpg", type: "image" as const, size: "5.1 MB", postedDate: "10/03/2026", readDate: "10/03/2026" },
      { name: "Orçamento Materiais.pdf", type: "pdf" as const, size: "890 KB", postedDate: "08/03/2026" },
    ],
    revisions: [
      { rev: "REV 00", date: "20/01/2026", status: "Aprovado", desc: "Planta inicial aprovada" },
      { rev: "REV 01", date: "15/02/2026", status: "Aprovado", desc: "Ajustes em layout da cozinha" },
      { rev: "REV 02", date: "10/03/2026", status: "Pendente", desc: "Detalhamento técnico em revisão" },
    ],
    siteUpdates: [
      { date: "14/03/2026", text: "Fundação concluída, iniciando estrutura.", photos: 3 },
      { date: "08/03/2026", text: "Terreno preparado e nivelado.", photos: 5 },
    ],
    invoices: [
      { id: "INV-001", desc: "Entry Payment (50%)", amount: "$2,400.00", status: "Pago", date: "20/01/2026", paidDate: "22/01/2026", receipt: "comprovante_jan.pdf" },
      { id: "INV-002", desc: "Final Payment (50%)", amount: "$2,400.00", status: "Pendente", date: "15/04/2026" },
    ],
  },
  {
    id: 2,
    address: "88 Dover St - Boston, MA",
    service: "Commercial Office Renovation",
    phase: 1,
    phases: ["Levantamento", "Estudo Preliminar", "Detalhamento", "Entrega Final"],
    status: "Em andamento",
    client: "João da Silva",
    company: "",
    email: "joao@email.com",
    phone: "(11) 99999-0001",
    country: "USA",
    language: "English",
    sqft: 3500,
    levels: "Ground Floor",
    startDate: "01/03/2026",
    contractValue: "$6,200.00",
    files: [
      { name: "Levantamento Inicial.pdf", type: "pdf" as const, size: "1.8 MB", postedDate: "05/03/2026", readDate: "06/03/2026" },
      { name: "Fotos do Local.jpg", type: "image" as const, size: "12.3 MB", postedDate: "03/03/2026" },
    ],
    revisions: [
      { rev: "REV 00", date: "05/03/2026", status: "Pendente", desc: "Levantamento inicial em análise" },
    ],
    siteUpdates: [],
    invoices: [
      { id: "INV-003", desc: "Entry Payment (50%)", amount: "$3,100.00", status: "Pago", date: "01/03/2026", paidDate: "03/03/2026" },
      { id: "INV-004", desc: "Final Payment (50%)", amount: "$3,100.00", status: "Pendente", date: "01/06/2026" },
    ],
  },
  {
    id: 3,
    address: "215 Hampton Rd - Brookline, MA",
    service: "Interior Design - Living Room",
    phase: 2,
    phases: ["Levantamento", "Estudo Preliminar", "Detalhamento", "Entrega Final"],
    status: "Em andamento",
    client: "João da Silva",
    company: "",
    email: "joao@email.com",
    phone: "(11) 99999-0001",
    country: "USA",
    language: "English",
    sqft: 1200,
    levels: "Ground Floor",
    startDate: "10/02/2026",
    contractValue: "$3,600.00",
    files: [
      { name: "Moodboard.jpg", type: "image" as const, size: "3.7 MB", postedDate: "14/03/2026" },
      { name: "Estudo Preliminar.pdf", type: "pdf" as const, size: "4.2 MB", postedDate: "11/03/2026", readDate: "11/03/2026", downloadedDate: "12/03/2026" },
      { name: "Especificações Técnicas.pdf", type: "pdf" as const, size: "1.1 MB", postedDate: "09/03/2026" },
    ],
    revisions: [
      { rev: "REV 00", date: "15/02/2026", status: "Aprovado", desc: "Moodboard aprovado" },
      { rev: "REV 01", date: "11/03/2026", status: "Pendente", desc: "Estudo preliminar aguardando aprovação" },
    ],
    siteUpdates: [
      { date: "12/03/2026", text: "Sala desmontada, pronta para renovação.", photos: 2 },
    ],
    invoices: [
      { id: "INV-005", desc: "Entry Payment (50%)", amount: "$1,800.00", status: "Pago", date: "10/02/2026", paidDate: "12/02/2026" },
      { id: "INV-006", desc: "Final Payment (50%)", amount: "$1,800.00", status: "Pendente", date: "10/05/2026" },
    ],
  },
];

const chatMessages = [
  { id: 1, text: "As plantas foram atualizadas com as correções.", sent: false, time: "14:00" },
  { id: 2, text: "Perfeito, vou revisar hoje.", sent: true, time: "14:15" },
  { id: 3, text: "Qualquer dúvida, pode me chamar!", sent: false, time: "14:16" },
];

export default function ProjectDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const project = projectsData.find((p) => p.id === Number(id));
  const [activeTab, setActiveTab] = useState("overview");
  const [previewFile, setPreviewFile] = useState<string | null>(null);
  const [revisionModal, setRevisionModal] = useState(false);
  const [newMsg, setNewMsg] = useState("");
  const [siteUpdateText, setSiteUpdateText] = useState("");
  const [paymentModal, setPaymentModal] = useState<string | null>(null);
  const [uploadedReceipt, setUploadedReceipt] = useState<string | null>(null);

  // Editable client fields
  const [editingClient, setEditingClient] = useState(false);
  const [clientName, setClientName] = useState("");
  const [clientCompany, setClientCompany] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [clientCountry, setClientCountry] = useState("");
  const [clientLanguage, setClientLanguage] = useState("");

  if (!project) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <p className="text-muted-foreground">Projeto não encontrado.</p>
        <Button variant="outline" onClick={() => navigate("/projects")}>
          <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
        </Button>
      </div>
    );
  }

  const progressPercent = (project.phase / project.phases.length) * 100;

  const startEditClient = () => {
    setClientName(project.client);
    setClientCompany(project.company);
    setClientEmail(project.email);
    setClientPhone(project.phone);
    setClientCountry(project.country);
    setClientLanguage(project.language);
    setEditingClient(true);
  };

  const saveClientInfo = () => {
    setEditingClient(false);
    toast.success("Dados pessoais atualizados!");
  };

  const handleApprove = (rev: string) => {
    toast.success(`Revisão "${rev}" aprovada com sucesso!`, {
      description: "A equipe DARA Studio foi notificada.",
    });
  };

  const handleReceiptUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedReceipt(file.name);
      toast.success(`Comprovante "${file.name}" anexado!`);
    }
  };

  const handlePayment = (method: string) => {
    toast.success(`Pagamento via ${method} registrado!`, { description: "DARA Studio será notificada." });
    setPaymentModal(null);
    setUploadedReceipt(null);
  };

  const handleAttachReceipt = (invoiceId: string) => {
    toast.success(`Comprovante anexado à fatura ${invoiceId}!`);
  };

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Header */}
      <div className="flex items-start gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate("/projects")} className="mt-1 shrink-0">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-2xl md:text-3xl font-display font-semibold">{project.address}</h1>
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
              {project.status}
            </Badge>
          </div>
          <p className="text-muted-foreground mt-1">{project.service}</p>
        </div>
      </div>

      {/* Progress */}
      <Card className="border">
        <CardContent className="pt-5">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-muted-foreground">Progresso Geral</span>
            <span className="font-semibold text-primary">{Math.round(progressPercent)}%</span>
          </div>
          <Progress value={progressPercent} className="h-2.5 mb-4" />
          <div className="flex items-center gap-1 flex-wrap">
            {project.phases.map((phase, idx) => (
              <div key={phase} className="flex items-center gap-1">
                {idx < project.phase ? (
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                ) : (
                  <Circle className="h-4 w-4 text-muted-foreground/40" />
                )}
                <span className={`text-sm ${idx < project.phase ? "text-foreground font-medium" : "text-muted-foreground"}`}>
                  {phase}
                </span>
                {idx < project.phases.length - 1 && <span className="text-muted-foreground/30 mx-1.5">›</span>}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Approve Stage */}
      <div className="flex items-center gap-3 p-4 rounded-xl border-2 border-primary/30 bg-primary/5">
        <div className="flex-1">
          <p className="font-display font-semibold text-sm">Etapa Atual: {project.phases[project.phase - 1]}</p>
          <p className="text-xs text-muted-foreground mt-0.5">Revise os arquivos e aprove para avançar à próxima fase.</p>
        </div>
        <Button
          size="lg"
          className="gap-2 shadow-md"
          onClick={() => handleApprove(project.phases[project.phase - 1])}
        >
          <ThumbsUp className="h-4 w-4" /> Aprovar Etapa
        </Button>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="progress">Progress / Timeline</TabsTrigger>
          <TabsTrigger value="drawings">Drawings / Files</TabsTrigger>
          <TabsTrigger value="site-updates">Site Updates</TabsTrigger>
          <TabsTrigger value="finance">Finance</TabsTrigger>
          <TabsTrigger value="chat">Tickets / Chat</TabsTrigger>
        </TabsList>

        {/* OVERVIEW */}
        <TabsContent value="overview" className="space-y-4 mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Client Data - Editable */}
            <Card className="border">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm text-muted-foreground font-body">Dados do Cliente</CardTitle>
                  {!editingClient ? (
                    <Button variant="ghost" size="sm" className="gap-1.5 text-xs" onClick={startEditClient}>
                      <Pencil className="h-3 w-3" /> Editar
                    </Button>
                  ) : (
                    <Button variant="default" size="sm" className="gap-1.5 text-xs" onClick={saveClientInfo}>
                      <Save className="h-3 w-3" /> Salvar
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                {editingClient ? (
                  <div className="space-y-3">
                    <div className="space-y-1">
                      <Label className="text-xs">Nome</Label>
                      <Input value={clientName} onChange={(e) => setClientName(e.target.value)} className="h-8 text-sm" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Empresa</Label>
                      <Input value={clientCompany} onChange={(e) => setClientCompany(e.target.value)} className="h-8 text-sm" placeholder="Opcional" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Email</Label>
                      <Input value={clientEmail} onChange={(e) => setClientEmail(e.target.value)} className="h-8 text-sm" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Telefone</Label>
                      <Input value={clientPhone} onChange={(e) => setClientPhone(e.target.value)} className="h-8 text-sm" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">País</Label>
                      <Input value={clientCountry} onChange={(e) => setClientCountry(e.target.value)} className="h-8 text-sm" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Idioma</Label>
                      <Input value={clientLanguage} onChange={(e) => setClientLanguage(e.target.value)} className="h-8 text-sm" />
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="flex justify-between"><span className="text-muted-foreground">Nome</span><span className="font-medium">{project.client}</span></div>
                    <Separator />
                    {project.company && (
                      <>
                        <div className="flex justify-between"><span className="text-muted-foreground">Empresa</span><span className="font-medium">{project.company}</span></div>
                        <Separator />
                      </>
                    )}
                    <div className="flex justify-between"><span className="text-muted-foreground">Email</span><span className="font-medium">{project.email}</span></div>
                    <Separator />
                    <div className="flex justify-between"><span className="text-muted-foreground">Telefone</span><span className="font-medium">{project.phone}</span></div>
                    <Separator />
                    <div className="flex justify-between"><span className="text-muted-foreground">País</span><span className="font-medium">{project.country}</span></div>
                    <Separator />
                    <div className="flex justify-between"><span className="text-muted-foreground">Idioma</span><span className="font-medium">{project.language}</span></div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Technical Details */}
            <Card className="border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-muted-foreground font-body">Detalhes Técnicos</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Endereço</span><span className="font-medium">{project.address}</span></div>
                <Separator />
                <div className="flex justify-between"><span className="text-muted-foreground">Serviço</span><span className="font-medium">{project.service}</span></div>
                <Separator />
                <div className="flex justify-between"><span className="text-muted-foreground">Área</span><span className="font-medium">{project.sqft.toLocaleString()} sqft</span></div>
                <Separator />
                <div className="flex justify-between"><span className="text-muted-foreground">Níveis</span><span className="font-medium">{project.levels}</span></div>
                <Separator />
                <div className="flex justify-between"><span className="text-muted-foreground">Início</span><span className="font-medium">{project.startDate}</span></div>
                <Separator />
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Valor do Contrato</span>
                  <span className="font-display font-bold text-primary">{project.contractValue}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* PROGRESS / TIMELINE */}
        <TabsContent value="progress" className="space-y-4 mt-4">
          <div className="relative pl-6 space-y-6">
            <div className="absolute left-2.5 top-2 bottom-2 w-px bg-border" />
            {project.revisions.map((rev, idx) => (
              <motion.div
                key={rev.rev}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="relative"
              >
                <div className={`absolute -left-[18px] top-1 h-4 w-4 rounded-full border-2 ${
                  rev.status === "Aprovado" ? "bg-primary border-primary" : "bg-card border-muted-foreground/40"
                }`}>
                  {rev.status === "Aprovado" && <CheckCircle2 className="h-3 w-3 text-primary-foreground absolute top-0 left-0" />}
                </div>
                <Card className="border">
                  <CardContent className="pt-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-display font-semibold text-sm">{rev.rev}</span>
                        <span className="text-xs text-muted-foreground ml-3">{rev.date}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className={`text-[11px] ${
                          rev.status === "Aprovado"
                            ? "bg-emerald-100 text-emerald-700 border-emerald-200"
                            : "bg-amber-100 text-amber-700 border-amber-200"
                        }`}>
                          {rev.status}
                        </Badge>
                        {rev.status === "Pendente" && (
                          <Button size="sm" className="gap-1.5 text-xs" onClick={() => handleApprove(rev.rev)}>
                            <ThumbsUp className="h-3 w-3" /> Aprovar
                          </Button>
                        )}
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{rev.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {/* DRAWINGS / FILES */}
        <TabsContent value="drawings" className="space-y-3 mt-4">
          {project.files.map((file) => (
            <div
              key={file.name}
              className="flex items-center justify-between p-3 rounded-lg border hover:bg-secondary/50 transition-colors group"
            >
              <div className="flex items-center gap-3 min-w-0 flex-1">
                {file.type === "pdf" ? (
                  <FileText className="h-5 w-5 text-destructive shrink-0" />
                ) : (
                  <Image className="h-5 w-5 text-blue-500 shrink-0" />
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium truncate">{file.name}</p>
                  <div className="flex items-center gap-3 text-[11px] text-muted-foreground mt-0.5">
                    <span>{file.size}</span>
                    <span>Postado: {file.postedDate}</span>
                    {file.readDate && <span className="text-emerald-600">Lido: {file.readDate}</span>}
                    {file.downloadedDate && (
                      <span className="text-primary flex items-center gap-0.5">
                        <CloudDownload className="h-3 w-3" /> {file.downloadedDate}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setPreviewFile(file.name)} title="Visualizar">
                  <Eye className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8" title="Download">
                  <Download className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost" size="icon" className="h-8 w-8"
                  title="Chat sobre este arquivo"
                  onClick={() => { setActiveTab("chat"); }}
                >
                  <MessageSquare className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost" size="icon" className="h-8 w-8"
                  title="Abrir ticket sobre este arquivo"
                  onClick={() => setRevisionModal(true)}
                >
                  <TicketPlus className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
          {project.files.length === 0 && (
            <div className="text-center py-12 text-muted-foreground text-sm">
              Nenhum arquivo disponível ainda.
            </div>
          )}
        </TabsContent>

        {/* SITE UPDATES */}
        <TabsContent value="site-updates" className="space-y-4 mt-4">
          <Card className="border border-dashed">
            <CardContent className="pt-5 space-y-3">
              <Label className="font-display font-semibold text-sm">Nova Atualização da Obra</Label>
              <Textarea
                placeholder="Descreva o que está acontecendo na obra..."
                rows={3}
                value={siteUpdateText}
                onChange={(e) => setSiteUpdateText(e.target.value)}
              />
              <div className="flex items-center gap-3">
                <div className="border-2 border-dashed rounded-lg p-3 flex-1 text-center cursor-pointer hover:bg-secondary/30 transition-colors">
                  <input type="file" className="hidden" id="site-photos" multiple accept="image/*" />
                  <label htmlFor="site-photos" className="cursor-pointer flex items-center justify-center gap-2 text-sm text-muted-foreground">
                    <Camera className="h-4 w-4" /> Adicionar Fotos
                  </label>
                </div>
                <Button
                  className="gap-2"
                  disabled={!siteUpdateText.trim()}
                  onClick={() => {
                    toast.success("Atualização publicada!");
                    setSiteUpdateText("");
                  }}
                >
                  <Upload className="h-4 w-4" /> Publicar
                </Button>
              </div>
            </CardContent>
          </Card>

          {project.siteUpdates.map((update, idx) => (
            <motion.div key={idx} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.08 }}>
              <Card className="border">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                    <Clock className="h-3.5 w-3.5" /> {update.date}
                    {update.photos > 0 && (
                      <Badge variant="secondary" className="text-[10px]">{update.photos} fotos</Badge>
                    )}
                  </div>
                  <p className="text-sm">{update.text}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
          {project.siteUpdates.length === 0 && (
            <p className="text-center text-sm text-muted-foreground py-8">Nenhuma atualização publicada ainda.</p>
          )}
        </TabsContent>

        {/* FINANCE */}
        <TabsContent value="finance" className="space-y-4 mt-4">
          {/* Payment terms highlight */}
          <Card className="border-2 border-primary/20 bg-primary/5">
            <CardContent className="pt-4 flex items-center justify-between">
              <div>
                <p className="font-display font-semibold text-sm">Termos de Pagamento</p>
                <p className="text-xs text-muted-foreground mt-0.5">50% Entry Payment + 50% Final Payment</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">Valor Total do Contrato</p>
                <p className="text-xl font-display font-bold text-primary">{project.contractValue}</p>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {project.invoices.map((inv) => (
              <Card key={inv.id} className={`border-2 ${inv.status === "Pendente" ? "border-primary/30" : "border-border"}`}>
                <CardContent className="pt-5 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs text-muted-foreground">{inv.id}</span>
                    <Badge variant="outline" className={`text-[11px] ${
                      inv.status === "Pago"
                        ? "bg-emerald-100 text-emerald-700 border-emerald-200"
                        : "bg-amber-100 text-amber-700 border-amber-200"
                    }`}>
                      {inv.status}
                    </Badge>
                  </div>
                  <div>
                    <p className="font-display font-semibold text-sm">{inv.desc}</p>
                    <p className="text-2xl font-display font-bold text-primary mt-1">{inv.amount}</p>
                  </div>
                  <div className="text-xs text-muted-foreground space-y-0.5">
                    <p>Vencimento: {inv.date}</p>
                    {inv.paidDate && <p className="text-emerald-600 font-medium">Pago em: {inv.paidDate}</p>}
                  </div>

                  {inv.status === "Pendente" ? (
                    <Button className="w-full gap-2" onClick={() => setPaymentModal(inv.id)}>
                      <CreditCard className="h-4 w-4" /> Pagar Agora
                    </Button>
                  ) : (
                    <div className="space-y-2">
                      {inv.receipt && (
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <CheckCircle2 className="h-3 w-3 text-emerald-600" /> Comprovante: {inv.receipt}
                        </p>
                      )}
                      <div className="border-2 border-dashed rounded-lg p-2.5 text-center cursor-pointer hover:bg-secondary/30 transition-colors">
                        <input
                          type="file"
                          className="hidden"
                          id={`receipt-${inv.id}`}
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleAttachReceipt(inv.id);
                          }}
                          accept="image/*,.pdf"
                        />
                        <label htmlFor={`receipt-${inv.id}`} className="cursor-pointer flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
                          <Upload className="h-3.5 w-3.5" /> {inv.receipt ? "Atualizar comprovante" : "Anexar comprovante"}
                        </label>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* TICKETS / CHAT */}
        <TabsContent value="chat" className="space-y-4 mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card className="border overflow-hidden">
              <CardHeader className="pb-2 border-b">
                <CardTitle className="text-sm font-display">💬 Chat — {project.address}</CardTitle>
              </CardHeader>
              <div className="flex flex-col h-80">
                <div className="flex-1 overflow-auto p-4 space-y-3">
                  {chatMessages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.sent ? "justify-end" : "justify-start"}`}>
                      <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${
                        msg.sent
                          ? "bg-primary text-primary-foreground rounded-br-md"
                          : "bg-secondary text-secondary-foreground rounded-bl-md"
                      }`}>
                        <p>{msg.text}</p>
                        <p className={`text-[10px] mt-1 ${msg.sent ? "text-primary-foreground/70" : "text-muted-foreground"}`}>{msg.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="p-3 border-t flex gap-2">
                  <Button variant="ghost" size="icon" className="shrink-0"><Paperclip className="h-4 w-4" /></Button>
                  <Input placeholder="Escreva uma mensagem..." className="flex-1" value={newMsg} onChange={(e) => setNewMsg(e.target.value)} />
                  <Button size="icon" className="shrink-0"><Send className="h-4 w-4" /></Button>
                </div>
              </div>
            </Card>

            <Card className="border">
              <CardHeader className="pb-2 border-b">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-display">🎫 Tickets de Revisão</CardTitle>
                  <Button size="sm" variant="outline" className="gap-1.5 text-xs" onClick={() => setRevisionModal(true)}>
                    <TicketPlus className="h-3.5 w-3.5" /> Abrir Ticket
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="pt-4 space-y-3">
                {project.revisions.filter(r => r.status === "Pendente").map((rev) => (
                  <div key={rev.rev} className="flex items-center justify-between p-2.5 rounded-lg border">
                    <div>
                      <p className="text-sm font-medium">{rev.rev} — {rev.desc}</p>
                      <p className="text-xs text-muted-foreground">{rev.date}</p>
                    </div>
                    <Badge variant="outline" className="text-[11px] bg-amber-100 text-amber-700 border-amber-200">
                      Pendente
                    </Badge>
                  </div>
                ))}
                {project.revisions.filter(r => r.status === "Pendente").length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">Nenhum ticket pendente.</p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* File Preview Overlay */}
      <AnimatePresence>
        {previewFile && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-foreground/60 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setPreviewFile(null)}
          >
            <div className="bg-card rounded-xl shadow-2xl p-6 max-w-lg w-full text-center" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display font-semibold text-sm">{previewFile}</h3>
                <Button variant="ghost" size="icon" onClick={() => setPreviewFile(null)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <div className="bg-muted rounded-lg h-64 flex items-center justify-center">
                <p className="text-muted-foreground text-sm">Pré-visualização de "{previewFile}"</p>
              </div>
              <Button className="mt-4 gap-2"><Download className="h-4 w-4" /> Download</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Payment Modal */}
      {paymentModal && (
        <div className="fixed inset-0 z-50 bg-foreground/50 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => { setPaymentModal(null); setUploadedReceipt(null); }}>
          <div className="bg-card rounded-xl shadow-2xl p-6 max-w-md w-full" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold">Pagamento</h3>
              <Button variant="ghost" size="icon" onClick={() => { setPaymentModal(null); setUploadedReceipt(null); }}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <Tabs defaultValue="card">
              <TabsList className="w-full">
                <TabsTrigger value="card" className="flex-1 gap-1 text-xs"><CreditCard className="h-3.5 w-3.5" /> Cartão</TabsTrigger>
                <TabsTrigger value="bank" className="flex-1 gap-1 text-xs"><Building2 className="h-3.5 w-3.5" /> Depósito</TabsTrigger>
                <TabsTrigger value="pix" className="flex-1 gap-1 text-xs"><QrCode className="h-3.5 w-3.5" /> PIX</TabsTrigger>
              </TabsList>
              <TabsContent value="card" className="space-y-3 mt-4">
                <Input placeholder="4242 4242 4242 4242" />
                <div className="grid grid-cols-2 gap-2"><Input placeholder="MM/AA" /><Input placeholder="CVV" /></div>
                <Button className="w-full gap-2" onClick={() => handlePayment("Cartão")}>
                  <CreditCard className="h-4 w-4" /> Pagar
                </Button>
              </TabsContent>
              <TabsContent value="bank" className="space-y-3 mt-4">
                <Card className="border bg-secondary/30">
                  <CardContent className="pt-4 text-sm space-y-1">
                    <p className="font-semibold">Bank: Chase Bank</p>
                    <p>Routing: 021000021</p>
                    <p>Account: 1234567890</p>
                    <p>Beneficiary: DARA Studio LLC</p>
                  </CardContent>
                </Card>
                <div className="border-2 border-dashed rounded-lg p-4 text-center cursor-pointer hover:bg-secondary/30">
                  <input type="file" className="hidden" id="bank-receipt-detail" onChange={handleReceiptUpload} accept="image/*,.pdf" />
                  <label htmlFor="bank-receipt-detail" className="cursor-pointer">
                    <Upload className="h-5 w-5 mx-auto text-muted-foreground mb-1" />
                    <p className="text-sm text-muted-foreground">{uploadedReceipt || "Upload comprovante"}</p>
                  </label>
                </div>
                <Button className="w-full" disabled={!uploadedReceipt} onClick={() => handlePayment("Depósito")}>Confirmar</Button>
              </TabsContent>
              <TabsContent value="pix" className="space-y-3 mt-4">
                <div className="bg-muted rounded-lg p-3 text-center">
                  <p className="font-mono text-xs">financeiro@darastudio.com.br</p>
                </div>
                <div className="bg-muted rounded-lg h-28 flex items-center justify-center">
                  <QrCode className="h-12 w-12 text-muted-foreground/40" />
                </div>
                <div className="border-2 border-dashed rounded-lg p-4 text-center cursor-pointer hover:bg-secondary/30">
                  <input type="file" className="hidden" id="pix-receipt-detail" onChange={handleReceiptUpload} accept="image/*,.pdf" />
                  <label htmlFor="pix-receipt-detail" className="cursor-pointer">
                    <Upload className="h-5 w-5 mx-auto text-muted-foreground mb-1" />
                    <p className="text-sm text-muted-foreground">{uploadedReceipt || "Upload comprovante PIX"}</p>
                  </label>
                </div>
                <Button className="w-full" disabled={!uploadedReceipt} onClick={() => handlePayment("PIX")}>Confirmar</Button>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      )}

      {/* Revision Modal */}
      <RevisionTicketModal
        open={revisionModal}
        onOpenChange={setRevisionModal}
        projectAddress={project.address}
        projectFiles={project.files}
      />
    </div>
  );
}
