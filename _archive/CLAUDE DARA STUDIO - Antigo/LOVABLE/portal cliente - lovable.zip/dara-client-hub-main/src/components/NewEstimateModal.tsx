import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  MapPin,
  Hammer,
  ChevronRight,
  ChevronLeft,
  Check,
  Upload,
  Calculator,
  Zap,
  Cuboid,
  Ruler,
  PenTool,
  LayoutGrid,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

interface NewEstimateModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const serviceTypes = [
  { value: "new-construction", label: "New Construction / Custom Home", multiplier: 1.0 },
  { value: "addition", label: "Addition / ADU", multiplier: 1.15 },
  { value: "renovation", label: "Renovation / Remodel", multiplier: 1.10 },
  { value: "commercial", label: "Commercial Building", multiplier: 1.25 },
];

const RATE_GROUND = 1.60;
const RATE_SECOND = 1.10;
const RATE_BASEMENT = 0.80;
const RATE_ATTIC = 0.80;
const RENDER_COST = 350;

const renderableRooms = ["Kitchen", "Bathroom 1", "Bathroom 2", "Laundry Room"];

const designExtras = [
  { id: "architectural", label: "Architectural Design", icon: PenTool },
  { id: "space-planning", label: "Space Planning", icon: LayoutGrid },
  { id: "interior-layout", label: "Interior Layout", icon: Ruler },
];

const rooms = [
  "Living Room", "Kitchen", "Master Bedroom", "Bedroom 2", "Bedroom 3",
  "Bathroom 1", "Bathroom 2", "Home Office", "Garage", "Laundry Room",
  "Dining Room", "Pantry", "Mudroom", "Deck / Patio",
];

export default function NewEstimateModal({ open, onOpenChange }: NewEstimateModalProps) {
  const [phase, setPhase] = useState<1 | 2>(1);

  // Phase 1
  const [address, setAddress] = useState("");
  const [width, setWidth] = useState("");
  const [length, setLength] = useState("");
  const [serviceType, setServiceType] = useState("");
  const [hasSecondFloor, setHasSecondFloor] = useState(false);
  const [hasBasement, setHasBasement] = useState(false);
  const [hasAttic, setHasAttic] = useState(false);

  // Add-ons
  const [renderRooms, setRenderRooms] = useState<string[]>([]);
  const [selectedExtras, setSelectedExtras] = useState<string[]>([]);
  const [rushFee, setRushFee] = useState(false);

  // Phase 2
  const [selectedRooms, setSelectedRooms] = useState<string[]>([]);
  const [overview, setOverview] = useState("");
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);

  const estimate = useMemo(() => {
    const w = parseFloat(width) || 0;
    const l = parseFloat(length) || 0;
    const baseArea = w * l;
    if (baseArea === 0) return null;

    const groundCost = baseArea * RATE_GROUND;
    const secondCost = hasSecondFloor ? baseArea * RATE_SECOND : 0;
    const basementCost = hasBasement ? baseArea * RATE_BASEMENT : 0;
    const atticCost = hasAttic ? baseArea * RATE_ATTIC : 0;

    const subtotalArea = groundCost + secondCost + basementCost + atticCost;

    const svc = serviceTypes.find((s) => s.value === serviceType);
    const multiplier = svc?.multiplier ?? 1.0;
    const afterScope = subtotalArea * multiplier;

    const renderCount = renderRooms.length;
    const renderTotal = renderCount * RENDER_COST;

    const beforeRush = afterScope + renderTotal;
    const rushAmount = rushFee ? beforeRush * 0.20 : 0;
    const total = beforeRush + rushAmount;

    const totalArea = baseArea + (hasSecondFloor ? baseArea : 0) + (hasBasement ? baseArea : 0) + (hasAttic ? baseArea : 0);

    return {
      baseArea, totalArea, groundCost, secondCost, basementCost, atticCost,
      subtotalArea, multiplier, scopeLabel: svc?.label ?? "", afterScope,
      renderCount, renderTotal, rushAmount, total,
    };
  }, [width, length, hasSecondFloor, hasBasement, hasAttic, serviceType, renderRooms, rushFee]);

  const phase1Valid = address.trim() && width.trim() && length.trim() && serviceType;

  const toggleRoom = (room: string) => {
    setSelectedRooms((prev) => prev.includes(room) ? prev.filter((r) => r !== room) : [...prev, room]);
  };

  const toggleRenderRoom = (room: string) => {
    setRenderRooms((prev) => prev.includes(room) ? prev.filter((r) => r !== room) : [...prev, room]);
  };

  const toggleExtra = (id: string) => {
    setSelectedExtras((prev) => prev.includes(id) ? prev.filter((e) => e !== id) : [...prev, id]);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) setUploadedFiles((prev) => [...prev, ...Array.from(files).map((f) => f.name)]);
  };

  const handleSubmit = () => {
    toast.success(`Projeto "${address}" criado com sucesso!`, {
      description: "Card de projeto, pasta de arquivos e sala de chat foram criados automaticamente.",
    });
    setPhase(1);
    setAddress(""); setWidth(""); setLength(""); setServiceType("");
    setHasSecondFloor(false); setHasBasement(false); setHasAttic(false);
    setRenderRooms([]); setSelectedExtras([]); setRushFee(false);
    setSelectedRooms([]); setOverview(""); setUploadedFiles([]);
    onOpenChange(false);
  };

  const handleClose = (val: boolean) => {
    if (!val) setPhase(1);
    onOpenChange(val);
  };

  const fmt = (n: number) => `$ ${n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {phase === 1 ? "📐 Novo Estimate" : "📋 Detalhamento do Projeto"}
          </DialogTitle>
          <DialogDescription>
            {phase === 1
              ? "Insira as dimensões e opções para calcular o Design Fee em tempo real."
              : "Detalhe os requisitos do programa e envie arquivos de referência."}
          </DialogDescription>
        </DialogHeader>

        {/* Step indicator */}
        <div className="flex items-center gap-3 my-2">
          <div className={`flex items-center gap-2 text-sm font-medium ${phase >= 1 ? "text-primary" : "text-muted-foreground"}`}>
            <div className={`h-7 w-7 rounded-full flex items-center justify-center text-xs font-bold ${phase >= 1 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
              {phase > 1 ? <Check className="h-3.5 w-3.5" /> : "1"}
            </div>
            Estimate
          </div>
          <div className="flex-1 h-px bg-border" />
          <div className={`flex items-center gap-2 text-sm font-medium ${phase >= 2 ? "text-primary" : "text-muted-foreground"}`}>
            <div className={`h-7 w-7 rounded-full flex items-center justify-center text-xs font-bold ${phase >= 2 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
              2
            </div>
            Detalhamento
          </div>
        </div>

        <AnimatePresence mode="wait">
          {phase === 1 ? (
            <motion.div key="phase1" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-[1fr_280px] gap-5">
                {/* Left: inputs */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /> Endereço do Projeto</Label>
                    <Input placeholder="Ex: 41 Bowdoin Ave - Dorchester, MA" value={address} onChange={(e) => setAddress(e.target.value)} />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label>Width (ft)</Label>
                      <Input type="number" placeholder="Ex: 50" value={width} onChange={(e) => setWidth(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label>Length (ft)</Label>
                      <Input type="number" placeholder="Ex: 40" value={length} onChange={(e) => setLength(e.target.value)} />
                    </div>
                  </div>

                  {/* Levels */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Níveis do Projeto</Label>
                    <div className="grid grid-cols-3 gap-3">
                      <label className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer transition-colors text-sm ${hasSecondFloor ? "border-primary bg-primary/5" : "border-border"}`}>
                        <Switch checked={hasSecondFloor} onCheckedChange={setHasSecondFloor} /> 2nd Floor
                      </label>
                      <label className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer transition-colors text-sm ${hasBasement ? "border-primary bg-primary/5" : "border-border"}`}>
                        <Switch checked={hasBasement} onCheckedChange={setHasBasement} /> Basement
                      </label>
                      <label className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer transition-colors text-sm ${hasAttic ? "border-primary bg-primary/5" : "border-border"}`}>
                        <Switch checked={hasAttic} onCheckedChange={setHasAttic} /> Attic
                      </label>
                    </div>
                  </div>

                  {/* Service type */}
                  <div className="space-y-2">
                    <Label className="flex items-center gap-1.5"><Hammer className="h-3.5 w-3.5" /> Project Scope</Label>
                    <Select value={serviceType} onValueChange={setServiceType}>
                      <SelectTrigger><SelectValue placeholder="Selecione o tipo de serviço" /></SelectTrigger>
                      <SelectContent>
                        {serviceTypes.map((st) => (
                          <SelectItem key={st.value} value={st.value}>
                            {st.label} ({st.multiplier === 1 ? "Base" : `+${Math.round((st.multiplier - 1) * 100)}%`})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Design Extras */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Design Extras</Label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      {designExtras.map((extra) => (
                        <label
                          key={extra.id}
                          className={`flex items-center gap-2.5 p-3 rounded-lg border cursor-pointer transition-colors text-sm ${
                            selectedExtras.includes(extra.id)
                              ? "border-primary bg-primary/5 text-foreground font-medium"
                              : "border-border text-muted-foreground hover:bg-secondary/50"
                          }`}
                        >
                          <Checkbox checked={selectedExtras.includes(extra.id)} onCheckedChange={() => toggleExtra(extra.id)} />
                          <extra.icon className="h-4 w-4 shrink-0" />
                          <span className="text-xs">{extra.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* 3D Renderings */}
                  <div className="space-y-2">
                    <Label className="flex items-center gap-1.5"><Cuboid className="h-3.5 w-3.5" /> 3D Interior Rendering (+$350/amb.)</Label>
                    <div className="flex flex-wrap gap-2">
                      {renderableRooms.map((room) => (
                        <label
                          key={room}
                          className={`flex items-center gap-2 px-3 py-2 rounded-lg border cursor-pointer transition-colors text-xs ${
                            renderRooms.includes(room)
                              ? "border-primary bg-primary/5 text-foreground font-medium"
                              : "border-border text-muted-foreground hover:bg-secondary/50"
                          }`}
                        >
                          <Checkbox checked={renderRooms.includes(room)} onCheckedChange={() => toggleRenderRoom(room)} />
                          {room}
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Rush */}
                  <label className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${rushFee ? "border-primary bg-primary/5" : "border-border"}`}>
                    <Switch checked={rushFee} onCheckedChange={setRushFee} />
                    <div>
                      <span className="text-sm font-medium flex items-center gap-1.5"><Zap className="h-3.5 w-3.5" /> Rush Fee (Prazo Urgente)</span>
                      <span className="text-xs text-muted-foreground">+20% sobre o valor total</span>
                    </div>
                  </label>
                </div>

                {/* Right: estimate breakdown */}
                <Card className="border bg-secondary/30 self-start sticky top-4">
                  <CardContent className="pt-5 space-y-3">
                    <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                      <Calculator className="h-4 w-4" /> Estimated Design Fee
                    </div>
                    <div className="text-3xl font-display font-bold text-primary">
                      {estimate ? fmt(estimate.total) : "—"}
                    </div>
                    {estimate && (
                      <>
                        <Separator />
                        <div className="text-xs space-y-1.5 text-muted-foreground">
                          <p className="font-medium text-foreground text-[11px] uppercase tracking-wider">Breakdown</p>
                          <div className="flex justify-between">
                            <span>Ground Floor ({estimate.baseArea.toLocaleString()} sqft × $1.60)</span>
                            <span className="text-foreground font-medium">{fmt(estimate.groundCost)}</span>
                          </div>
                          {estimate.secondCost > 0 && (
                            <div className="flex justify-between">
                              <span>2nd Floor × $1.10</span>
                              <span className="text-foreground font-medium">{fmt(estimate.secondCost)}</span>
                            </div>
                          )}
                          {estimate.basementCost > 0 && (
                            <div className="flex justify-between">
                              <span>Basement × $0.80</span>
                              <span className="text-foreground font-medium">{fmt(estimate.basementCost)}</span>
                            </div>
                          )}
                          {estimate.atticCost > 0 && (
                            <div className="flex justify-between">
                              <span>Attic × $0.80</span>
                              <span className="text-foreground font-medium">{fmt(estimate.atticCost)}</span>
                            </div>
                          )}
                          {estimate.multiplier !== 1 && (
                            <div className="flex justify-between">
                              <span>Scope: {estimate.scopeLabel}</span>
                              <span className="text-foreground font-medium">×{estimate.multiplier.toFixed(2)}</span>
                            </div>
                          )}
                          {selectedExtras.length > 0 && (
                            <>
                              <Separator className="my-1" />
                              <div className="flex justify-between">
                                <span>Design Extras ({selectedExtras.length})</span>
                                <span className="text-foreground font-medium">Incluído</span>
                              </div>
                            </>
                          )}
                          {estimate.renderTotal > 0 && (
                            <>
                              <Separator className="my-1" />
                              <div className="flex justify-between">
                                <span>3D Rendering ({estimate.renderCount} amb.)</span>
                                <span className="text-foreground font-medium">{fmt(estimate.renderTotal)}</span>
                              </div>
                            </>
                          )}
                          {estimate.rushAmount > 0 && (
                            <div className="flex justify-between">
                              <span>Rush Fee (+20%)</span>
                              <span className="text-foreground font-medium">{fmt(estimate.rushAmount)}</span>
                            </div>
                          )}
                          <Separator className="my-1" />
                          <div className="flex justify-between text-sm font-semibold text-foreground">
                            <span>Total</span>
                            <span>{fmt(estimate.total)}</span>
                          </div>
                          <p className="text-[10px] pt-1">Total area: {estimate.totalArea.toLocaleString()} sqft</p>
                        </div>
                      </>
                    )}
                    <Badge variant="outline" className="text-[11px] bg-primary/10 text-primary border-primary/20">
                      Estimate preliminar
                    </Badge>
                  </CardContent>
                </Card>
              </div>

              <div className="flex justify-end pt-2">
                <Button className="gap-2" disabled={!phase1Valid} onClick={() => setPhase(2)}>
                  Aprovar e Detalhar Projeto <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </motion.div>
          ) : (
            <motion.div key="phase2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="space-y-4">
              <div className="space-y-2">
                <Label className="font-medium">Program Requirements</Label>
                <p className="text-xs text-muted-foreground mb-2">Selecione os cômodos necessários:</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {rooms.map((room) => (
                    <label
                      key={room}
                      className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer transition-colors text-sm ${
                        selectedRooms.includes(room)
                          ? "border-primary bg-primary/5 text-foreground"
                          : "border-border hover:bg-secondary/50 text-muted-foreground"
                      }`}
                    >
                      <Checkbox checked={selectedRooms.includes(room)} onCheckedChange={() => toggleRoom(room)} />
                      {room}
                    </label>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Project Overview</Label>
                <Textarea placeholder="Descreva o projeto, necessidades especiais, estilo desejado, referências..." rows={4} value={overview} onChange={(e) => setOverview(e.target.value)} />
              </div>

              <div className="space-y-2">
                <Label>Upload de Arquivos</Label>
                <p className="text-xs text-muted-foreground">Fotos do local, plantas existentes, referências visuais</p>
                <div className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-secondary/30 transition-colors">
                  <input type="file" className="hidden" id="estimate-files" onChange={handleFileUpload} multiple accept="image/*,.pdf,.dwg" />
                  <label htmlFor="estimate-files" className="cursor-pointer">
                    <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">Clique para selecionar arquivos</p>
                  </label>
                </div>
                {uploadedFiles.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {uploadedFiles.map((f, i) => (
                      <Badge key={i} variant="secondary" className="text-xs">{f}</Badge>
                    ))}
                  </div>
                )}
              </div>

              {estimate && (
                <Card className="border bg-secondary/30">
                  <CardContent className="pt-4 flex items-center justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground">Estimated Design Fee</p>
                      <p className="text-xl font-display font-bold text-primary">{fmt(estimate.total)}</p>
                    </div>
                    <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 text-xs">
                      {estimate.totalArea.toLocaleString()} sqft
                    </Badge>
                  </CardContent>
                </Card>
              )}

              <div className="flex items-center justify-between pt-2">
                <Button variant="outline" className="gap-2" onClick={() => setPhase(1)}>
                  <ChevronLeft className="h-4 w-4" /> Voltar
                </Button>
                <Button className="gap-2" onClick={handleSubmit}>
                  <Check className="h-4 w-4" /> Submeter Projeto
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}
