import { useState } from "react";
import { Upload, Check } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

interface RevisionTicketModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  projectAddress: string;
  projectFiles: Array<{ name: string }>;
}

const alterationTypes = [
  { value: "layout", label: "Layout" },
  { value: "medidas", label: "Medidas" },
  { value: "materiais", label: "Materiais" },
  { value: "acabamentos", label: "Acabamentos" },
  { value: "outros", label: "Outros" },
];

let ticketCounter = 1;

function generateProtocol(address: string) {
  const abbr = address.substring(0, 5).replace(/\s/g, "").toUpperCase();
  const num = String(ticketCounter++).padStart(3, "0");
  return `REV-${abbr}-${num}`;
}

export default function RevisionTicketModal({
  open,
  onOpenChange,
  projectAddress,
  projectFiles,
}: RevisionTicketModalProps) {
  const [referenceFile, setReferenceFile] = useState("");
  const [alterationType, setAlterationType] = useState("");
  const [description, setDescription] = useState("");
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      setUploadedFiles(Array.from(files).map((f) => f.name));
    }
  };

  const handleSubmit = () => {
    const protocol = generateProtocol(projectAddress);
    toast.success(`Ticket de revisão ${protocol} criado!`, {
      description: `Projeto "${projectAddress}" alterado para status "Em Revisão".`,
    });
    setReferenceFile("");
    setAlterationType("");
    setDescription("");
    setUploadedFiles([]);
    onOpenChange(false);
  };

  const isValid = alterationType && description.trim();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">🎫 Solicitação de Revisão</DialogTitle>
          <DialogDescription>{projectAddress}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          <div className="space-y-2">
            <Label>Arquivo de Referência</Label>
            <Select value={referenceFile} onValueChange={setReferenceFile}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o arquivo" />
              </SelectTrigger>
              <SelectContent>
                {projectFiles.map((f) => (
                  <SelectItem key={f.name} value={f.name}>
                    {f.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Tipo de Alteração</Label>
            <Select value={alterationType} onValueChange={setAlterationType}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o tipo" />
              </SelectTrigger>
              <SelectContent>
                {alterationTypes.map((t) => (
                  <SelectItem key={t.value} value={t.value}>
                    {t.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Descrição Detalhada</Label>
            <Textarea
              placeholder="Descreva as alterações necessárias..."
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label>Marcações à Mão</Label>
            <p className="text-xs text-muted-foreground">Fotos ou prints com suas anotações</p>
            <div className="border-2 border-dashed rounded-lg p-4 text-center cursor-pointer hover:bg-secondary/30 transition-colors">
              <input
                type="file"
                className="hidden"
                id="revision-files"
                onChange={handleFileUpload}
                multiple
                accept="image/*,.pdf"
              />
              <label htmlFor="revision-files" className="cursor-pointer">
                <Upload className="h-6 w-6 mx-auto text-muted-foreground mb-1" />
                <p className="text-sm text-muted-foreground">Clique para enviar</p>
              </label>
            </div>
            {uploadedFiles.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-1">
                {uploadedFiles.map((f, i) => (
                  <Badge key={i} variant="secondary" className="text-xs">
                    {f}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="flex gap-2 justify-end pt-1">
            <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button size="sm" className="gap-1.5" disabled={!isValid} onClick={handleSubmit}>
              <Check className="h-3.5 w-3.5" /> Enviar Ticket
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
