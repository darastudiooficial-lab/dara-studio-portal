

## Formulário de Orçamento Rápido — Plano de Implementação

### Layout
- Duas colunas no desktop (65/35), coluna única no mobile com painel sticky no topo
- Design minimalista com cores claras, acentos em tons terrosos/dourados (#B8860B / amber)
- Tipografia limpa, cards com sombras suaves

### Coluna Esquerda — Formulário
Seções com cards:
1. **Informações de Contato** — Nome (text input)
2. **Detalhes do Projeto** — Tipo (dropdown: Residencial, Comercial, Reforma), Área em m² (number input)
3. **Serviços Desejados** — Checkboxes: Planta Baixa, Design de Interiores, Aprovação na Prefeitura, Renderização 3D
4. **Localização** — CEP ou Cidade (text input)
5. **Botão** "Solicitar Proposta Completa" em tom dourado

### Coluna Direita — Painel Sticky de Orçamento
- Título "Estimativa Prévia de Custo"
- Valor dinâmico em R$ com faixa (±10%)
- Barra de Confiança (progresso 0-100%) baseada nos campos preenchidos
- Nível de Complexidade (Baixa/Média/Alta)
- Texto motivacional: "Adicione mais detalhes para melhorar a precisão"

### Lógica de Cálculo (simulada no state)
- Custo base = área × R$ 50
- Planta Baixa: +R$ 500 | Design de Interiores: +R$ 1.000 | Aprovação Prefeitura: +R$ 800 | Renderização 3D: +R$ 1.500
- Comercial: multiplicador 1.3x | Reforma: 1.2x
- Exibe faixa: valor -10% ~ valor +10%
- Confiança: nome (+20%), tipo (+15%), área (+25%), serviços (+25%), localização (+15%)
- Complexidade: 0-1 serviço = Baixa, 2 = Média, 3+ = Alta

### Responsivo
- Mobile: painel de orçamento aparece como card fixo no topo ou seção colapsável antes do formulário

