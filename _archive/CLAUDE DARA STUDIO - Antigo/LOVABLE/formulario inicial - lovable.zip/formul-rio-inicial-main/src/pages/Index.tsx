import { useState, useMemo, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight } from "lucide-react";
import StepperNav, { STEPS } from "@/components/wizard/StepperNav";
import EstimateSidebar, { type LineItem } from "@/components/wizard/EstimateSidebar";
import LocationStep, { type LocationData } from "@/components/wizard/steps/LocationStep";
import AboutYouStep, { type AboutData } from "@/components/wizard/steps/AboutYouStep";
import DetailsStep from "@/components/wizard/steps/DetailsStep";
import ProjectScopeStep, { type ScopeData } from "@/components/wizard/steps/ProjectScopeStep";
import FilesStep from "@/components/wizard/steps/FilesStep";
import ReviewStep from "@/components/wizard/steps/ReviewStep";

const TYPE_LABELS: Record<string, string> = {
  deck: "Deck / Porch / Outdoor",
  kitchen: "Kitchen Remodel",
  bath: "Bath Remodel",
  laundry: "Laundry Remodel",
  interior: "Interior Renovation",
  single_family: "Single Family Residential",
  multi_family: "Multi-Family Residential",
  adu: "ADU",
  commercial: "Small Commercial Building",
  garage: "Garage",
  addition: "Home Addition",
  custom_home: "Custom Home",
  "3d_viz": "3D Visualization",
};

const BUSINESS_ROLES = ["Builder / Contractor", "Architect", "Developer"];

interface FormData {
  location: LocationData;
  about: AboutData;
  details: { width: string; length: string; levels: string[] };
  scope: ScopeData;
  files: File[];
}

const INITIAL: FormData = {
  location: { region: "", street1: "", street2: "", city: "", state: "", zip: "" },
  about: { name: "", email: "", phone: "", role: "", companyName: "", companyWebsite: "", companyStreet: "", companyCity: "", companyState: "", companyZip: "" },
  details: { width: "", length: "", levels: ["ground"] },
  scope: {
    types: [],
    engagement: "",
    designExtras: [],
    viz3dExterior: false,
    viz3dInterior: false,
    room3d: [],
  },
  files: [],
};

export default function Index() {
  const [step, setStep] = useState(0);
  const [data, setData] = useState<FormData>(INITIAL);

  const update = useCallback(
    <K extends keyof FormData>(section: K) =>
      (partial: Partial<FormData[K]>) =>
        setData((prev) => ({ ...prev, [section]: { ...prev[section], ...partial } })),
    []
  );

  const isBR = data.location.region === "br";
  const currency = isBR ? "R$" : "$";
  const unit = isBR ? "m" : "ft";
  const areaUnit = isBR ? "m²" : "sqft";

  // ── Estimate logic ──
  const { low, high, confidence, complexity, breakdown } = useMemo(() => {
    const w = parseFloat(data.details.width) || 0;
    const l = parseFloat(data.details.length) || 0;
    const baseArea = w * l;

    const eng = data.scope.engagement;
    const isFull = eng === "full";
    const isPlans = eng === "plans_only";

    const items: LineItem[] = [];
    let total = 0;

    if (baseArea > 0 && (isFull || isPlans)) {
      if (isPlans) {
        const plansCost = baseArea * 0.8;
        total += plansCost;
        items.push({ label: `Floor Plans Only (${baseArea.toLocaleString()} ${areaUnit} × $0.80)`, value: plansCost });
      } else {
        const groundCost = baseArea * 1.6;
        total += groundCost;
        items.push({ label: `Ground Floor (${baseArea.toLocaleString()} ${areaUnit} × $1.60)`, value: groundCost });

        if (data.details.levels.includes("2nd")) {
          const cost2nd = baseArea * 1.1;
          total += cost2nd;
          items.push({ label: `2nd Floor (${baseArea.toLocaleString()} ${areaUnit} × $1.10)`, value: cost2nd });
        }
        if (data.details.levels.includes("basement")) {
          const costBsmt = baseArea * 0.8;
          total += costBsmt;
          items.push({ label: `Basement (${baseArea.toLocaleString()} ${areaUnit} × $0.80)`, value: costBsmt });
        }
        if (data.details.levels.includes("attic")) {
          const costAttic = baseArea * 0.6;
          total += costAttic;
          items.push({ label: `Attic (${baseArea.toLocaleString()} ${areaUnit} × $0.60)`, value: costAttic });
        }
      }
    } else if (baseArea > 0 && !eng) {
      const baseCost = baseArea * 1.6;
      total += baseCost;
      items.push({ label: `Base (${baseArea.toLocaleString()} ${areaUnit} × $1.60)`, value: baseCost });
    }

    // 3D Exterior
    if (data.scope.viz3dExterior) {
      if (isFull) {
        items.push({ label: "3D Exterior Rendering", value: 0, included: true });
      } else {
        total += 450;
        items.push({ label: "3D Exterior Rendering", value: 450 });
      }
    }

    // Per-room 3D
    for (const room of data.scope.room3d) {
      const roomLabel = room === "kitchen" ? "3D Kitchen Design" : room === "bathroom" ? "3D Bathroom Design" : "3D Laundry Design";
      total += 350;
      items.push({ label: roomLabel, value: 350 });
    }

    total = Math.round(total);
    const lowVal = Math.round(total * 0.9);
    const highVal = Math.round(total * 1.1);

    // Confidence — expanded to account for new fields
    let conf = 0;
    if (data.location.region) conf += 8;
    if (data.location.city.trim()) conf += 3;
    if (data.location.state.trim()) conf += 2;
    if (data.location.zip.trim()) conf += 2;
    if (data.about.name.trim()) conf += 10;
    if (data.about.email.trim()) conf += 5;
    if (data.about.role) conf += 5;
    // Business role bonus: professional clients = more reliable data
    if (BUSINESS_ROLES.includes(data.about.role)) conf += 5;
    if (data.about.companyName?.trim()) conf += 3;
    if (baseArea > 0) conf += 20;
    if (data.details.levels.length > 1) conf += 5;
    if (data.scope.types.length) conf += 10;
    if (eng) conf += 12;
    if (data.files.length) conf += 5;
    conf += Math.min(step * 2, 10);
    conf = Math.min(conf, 100);

    // Complexity
    const svcCount = data.scope.designExtras.length + (data.scope.viz3dExterior ? 1 : 0) + (data.scope.viz3dInterior ? 1 : 0) + data.scope.room3d.length;
    const cplx = isFull ? "High" : svcCount >= 2 ? "Moderate" : isPlans ? "Low" : "—";

    return { low: lowVal, high: highVal, confidence: conf, complexity: cplx, breakdown: items };
  }, [data, step, areaUnit]);

  const baseArea = (parseFloat(data.details.width) || 0) * (parseFloat(data.details.length) || 0);

  // ── Step renderer ──
  const renderStep = () => {
    switch (step) {
      case 0:
        return <LocationStep data={data.location} onChange={update("location")} />;
      case 1:
        return <AboutYouStep data={data.about} region={data.location.region} onChange={update("about")} />;
      case 2:
        return <DetailsStep data={data.details} unit={unit} onChange={update("details")} />;
      case 3:
        return <ProjectScopeStep data={data.scope} onChange={update("scope")} />;
      case 4:
        return <FilesStep files={data.files} onChange={(files) => setData((prev) => ({ ...prev, files }))} />;
      case 5:
        return (
          <ReviewStep
            summary={{
              name: data.about.name,
              email: data.about.email,
              phone: data.about.phone,
              city: data.location.city,
              state: data.location.state,
              region: data.location.region,
              width: data.details.width,
              length: data.details.length,
              area: baseArea,
              areaUnit,
              unit,
              levels: data.details.levels,
              types: data.scope.types.map((t) => TYPE_LABELS[t] || t),
              engagement: data.scope.engagement,
              designExtras: data.scope.designExtras,
              viz3dExterior: data.scope.viz3dExterior,
              room3d: data.scope.room3d,
              filesCount: data.files.length,
              estimateRange: high > 0 ? `${currency}${low.toLocaleString()} – ${currency}${high.toLocaleString()}` : `${currency}0`,
            }}
          />
        );
      default:
        return null;
    }
  };

  const isLast = step === STEPS.length - 1;

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'hsl(var(--section-background))' }}>
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <StepperNav currentStep={step} />
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-8 items-start">
          <div className="order-2 lg:order-1">
            <div className="bg-card rounded-xl border p-6 sm:p-8 shadow-[0_1px_3px_0_rgb(0_0_0/0.04)] min-h-[420px]">
              {renderStep()}
            </div>

            {!isLast && (
              <div className="flex justify-between mt-6">
                <Button
                  variant="outline"
                  onClick={() => setStep((s) => Math.max(0, s - 1))}
                  disabled={step === 0}
                  className="gap-2"
                >
                  <ArrowLeft className="h-4 w-4" /> Back
                </Button>
                <Button onClick={() => setStep((s) => Math.min(STEPS.length - 1, s + 1))} className="gap-2">
                  Next <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            )}

            {isLast && (
              <div className="flex justify-start mt-6">
                <Button
                  variant="outline"
                  onClick={() => setStep((s) => Math.max(0, s - 1))}
                  className="gap-2"
                >
                  <ArrowLeft className="h-4 w-4" /> Back
                </Button>
              </div>
            )}
          </div>

          <div className="order-1 lg:order-2 lg:sticky lg:top-24">
            <EstimateSidebar
              low={low}
              high={high}
              confidence={confidence}
              complexity={complexity}
              currency={currency}
              breakdown={breakdown}
            />
          </div>
        </div>
      </main>
    </div>
  );
}
