import { Progress } from "@/components/ui/progress";
import { TrendingUp } from "lucide-react";

export interface LineItem {
  label: string;
  value: number;
  included?: boolean; // show "Included" instead of price
}

interface EstimateSidebarProps {
  low: number;
  high: number;
  confidence: number;
  complexity: string;
  currency: string;
  breakdown: LineItem[];
}

function fmt(v: number, currency: string) {
  const safe = Number.isFinite(v) ? v : 0;
  const code = currency === "R$" ? "BRL" : "USD";
  return safe.toLocaleString(code === "BRL" ? "pt-BR" : "en-US", {
    style: "currency",
    currency: code,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  });
}

export default function EstimateSidebar({ low, high, confidence, complexity, currency, breakdown }: EstimateSidebarProps) {
  return (
    <div className="rounded-xl border bg-card shadow-[0_2px_8px_0_rgb(0_0_0/0.06)] p-6 space-y-6">
      <p className="text-[11px] font-bold tracking-[0.15em] uppercase text-primary">
        Estimated Design Fee
      </p>

      <div className="text-center py-5 rounded-lg bg-secondary/50">
        {high === 0 ? (
          <p className="text-3xl font-bold text-muted-foreground">{currency}0</p>
        ) : (
          <p className="text-3xl font-extrabold text-foreground tracking-tight">
            {fmt(low, currency)}{" "}
            <span className="text-muted-foreground font-normal text-xl">–</span>{" "}
            {fmt(high, currency)}
          </p>
        )}
      </div>

      <p className="text-[11px] text-muted-foreground leading-relaxed">
        *Approximate estimate. Final pricing may vary based on project complexity.
      </p>

      {/* Cost Breakdown */}
      {breakdown.length > 0 && (
        <div className="space-y-1.5 border-t pt-4">
          <p className="text-[11px] font-bold tracking-[0.1em] uppercase text-muted-foreground mb-2">Cost Breakdown</p>
          {breakdown.map((item, i) => (
            <div key={i} className="flex justify-between text-sm">
              <span className="text-muted-foreground">{item.label}</span>
              <span className="font-semibold text-foreground">
                {item.included ? (
                  <span className="text-primary text-xs font-bold">Included</span>
                ) : (
                  fmt(item.value, currency)
                )}
              </span>
            </div>
          ))}
        </div>
      )}

      <div className="flex justify-between items-center text-sm border-t pt-4">
        <span className="text-muted-foreground font-medium">Project Complexity</span>
        <span className="font-bold text-foreground">{complexity}</span>
      </div>

      <div className="space-y-2 border-t pt-4">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground font-medium flex items-center gap-1.5">
            <TrendingUp className="h-4 w-4" />
            Estimate Confidence
          </span>
          <span className="font-semibold text-foreground">{confidence}%</span>
        </div>
        <Progress value={confidence} className="h-2.5" />
        {confidence < 80 && (
          <p className="text-xs text-muted-foreground italic">
            Add more project details to improve accuracy.
          </p>
        )}
      </div>
    </div>
  );
}
