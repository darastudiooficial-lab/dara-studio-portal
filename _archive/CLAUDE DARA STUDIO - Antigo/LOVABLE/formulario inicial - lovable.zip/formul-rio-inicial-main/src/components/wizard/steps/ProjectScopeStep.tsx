import { cn } from "@/lib/utils";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Home, Warehouse, UtensilsCrossed, Bath, PaintBucket, Fence,
  Building2, Building, Plus, Cuboid, ShowerHead, Box, Eye,
} from "lucide-react";

const TYPES = [
  { id: "deck", label: "Deck / Porch / Outdoor", icon: Fence },
  { id: "kitchen", label: "Kitchen Remodel", icon: UtensilsCrossed },
  { id: "bath", label: "Bath Remodel", icon: Bath },
  { id: "laundry", label: "Laundry Remodel", icon: ShowerHead },
  { id: "interior", label: "Interior Renovation", icon: PaintBucket },
  { id: "single_family", label: "Single Family Residential", icon: Home },
  { id: "multi_family", label: "Multi-Family Residential", icon: Building },
  { id: "adu", label: "ADU", icon: Box },
  { id: "commercial", label: "Small Commercial Building", icon: Building2 },
  { id: "garage", label: "Garage", icon: Warehouse },
  { id: "addition", label: "Home Addition", icon: Plus },
  { id: "custom_home", label: "Custom Home", icon: Cuboid },
  { id: "3d_viz", label: "3D Visualization", icon: Eye },
];

export interface ScopeData {
  types: string[];
  engagement: "full" | "plans_only" | "";
  designExtras: string[];   // arch_design, space_planning, interior_layout
  viz3dExterior: boolean;
  viz3dInterior: boolean;
  room3d: string[];         // kitchen, bathroom, laundry
}

interface Props {
  data: ScopeData;
  onChange: (d: Partial<ScopeData>) => void;
}

export default function ProjectScopeStep({ data, onChange }: Props) {
  const isFull = data.engagement === "full";
  const isPlans = data.engagement === "plans_only";

  const toggleType = (id: string) => {
    const next = data.types.includes(id)
      ? data.types.filter((t) => t !== id)
      : [...data.types, id];
    onChange({ types: next });
  };

  const toggleDesignExtra = (id: string) => {
    const next = data.designExtras.includes(id)
      ? data.designExtras.filter((t) => t !== id)
      : [...data.designExtras, id];
    onChange({ designExtras: next });
  };

  const toggleRoom3d = (id: string) => {
    const next = data.room3d.includes(id)
      ? data.room3d.filter((t) => t !== id)
      : [...data.room3d, id];
    onChange({ room3d: next });
  };

  const handleEngagementChange = (val: string) => {
    const eng = val as ScopeData["engagement"];
    // Reset dependent state when switching
    onChange({
      engagement: eng,
      designExtras: eng === "full" ? data.designExtras : [],
      viz3dExterior: data.viz3dExterior,
    });
  };

  return (
    <div className="space-y-10">
      {/* Section A: Project Type */}
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-1">Project Scope</h2>
        <p className="text-muted-foreground text-sm">Define your project type and select the services you need.</p>
      </div>

      <div>
        <Label className="text-sm font-semibold mb-3 block">What type of project?</Label>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {TYPES.map((t) => {
            const selected = data.types.includes(t.id);
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => toggleType(t.id)}
                className={cn(
                  "flex flex-col items-center gap-2 rounded-xl border-2 p-4 transition-all",
                  selected
                    ? "border-primary bg-primary/5 shadow-sm"
                    : "border-border hover:border-muted-foreground/30"
                )}
              >
                <t.icon className={cn("h-6 w-6", selected ? "text-primary" : "text-muted-foreground")} />
                <span className={cn("text-xs font-medium text-center leading-tight", selected ? "text-foreground" : "text-muted-foreground")}>
                  {t.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Section B: Services */}
      <div className="space-y-8">
        <div>
          <Label className="text-lg font-bold mb-1 block text-foreground">Services Needed</Label>
          <p className="text-muted-foreground text-sm">Choose your engagement level and add-on services.</p>
        </div>

        {/* Group 1: Core Engagement */}
        <div>
          <Label className="text-sm font-semibold mb-3 block">Core Engagement</Label>
          <RadioGroup value={data.engagement} onValueChange={handleEngagementChange} className="space-y-2">
            <label className={cn(
              "flex items-start gap-3 rounded-lg border-2 px-4 py-4 cursor-pointer transition-colors",
              isFull ? "border-primary bg-primary/5" : "border-border hover:border-muted-foreground/30"
            )}>
              <RadioGroupItem value="full" className="mt-0.5" />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-foreground">Full Construction</span>
                  <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-destructive/10 text-destructive">High Complexity</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">$1.60/sqft base + floor additions. Unlocks all design extras and includes 3D Exterior Rendering for free.</p>
              </div>
            </label>

            <label className={cn(
              "flex items-start gap-3 rounded-lg border-2 px-4 py-4 cursor-pointer transition-colors",
              isPlans ? "border-primary bg-primary/5" : "border-border hover:border-muted-foreground/30"
            )}>
              <RadioGroupItem value="plans_only" className="mt-0.5" />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-foreground">Floor Plans Only</span>
                  <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-muted text-muted-foreground">Low Complexity</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">$0.80/sqft simplified base. Floor-level additions are not applied. 3D Exterior Rendering available as a paid add-on.</p>
              </div>
            </label>
          </RadioGroup>
        </div>

        {/* Group 2: Design Extras (Full only) */}
        {isFull && (
          <div>
            <Label className="text-sm font-semibold mb-3 block">Design Extras</Label>
            <div className="space-y-2">
              {[
                { id: "arch_design", label: "Architectural Design" },
                { id: "space_planning", label: "Space Planning" },
                { id: "interior_layout", label: "Interior Layout" },
              ].map((item) => (
                <label key={item.id} className={cn(
                  "flex items-center gap-3 rounded-lg border px-4 py-3 cursor-pointer transition-colors hover:bg-secondary/60",
                  data.designExtras.includes(item.id) && "border-primary bg-primary/5"
                )}>
                  <Checkbox
                    checked={data.designExtras.includes(item.id)}
                    onCheckedChange={() => toggleDesignExtra(item.id)}
                  />
                  <span className="text-sm font-medium">{item.label}</span>
                  <span className="ml-auto text-xs text-muted-foreground">Included</span>
                </label>
              ))}
            </div>
          </div>
        )}

        {/* Group 3: 3D Exterior Rendering */}
        {(isFull || isPlans) && (
          <div>
            <Label className="text-sm font-semibold mb-3 block">3D Visualization</Label>
            <div className="space-y-2">
              <label className={cn(
                "flex items-center gap-3 rounded-lg border px-4 py-3 cursor-pointer transition-colors hover:bg-secondary/60",
                data.viz3dExterior && "border-primary bg-primary/5"
              )}>
                <Checkbox
                  checked={data.viz3dExterior}
                  onCheckedChange={(c) => onChange({ viz3dExterior: !!c })}
                />
                <span className="text-sm font-medium">3D Exterior Rendering</span>
                <span className={cn("ml-auto text-xs font-semibold", isFull ? "text-green-600" : "text-foreground")}>
                  {isFull ? "Included — FREE" : "+$450.00"}
                </span>
              </label>
            </div>
          </div>
        )}

        {/* Group 4: Per-Room 3D Design */}
        {(isFull || isPlans) && (
          <div>
            <Label className="text-sm font-semibold mb-3 block">Per-Room 3D Design</Label>
            <div className="space-y-2">
              {[
                { id: "kitchen", label: "3D Kitchen Design", price: "$350" },
                { id: "bathroom", label: "3D Bathroom Design", price: "$350" },
                { id: "laundry", label: "3D Laundry Design", price: "$350" },
              ].map((item) => (
                <label key={item.id} className={cn(
                  "flex items-center gap-3 rounded-lg border px-4 py-3 cursor-pointer transition-colors hover:bg-secondary/60",
                  data.room3d.includes(item.id) && "border-primary bg-primary/5"
                )}>
                  <Checkbox
                    checked={data.room3d.includes(item.id)}
                    onCheckedChange={() => toggleRoom3d(item.id)}
                  />
                  <span className="text-sm font-medium">{item.label}</span>
                  <span className="ml-auto text-xs font-semibold text-foreground">+{item.price}</span>
                </label>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
