import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { useCallback } from "react";
import { Building2 } from "lucide-react";

const ROLES = ["Homeowner", "Builder / Contractor", "Architect", "Developer"];
const BUSINESS_ROLES = ["Builder / Contractor", "Architect", "Developer"];

export interface AboutData {
  name: string;
  email: string;
  phone: string;
  role: string;
  companyName: string;
  companyWebsite: string;
  companyStreet: string;
  companyCity: string;
  companyState: string;
  companyZip: string;
}

interface Props {
  data: AboutData;
  region: string;
  onChange: (d: Partial<AboutData>) => void;
}

function formatUSPhone(raw: string): string {
  const d = raw.replace(/\D/g, "").slice(0, 11);
  if (d.length === 0) return "";
  if (d.length <= 1) return `+${d}`;
  if (d.length <= 4) return `+${d[0]} (${d.slice(1)}`;
  if (d.length <= 7) return `+${d[0]} (${d.slice(1, 4)}) ${d.slice(4)}`;
  return `+${d[0]} (${d.slice(1, 4)}) ${d.slice(4, 7)}-${d.slice(7)}`;
}

function formatBRPhone(raw: string): string {
  const d = raw.replace(/\D/g, "").slice(0, 13);
  if (d.length === 0) return "";
  if (d.length <= 2) return `+${d}`;
  if (d.length <= 4) return `+${d.slice(0, 2)} (${d.slice(2)}`;
  if (d.length <= 9) return `+${d.slice(0, 2)} (${d.slice(2, 4)}) ${d.slice(4)}`;
  return `+${d.slice(0, 2)} (${d.slice(2, 4)}) ${d.slice(4, 9)}-${d.slice(9)}`;
}

export default function AboutYouStep({ data, region, onChange }: Props) {
  const isBR = region === "br";
  const showCompany = BUSINESS_ROLES.includes(data.role);

  const handlePhoneChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const raw = e.target.value;
      const formatted = isBR ? formatBRPhone(raw) : formatUSPhone(raw);
      onChange({ phone: formatted });
    },
    [isBR, onChange]
  );

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-1">Tell us about yourself</h2>
        <p className="text-muted-foreground text-sm">We'd love to know who we're working with.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="sm:col-span-2">
          <Label htmlFor="fullName">Full Name</Label>
          <Input id="fullName" placeholder="John Doe" value={data.name} onChange={(e) => onChange({ name: e.target.value })} className="mt-1.5" />
        </div>
        <div>
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" placeholder="john@example.com" value={data.email} onChange={(e) => onChange({ email: e.target.value })} className="mt-1.5" />
        </div>
        <div>
          <Label htmlFor="phone">Phone</Label>
          <Input
            id="phone"
            type="tel"
            placeholder={isBR ? "+55 (00) 00000-0000" : "+1 (000) 000-0000"}
            value={data.phone}
            onChange={handlePhoneChange}
            className="mt-1.5"
          />
        </div>
      </div>

      <div>
        <Label className="text-sm font-semibold mb-3 block">Who are you?</Label>
        <div className="flex flex-wrap gap-2">
          {ROLES.map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => onChange({ role: r })}
              className={cn(
                "px-5 py-2 rounded-full border text-sm font-medium transition-all",
                data.role === r
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-card text-foreground border-border hover:border-muted-foreground/40"
              )}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Conditional Company Information */}
      {showCompany && (
        <div className="space-y-4 rounded-xl border bg-card p-5">
          <div className="flex items-center gap-2 mb-1">
            <Building2 className="h-4 w-4 text-primary" />
            <Label className="text-sm font-semibold">Company Information</Label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="companyName" className="text-xs text-muted-foreground">Business Name</Label>
              <Input
                id="companyName"
                placeholder="e.g., Acme Architecture"
                value={data.companyName}
                onChange={(e) => onChange({ companyName: e.target.value })}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="companyWebsite" className="text-xs text-muted-foreground">Business Website</Label>
              <Input
                id="companyWebsite"
                placeholder="e.g., www.company.com"
                value={data.companyWebsite}
                onChange={(e) => onChange({ companyWebsite: e.target.value })}
                className="mt-1"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="companyStreet" className="text-xs text-muted-foreground">Company Street Address</Label>
            <Input
              id="companyStreet"
              placeholder="e.g., 456 Business Ave"
              value={data.companyStreet}
              onChange={(e) => onChange({ companyStreet: e.target.value })}
              className="mt-1"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="companyCity" className="text-xs text-muted-foreground">City</Label>
              <Input
                id="companyCity"
                placeholder="e.g., Boston"
                value={data.companyCity}
                onChange={(e) => onChange({ companyCity: e.target.value })}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="companyState" className="text-xs text-muted-foreground">State</Label>
              <Input
                id="companyState"
                placeholder="e.g., MA"
                value={data.companyState}
                onChange={(e) => onChange({ companyState: e.target.value })}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="companyZip" className="text-xs text-muted-foreground">Zip Code</Label>
              <Input
                id="companyZip"
                placeholder="e.g., 02101"
                value={data.companyZip}
                onChange={(e) => onChange({ companyZip: e.target.value })}
                className="mt-1"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
