import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MapPin } from "lucide-react";
import { cn } from "@/lib/utils";

const REGIONS = [
  { id: "us", label: "United States", sub: "USD — sqft", flag: "🇺🇸" },
  { id: "br", label: "Brazil", sub: "BRL — m²", flag: "🇧🇷" },
];

export interface LocationData {
  region: string;
  street1: string;
  street2: string;
  city: string;
  state: string;
  zip: string;
}

interface Props {
  data: LocationData;
  onChange: (d: Partial<LocationData>) => void;
}

export default function LocationStep({ data, onChange }: Props) {
  const isBR = data.region === "br";

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-1">Where is your project located?</h2>
        <p className="text-muted-foreground text-sm">Select your region and provide your project address.</p>
      </div>

      {/* Region selector */}
      <div>
        <Label className="text-sm font-semibold mb-3 block">Region</Label>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {REGIONS.map((r) => (
            <button
              key={r.id}
              type="button"
              onClick={() => onChange({ region: r.id })}
              className={cn(
                "flex items-center gap-4 rounded-xl border-2 p-5 text-left transition-all",
                data.region === r.id
                  ? "border-primary bg-primary/5 shadow-sm"
                  : "border-border hover:border-muted-foreground/30"
              )}
            >
              <span className="text-3xl">{r.flag}</span>
              <div>
                <p className="font-semibold text-foreground">{r.label}</p>
                <p className="text-xs text-muted-foreground">{r.sub}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Full address form — shown after region is selected */}
      {data.region && (
        <div className="space-y-4 rounded-xl border bg-card p-5">
          <div className="flex items-center gap-2 mb-1">
            <MapPin className="h-4 w-4 text-primary" />
            <Label className="text-sm font-semibold">Project Address</Label>
          </div>

          <div>
            <Label htmlFor="street1" className="text-xs text-muted-foreground">Street Address</Label>
            <Input
              id="street1"
              placeholder="e.g., 123 Main St"
              value={data.street1}
              onChange={(e) => onChange({ street1: e.target.value })}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="street2" className="text-xs text-muted-foreground">Street Address Line 2</Label>
            <Input
              id="street2"
              placeholder="Apartment, suite, unit, building, floor, etc."
              value={data.street2}
              onChange={(e) => onChange({ street2: e.target.value })}
              className="mt-1"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="city" className="text-xs text-muted-foreground">City</Label>
              <Input
                id="city"
                placeholder={isBR ? "e.g., São Paulo" : "e.g., Weston"}
                value={data.city}
                onChange={(e) => onChange({ city: e.target.value })}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="state" className="text-xs text-muted-foreground">
                {isBR ? "State" : "Region / State / Province"}
              </Label>
              <Input
                id="state"
                placeholder={isBR ? "e.g., SP" : "e.g., Massachusetts"}
                value={data.state}
                onChange={(e) => onChange({ state: e.target.value })}
                className="mt-1"
              />
            </div>
          </div>

          <div className="sm:w-1/2">
            <Label htmlFor="zip" className="text-xs text-muted-foreground">
              {isBR ? "CEP" : "Postal / Zip Code"}
            </Label>
            <Input
              id="zip"
              placeholder={isBR ? "e.g., 01310-100" : "e.g., 02493"}
              value={data.zip}
              onChange={(e) => onChange({ zip: e.target.value })}
              className="mt-1"
            />
          </div>
        </div>
      )}
    </div>
  );
}
