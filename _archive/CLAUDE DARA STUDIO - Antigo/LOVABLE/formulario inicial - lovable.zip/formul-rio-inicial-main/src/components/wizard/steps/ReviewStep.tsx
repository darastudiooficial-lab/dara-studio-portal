import { Button } from "@/components/ui/button";
import { CheckCircle2, Send, BookmarkPlus, Loader2 } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

const DESIGN_EXTRA_LABELS: Record<string, string> = {
  arch_design: "Architectural Design",
  space_planning: "Space Planning",
  interior_layout: "Interior Layout",
};

const ROOM_3D_LABELS: Record<string, string> = {
  kitchen: "3D Kitchen Design",
  bathroom: "3D Bathroom Design",
  laundry: "3D Laundry Design",
};

interface Props {
  summary: {
    name: string;
    email: string;
    phone: string;
    city: string;
    state: string;
    region: string;
    width: string;
    length: string;
    area: number;
    areaUnit: string;
    unit: string;
    levels: string[];
    types: string[];
    engagement: string;
    designExtras: string[];
    viz3dExterior: boolean;
    room3d: string[];
    filesCount: number;
    estimateRange: string;
  };
}

export default function ReviewStep({ summary }: Props) {
  const [status, setStatus] = useState<"idle" | "loading" | "accepted" | "saved">("idle");

  const handleAction = (action: "accept" | "save") => {
    setStatus("loading");
    setTimeout(() => setStatus(action === "accept" ? "accepted" : "saved"), 2000);
  };

  if (status === "accepted" || status === "saved") {
    return (
      <div className="flex flex-col items-center justify-center text-center py-12 space-y-5">
        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
          <CheckCircle2 className="h-8 w-8 text-primary" />
        </div>
        <h2 className="text-2xl font-bold text-foreground">Thank You, {summary.name.split(" ")[0] || "there"}!</h2>
        {status === "accepted" ? (
          <div className="max-w-md space-y-2">
            <p className="text-muted-foreground text-sm">Your estimate has been accepted. We've sent a confirmation email to <strong className="text-foreground">{summary.email}</strong>.</p>
            <p className="text-muted-foreground text-sm">A designer will reach out within 24 hours to start the full project briefing.</p>
          </div>
        ) : (
          <div className="max-w-md space-y-2">
            <p className="text-muted-foreground text-sm">We've emailed a copy of this estimate to <strong className="text-foreground">{summary.email}</strong>.</p>
            <p className="text-muted-foreground text-sm">Feel free to come back anytime when you're ready to proceed!</p>
          </div>
        )}
      </div>
    );
  }

  const isFull = summary.engagement === "full";
  const isPlans = summary.engagement === "plans_only";

  const levelLabels: Record<string, string> = {
    ground: "Ground Floor / Main Level",
    "2nd": "2nd Floor",
    basement: "Basement",
    attic: "Attic",
  };

  const addons: string[] = [];
  summary.designExtras.forEach((e) => {
    if (DESIGN_EXTRA_LABELS[e]) addons.push(DESIGN_EXTRA_LABELS[e]);
  });
  if (summary.viz3dExterior) {
    addons.push(isFull ? "3D Exterior Rendering (Included)" : "3D Exterior Rendering (+$450)");
  }
  summary.room3d.forEach((r) => {
    if (ROOM_3D_LABELS[r]) addons.push(`${ROOM_3D_LABELS[r]} (+$350)`);
  });

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-1">Review & Submit</h2>
        <p className="text-muted-foreground text-sm">Confirm your project details and estimated fee below.</p>
      </div>

      {/* Summary Sections */}
      <div className="space-y-6">
        {/* Client & Location */}
        <SummarySection title="Client & Location">
          <SummaryRow label="Name" value={summary.name || "—"} />
          <SummaryRow label="Email" value={summary.email || "—"} />
          <SummaryRow label="Phone" value={summary.phone || "—"} />
          <SummaryRow label="City" value={summary.city || "—"} />
          <SummaryRow label="State / Country" value={summary.state ? `${summary.state} (${summary.region === "br" ? "Brazil" : "United States"})` : "—"} />
        </SummarySection>

        {/* Project Dimensions */}
        <SummarySection title="Project Dimensions">
          <SummaryRow label={`Width (${summary.unit})`} value={summary.width || "—"} />
          <SummaryRow label={`Length (${summary.unit})`} value={summary.length || "—"} />
          <SummaryRow label="Total Base Area" value={summary.area > 0 ? `${summary.area.toLocaleString()} ${summary.areaUnit}` : "—"} />
          <SummaryRow label="Selected Floors" value={summary.levels.length ? summary.levels.map((l) => levelLabels[l] || l).join(", ") : "—"} />
        </SummarySection>

        {/* Project Details */}
        <SummarySection title="Project Details">
          <SummaryRow label="Project Type" value={summary.types.length ? summary.types.join(", ") : "—"} />
          <SummaryRow label="Files Uploaded" value={summary.filesCount > 0 ? `${summary.filesCount} file(s)` : "None"} />
        </SummarySection>

        {/* Scope & Services */}
        <SummarySection title="Scope & Services">
          <SummaryRow
            label="Core Engagement"
            value={isFull ? "Full Construction" : isPlans ? "Floor Plans Only" : "—"}
          />
          {addons.length > 0 && (
            <div className="px-4 py-3">
              <span className="text-muted-foreground text-sm">Add-ons</span>
              <ul className="mt-1.5 space-y-1">
                {addons.map((a) => (
                  <li key={a} className="text-sm font-medium text-foreground flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                    {a}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </SummarySection>

        {/* Estimated Fee */}
        <div className="rounded-lg border-2 border-primary/30 bg-primary/5 px-4 py-4 flex items-center justify-between">
          <span className="text-sm font-semibold text-foreground">Estimated Design Fee</span>
          <span className="text-lg font-bold text-primary">{summary.estimateRange}</span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Button
            onClick={() => handleAction("accept")}
            disabled={status === "loading"}
            className="w-full gap-2"
          >
            {status === "loading" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            Accept Estimate & Continue
          </Button>
          <p className="text-xs text-muted-foreground text-center">I agree with this estimate and want to proceed to the full briefing.</p>
        </div>
        <div className="space-y-2">
          <Button
            variant="outline"
            onClick={() => handleAction("save")}
            disabled={status === "loading"}
            className="w-full gap-2"
          >
            {status === "loading" ? <Loader2 className="h-4 w-4 animate-spin" /> : <BookmarkPlus className="h-4 w-4" />}
            Decline / Save for Later
          </Button>
          <p className="text-xs text-muted-foreground text-center">Just email me this estimate for now.</p>
        </div>
      </div>
    </div>
  );
}

function SummarySection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border bg-card overflow-hidden">
      <div className="px-4 py-2.5 bg-secondary/50 border-b">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{title}</h3>
      </div>
      <div className="divide-y">{children}</div>
    </div>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between px-4 py-3 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium text-foreground text-right max-w-[60%]">{value}</span>
    </div>
  );
}
