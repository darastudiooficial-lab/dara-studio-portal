import { useCallback, useRef, useState } from "react";
import { Upload, X, FileText } from "lucide-react";
import { cn } from "@/lib/utils";

interface Props {
  files: File[];
  onChange: (files: File[]) => void;
}

export default function FilesStep({ files, onChange }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);

  const addFiles = useCallback(
    (newFiles: FileList | null) => {
      if (!newFiles) return;
      const combined = [...files, ...Array.from(newFiles)].slice(0, 10);
      onChange(combined);
    },
    [files, onChange]
  );

  const removeFile = (idx: number) => {
    onChange(files.filter((_, i) => i !== idx));
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-1">Upload Files</h2>
        <p className="text-muted-foreground text-sm">Share reference files, photos, or plot plans to help us understand your vision.</p>
      </div>

      {/* Drop zone */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => { e.preventDefault(); setDragOver(false); addFiles(e.dataTransfer.files); }}
        onClick={() => inputRef.current?.click()}
        className={cn(
          "flex flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed p-12 cursor-pointer transition-colors",
          dragOver ? "border-primary bg-primary/5" : "border-border hover:border-muted-foreground/40"
        )}
      >
        <Upload className="h-10 w-10 text-muted-foreground" />
        <p className="text-sm font-medium text-foreground">Drag & drop files here, or click to browse</p>
        <p className="text-xs text-muted-foreground">Upload reference files, photos, or plot plans (up to 10 files)</p>
        <input ref={inputRef} type="file" multiple className="hidden" onChange={(e) => addFiles(e.target.files)} />
      </div>

      {/* File list */}
      {files.length > 0 && (
        <div className="space-y-2">
          <p className="text-sm font-semibold text-foreground">{files.length} file{files.length > 1 ? "s" : ""} selected</p>
          {files.map((f, i) => (
            <div key={i} className="flex items-center gap-3 rounded-lg border px-4 py-2.5">
              <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
              <span className="text-sm truncate flex-1">{f.name}</span>
              <span className="text-xs text-muted-foreground">{(f.size / 1024).toFixed(0)} KB</span>
              <button type="button" onClick={() => removeFile(i)} className="text-muted-foreground hover:text-destructive transition-colors">
                <X className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
