import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";

const LEVELS = [
  { id: "ground", label: "Ground Floor / Main Level" },
  { id: "2nd", label: "2nd Floor" },
  { id: "basement", label: "Basement" },
  { id: "attic", label: "Attic" },
];

interface Props {
  data: { width: string; length: string; levels: string[] };
  unit: string;
  onChange: (d: Partial<Props["data"]>) => void;
}

export default function DetailsStep({ data, unit, onChange }: Props) {
  const w = parseFloat(data.width) || 0;
  const l = parseFloat(data.length) || 0;
  const baseArea = w * l;
  const areaLabel = unit === "m" ? "m²" : "sqft";
  const has2nd = data.levels.includes("2nd");
  const totalArea = has2nd ? baseArea * 2 : baseArea;

  const toggleLevel = (id: string) => {
    if (id === "ground") return;
    const next = data.levels.includes(id)
      ? data.levels.filter((x) => x !== id)
      : [...data.levels, id];
    onChange({ levels: next });
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-1">Project Details</h2>
        <p className="text-muted-foreground text-sm">Enter your project dimensions and select the levels.</p>
      </div>

      {/* Dimensions */}
      <div>
        <Label className="text-sm font-semibold mb-3 block">Base Dimensions</Label>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="width" className="text-xs text-muted-foreground">Width ({unit})</Label>
            <Input
              id="width"
              type="number"
              min="0"
              placeholder="e.g. 30"
              value={data.width}
              onChange={(e) => onChange({ width: e.target.value })}
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="length" className="text-xs text-muted-foreground">Length ({unit})</Label>
            <Input
              id="length"
              type="number"
              min="0"
              placeholder="e.g. 40"
              value={data.length}
              onChange={(e) => onChange({ length: e.target.value })}
              className="mt-1"
            />
          </div>
        </div>

        {baseArea > 0 && (
          <div className="mt-3 space-y-2">
            <div className="rounded-lg bg-primary/10 px-4 py-3 text-sm font-semibold text-foreground">
              Total Base Area: <span className="text-primary">{baseArea.toLocaleString()} {areaLabel}</span>
            </div>
            {has2nd && (
              <div className="rounded-lg bg-accent/60 px-4 py-3 text-sm font-medium text-foreground">
                An extra level was added, and the current total area is:{" "}
                <span className="font-bold text-primary">{totalArea.toLocaleString()} {areaLabel}</span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Levels */}
      <div>
        <Label className="text-sm font-semibold mb-3 block">Levels</Label>
        <div className="space-y-2">
          {LEVELS.map((lv) => {
            const checked = data.levels.includes(lv.id);
            const isGround = lv.id === "ground";
            return (
              <label
                key={lv.id}
                className="flex items-center gap-3 rounded-lg border px-4 py-3 cursor-pointer transition-colors hover:bg-secondary/60 has-[:checked]:border-primary has-[:checked]:bg-primary/5"
              >
                <Checkbox
                  checked={checked}
                  disabled={isGround}
                  onCheckedChange={() => toggleLevel(lv.id)}
                />
                <span className="text-sm font-medium">{lv.label}</span>
                {isGround && <span className="ml-auto text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Default</span>}
              </label>
            );
          })}
        </div>
      </div>
    </div>
  );
}
