import { cn } from "@/lib/utils";
import { Check } from "lucide-react";

const STEPS = [
  "Location",
  "About You",
  "Details",
  "Project Scope",
  "Files",
  "Review",
];

interface StepperNavProps {
  currentStep: number;
}

export default function StepperNav({ currentStep }: StepperNavProps) {
  return (
    <nav className="w-full overflow-x-auto">
      <ol className="flex items-center gap-0 min-w-max mx-auto justify-center">
        {STEPS.map((label, i) => {
          const done = i < currentStep;
          const active = i === currentStep;
          return (
            <li key={label} className="flex items-center">
              <div className="flex flex-col items-center gap-1.5 px-4">
                <div
                  className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-colors",
                    done && "bg-primary text-primary-foreground",
                    active && "bg-primary text-primary-foreground ring-2 ring-primary/30 ring-offset-2 ring-offset-background",
                    !done && !active && "bg-muted text-muted-foreground"
                  )}
                >
                  {done ? <Check className="h-4 w-4" /> : i + 1}
                </div>
                <span
                  className={cn(
                    "text-[11px] font-medium whitespace-nowrap",
                    active ? "text-foreground" : "text-muted-foreground"
                  )}
                >
                  {label}
                </span>
              </div>
              {i < STEPS.length - 1 && (
                <div
                  className={cn(
                    "w-10 h-0.5 mt-[-18px]",
                    i < currentStep ? "bg-primary" : "bg-muted"
                  )}
                />
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

export { STEPS };
