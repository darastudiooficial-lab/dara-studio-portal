
-- Create site_updates table for construction progress
CREATE TABLE public.site_updates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  uploaded_by UUID REFERENCES auth.users(id),
  media_url TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.site_updates ENABLE ROW LEVEL SECURITY;

-- Admin full access
CREATE POLICY "Admins can do everything on site_updates"
  ON public.site_updates FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Clients can view their own project updates
CREATE POLICY "Clients can view own project site_updates"
  ON public.site_updates FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.projects p
    WHERE p.id = site_updates.project_id
    AND public.user_belongs_to_company(auth.uid(), p.company_id)
  ));

-- Clients can upload updates to their projects
CREATE POLICY "Clients can insert site_updates for own projects"
  ON public.site_updates FOR INSERT TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.projects p
    WHERE p.id = site_updates.project_id
    AND public.user_belongs_to_company(auth.uid(), p.company_id)
  ));

-- Create storage bucket for site update media
INSERT INTO storage.buckets (id, name, public) VALUES ('site-updates', 'site-updates', true);

-- Storage policies for site-updates bucket
CREATE POLICY "Anyone can view site update files"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'site-updates');

CREATE POLICY "Authenticated users can upload site update files"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'site-updates');

-- Enable realtime for site_updates
ALTER PUBLICATION supabase_realtime ADD TABLE public.site_updates;
