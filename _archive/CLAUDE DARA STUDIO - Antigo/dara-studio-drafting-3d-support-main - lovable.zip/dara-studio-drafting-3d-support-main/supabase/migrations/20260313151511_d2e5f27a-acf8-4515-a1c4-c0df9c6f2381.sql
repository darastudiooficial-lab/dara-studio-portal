
-- Add project_number column
ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS project_number TEXT DEFAULT NULL;

-- Create sequence for project numbering
CREATE SEQUENCE IF NOT EXISTS public.project_number_seq START WITH 1;

-- Set existing projects with sequential numbers based on creation order
WITH numbered AS (
  SELECT id, ROW_NUMBER() OVER (ORDER BY created_at) AS rn
  FROM public.projects
  WHERE project_number IS NULL
)
UPDATE public.projects p
SET project_number = 'DARA-' || LPAD(n.rn::text, 4, '0')
FROM numbered n
WHERE p.id = n.id;

-- Set sequence to continue after existing projects
SELECT setval('public.project_number_seq', COALESCE(
  (SELECT COUNT(*) FROM public.projects), 0
));

-- Create trigger function to auto-assign project_number
CREATE OR REPLACE FUNCTION public.assign_project_number()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.project_number IS NULL THEN
    NEW.project_number := 'DARA-' || LPAD(nextval('public.project_number_seq')::text, 4, '0');
  END IF;
  RETURN NEW;
END;
$$;

-- Create trigger
CREATE TRIGGER trg_assign_project_number
  BEFORE INSERT ON public.projects
  FOR EACH ROW
  EXECUTE FUNCTION public.assign_project_number();
