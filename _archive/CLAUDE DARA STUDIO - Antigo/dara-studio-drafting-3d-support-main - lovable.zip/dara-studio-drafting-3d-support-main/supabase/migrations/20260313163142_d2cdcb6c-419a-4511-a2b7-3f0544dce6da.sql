
CREATE TABLE public.studio_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  studio_name text NOT NULL DEFAULT 'DARA Studio',
  tagline text DEFAULT 'Drafting & 3D Support',
  logo_url text,
  primary_color text DEFAULT '#b8860b',
  accent_color text DEFAULT '#f5a623',
  contact_email text,
  contact_phone text,
  custom_domain text,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.studio_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage studio settings"
ON public.studio_settings FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Anyone can view studio settings"
ON public.studio_settings FOR SELECT
TO public
USING (true);

-- Insert default row
INSERT INTO public.studio_settings (studio_name, tagline, contact_email)
VALUES ('DARA Studio', 'Drafting & 3D Support', 'contact@darastudio.com');
