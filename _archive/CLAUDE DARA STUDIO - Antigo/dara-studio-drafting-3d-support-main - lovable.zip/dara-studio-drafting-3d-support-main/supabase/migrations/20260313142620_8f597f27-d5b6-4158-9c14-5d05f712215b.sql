
CREATE POLICY "Admins can do everything on quote_requests"
  ON public.quote_requests FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));
