
-- Add personal email and personal instagram to companies
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS personal_email text;
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS personal_instagram text;

-- Create company_employees table
CREATE TABLE public.company_employees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  name text NOT NULL,
  phone text,
  email text,
  instagram text,
  linkedin text,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.company_employees ENABLE ROW LEVEL SECURITY;

-- Admin full access
CREATE POLICY "Admins can do everything on company_employees"
ON public.company_employees
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
