
CREATE TABLE public.drawing_versions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  drawing_name TEXT NOT NULL,
  version_number INTEGER NOT NULL DEFAULT 1,
  file_url TEXT NOT NULL,
  file_name TEXT NOT NULL,
  revision_notes TEXT,
  is_current BOOLEAN NOT NULL DEFAULT false,
  uploaded_by UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.drawing_versions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can do everything on drawing_versions"
  ON public.drawing_versions FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Clients can view own project drawings"
  ON public.drawing_versions FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.projects p
    WHERE p.id = drawing_versions.project_id
    AND public.user_belongs_to_company(auth.uid(), p.company_id)
  ));

CREATE POLICY "Freelancers can view assigned project drawings"
  ON public.drawing_versions FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.freelancer_assignments fa
    WHERE fa.project_id = drawing_versions.project_id
    AND fa.freelancer_id = auth.uid()
  ));
