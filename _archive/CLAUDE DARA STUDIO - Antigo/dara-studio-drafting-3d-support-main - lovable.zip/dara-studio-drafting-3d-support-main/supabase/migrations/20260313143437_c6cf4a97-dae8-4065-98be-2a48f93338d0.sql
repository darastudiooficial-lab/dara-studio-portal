
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS language TEXT DEFAULT 'en';
