-- Allow free-text service type in admin projects
ALTER TABLE public.projects
  ALTER COLUMN service_type DROP DEFAULT;

ALTER TABLE public.projects
  ALTER COLUMN service_type TYPE text
  USING service_type::text;

ALTER TABLE public.projects
  ALTER COLUMN service_type SET DEFAULT 'technical_drafting';