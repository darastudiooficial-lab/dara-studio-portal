
ALTER TABLE public.projects
  ADD COLUMN IF NOT EXISTS homeowner_name TEXT,
  ADD COLUMN IF NOT EXISTS homeowner_phone TEXT,
  ADD COLUMN IF NOT EXISTS homeowner_email TEXT,
  ADD COLUMN IF NOT EXISTS homeowner_address TEXT;
