
-- Client tickets table
CREATE TABLE public.client_tickets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  subject TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Ticket messages table
CREATE TABLE public.client_ticket_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  ticket_id UUID NOT NULL REFERENCES public.client_tickets(id) ON DELETE CASCADE,
  sender_id UUID REFERENCES auth.users(id),
  is_from_admin BOOLEAN NOT NULL DEFAULT false,
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.client_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.client_ticket_messages ENABLE ROW LEVEL SECURITY;

-- RLS: Admins full access
CREATE POLICY "Admins can do everything on client_tickets"
  ON public.client_tickets FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can do everything on client_ticket_messages"
  ON public.client_ticket_messages FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- RLS: Clients can view/create tickets for their company
CREATE POLICY "Clients can view own company tickets"
  ON public.client_tickets FOR SELECT TO authenticated
  USING (user_belongs_to_company(auth.uid(), company_id));

CREATE POLICY "Clients can create tickets for own company"
  ON public.client_tickets FOR INSERT TO authenticated
  WITH CHECK (user_belongs_to_company(auth.uid(), company_id));

-- RLS: Clients can view/create messages on their tickets
CREATE POLICY "Clients can view own ticket messages"
  ON public.client_ticket_messages FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.client_tickets t
    WHERE t.id = client_ticket_messages.ticket_id
    AND user_belongs_to_company(auth.uid(), t.company_id)
  ));

CREATE POLICY "Clients can create messages on own tickets"
  ON public.client_ticket_messages FOR INSERT TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.client_tickets t
    WHERE t.id = client_ticket_messages.ticket_id
    AND user_belongs_to_company(auth.uid(), t.company_id)
  ));

-- Updated_at trigger
CREATE TRIGGER update_client_tickets_updated_at
  BEFORE UPDATE ON public.client_tickets
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
