
-- Allow clients to view payment milestones for their own company projects
CREATE POLICY "Clients can view own project milestones"
ON public.payment_milestones
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.projects p
    WHERE p.id = payment_milestones.project_id
    AND public.user_belongs_to_company(auth.uid(), p.company_id)
  )
);
