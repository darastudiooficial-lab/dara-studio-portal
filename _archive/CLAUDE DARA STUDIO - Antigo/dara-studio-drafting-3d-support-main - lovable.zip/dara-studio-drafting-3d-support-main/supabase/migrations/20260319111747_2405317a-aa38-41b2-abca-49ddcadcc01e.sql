
-- Timeline events table
CREATE TABLE public.project_timeline (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  revision_number integer NOT NULL DEFAULT 0,
  event_type text NOT NULL,
  event_date date,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.project_timeline ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can do everything on project_timeline"
  ON public.project_timeline FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Clients can view own project timeline"
  ON public.project_timeline FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM projects p
    WHERE p.id = project_timeline.project_id
    AND public.user_belongs_to_company(auth.uid(), p.company_id)
  ));

CREATE INDEX idx_project_timeline_project_id ON public.project_timeline(project_id);
