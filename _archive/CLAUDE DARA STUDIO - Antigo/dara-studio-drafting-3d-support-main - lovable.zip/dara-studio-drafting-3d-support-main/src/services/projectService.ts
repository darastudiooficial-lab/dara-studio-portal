// src/services/projectService.ts

export const getProjectStatus = (stage: string) => {
  return stage;
};
