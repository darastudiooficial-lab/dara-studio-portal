import { supabase } from "./client";

export const login = async (email: string, password: string) => {
  return supabase.auth.signInWithPassword({ email, password });
};

export const logout = async () => {
  return supabase.auth.signOut();
};

export const getUser = async () => {
  return supabase.auth.getUser();
};

export const onAuthStateChange = (callback: (event: string, session: any) => void) => {
  return supabase.auth.onAuthStateChange(callback);
};
