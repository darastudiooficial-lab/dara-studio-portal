import { supabase } from "./client";

// Freelancer assignments
export const getFreelancerAssignments = async (freelancerId?: string) => {
  let query = supabase
    .from("freelancer_assignments")
    .select("*, projects(name, companies(name))");

  if (freelancerId) {
    query = query.eq("freelancer_id", freelancerId);
  }

  const { data, error } = await query;
  return { data, error };
};

// Freelancer contracts
export const getFreelancerContracts = async (freelancerId: string) => {
  const { data, error } = await supabase
    .from("freelancer_contracts")
    .select("*, projects(name)")
    .eq("freelancer_id", freelancerId)
    .order("created_at", { ascending: false });
  return { data, error };
};

// Freelancer deliveries
export const createDelivery = async (delivery: any) => {
  const { data, error } = await supabase
    .from("freelancer_deliveries")
    .insert([delivery])
    .select();
  return { data, error };
};

export const getDeliveries = async (freelancerId: string) => {
  const { data, error } = await supabase
    .from("freelancer_deliveries")
    .select("*, projects(name)")
    .eq("freelancer_id", freelancerId)
    .order("created_at", { ascending: false });
  return { data, error };
};
