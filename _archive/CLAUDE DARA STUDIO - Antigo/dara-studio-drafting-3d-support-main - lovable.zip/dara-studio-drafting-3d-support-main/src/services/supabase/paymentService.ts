import { supabase } from "./client";

// Admin payments (studio income)
export const getAdminPayments = async () => {
  const { data, error } = await supabase
    .from("admin_payments")
    .select("*, projects(name, companies(name))")
    .order("created_at", { ascending: false });
  return { data, error };
};

// Freelancer payments (outgoing)
export const getFreelancerPayments = async (freelancerId?: string) => {
  let query = supabase
    .from("freelancer_payments")
    .select("*, projects(name)")
    .order("created_at", { ascending: false });

  if (freelancerId) {
    query = query.eq("freelancer_id", freelancerId);
  }

  const { data, error } = await query;
  return { data, error };
};

export const createAdminPayment = async (payment: any) => {
  const { data, error } = await supabase
    .from("admin_payments")
    .insert([payment])
    .select();
  return { data, error };
};
