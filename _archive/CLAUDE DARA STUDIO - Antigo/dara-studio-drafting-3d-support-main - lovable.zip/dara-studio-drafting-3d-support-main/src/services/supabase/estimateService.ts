import { supabase } from "./client";

// Uses the quote_requests table (public estimate form submissions)
export const createEstimate = async (data: any) => {
  const { data: result, error } = await supabase
    .from("quote_requests")
    .insert([data])
    .select();
  return { result, error };
};

export const getEstimates = async () => {
  const { data, error } = await supabase
    .from("quote_requests")
    .select("*")
    .order("created_at", { ascending: false });
  return { data, error };
};

// Quotes (sent to clients)
export const getQuotes = async () => {
  const { data, error } = await supabase
    .from("quotes")
    .select("*, companies(name), projects(name)")
    .order("created_at", { ascending: false });
  return { data, error };
};

export const createQuote = async (quote: any) => {
  const { data, error } = await supabase
    .from("quotes")
    .insert([quote])
    .select();
  return { data, error };
};
