// Re-export the auto-generated Supabase client
// IMPORTANT: Do NOT create a new client — use the one managed by Lovable Cloud
export { supabase } from "@/integrations/supabase/client";
