import { supabase } from "./client";

export const getProjects = async () => {
  const { data, error } = await supabase
    .from("projects")
    .select("*, companies(name)");
  return { data, error };
};

export const getProjectById = async (id: string) => {
  const { data, error } = await supabase
    .from("projects")
    .select("*, companies(name)")
    .eq("id", id)
    .single();
  return { data, error };
};

export const createProject = async (project: any) => {
  const { data, error } = await supabase
    .from("projects")
    .insert([project])
    .select();
  return { data, error };
};

export const updateProject = async (id: string, updates: any) => {
  const { data, error } = await supabase
    .from("projects")
    .update(updates)
    .eq("id", id)
    .select();
  return { data, error };
};
