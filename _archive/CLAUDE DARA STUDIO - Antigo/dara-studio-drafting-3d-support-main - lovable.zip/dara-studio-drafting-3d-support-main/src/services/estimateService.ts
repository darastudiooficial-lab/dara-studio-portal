// src/services/estimateService.ts

export const calculateEstimate = (
  area: number,
  rate: number
) => {
  return area * rate;
};
