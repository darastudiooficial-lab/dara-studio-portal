// src/services/paymentService.ts

export const calculateRemaining = (
  total: number,
  paid: number
) => {
  return total - paid;
};
