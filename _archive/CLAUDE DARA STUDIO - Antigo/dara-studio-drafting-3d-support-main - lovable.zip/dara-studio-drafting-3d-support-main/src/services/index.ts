// Centralized Supabase services
export { supabase } from "./supabase/client";
export * as authService from "./supabase/authService";
export * as projectService from "./supabase/projectService";
export * as estimateService from "./supabase/estimateService";
export * as paymentService from "./supabase/paymentService";
export * as freelancerService from "./supabase/freelancerService";
