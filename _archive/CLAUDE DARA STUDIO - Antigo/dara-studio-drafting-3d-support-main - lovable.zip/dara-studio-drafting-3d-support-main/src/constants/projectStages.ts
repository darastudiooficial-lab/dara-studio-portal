// Unified project stages used across the entire system
// SYSTEM VALUES — stored in DB
export const PROJECT_STAGES = [
  "STOPPED",
  "CANCELED",
  "WAITING_INITIAL_PAYMENT",
  "WAITING_CLIENT_INFO",
  "READY_TO_START",
  "IN_PROGRESS_REV_00",
  "PREVIEW_SENT_REV_00",
  "IN_PROGRESS_REV_01",
  "PREVIEW_SENT_REV_01",
  "IN_PROGRESS_REV_02",
  "PREVIEW_SENT_REV_02",
  "IN_PROGRESS_REV_03",
  "PREVIEW_SENT_REV_03",
  "APPROVED",
  "FINALIZING",
  "COMPLETED",
  "DELIVERED",
] as const;

export type ProjectStage = typeof PROJECT_STAGES[number];

// UI LABELS — display only (PT-BR)
export const PROJECT_STAGE_LABELS: Record<ProjectStage, string> = {
  STOPPED: "Parado",
  CANCELED: "Cancelado",
  WAITING_INITIAL_PAYMENT: "Esperando pagamento inicial",
  WAITING_CLIENT_INFO: "Esperando informações do cliente",
  READY_TO_START: "Pronto para iniciar",
  IN_PROGRESS_REV_00: "Em andamento – REV 00",
  PREVIEW_SENT_REV_00: "Preview REV 00 enviado",
  IN_PROGRESS_REV_01: "Em andamento – REV 01",
  PREVIEW_SENT_REV_01: "Preview REV 01 enviado",
  IN_PROGRESS_REV_02: "Em andamento – REV 02",
  PREVIEW_SENT_REV_02: "Preview REV 02 enviado",
  IN_PROGRESS_REV_03: "Em andamento – REV 03 (final)",
  PREVIEW_SENT_REV_03: "Preview REV 03 enviado",
  APPROVED: "Aprovado",
  FINALIZING: "Em finalização",
  COMPLETED: "Concluído",
  DELIVERED: "Entregue",
};

// Helper to get display label for any stage value (graceful fallback)
export const getStageLabel = (stage: string): string => {
  return PROJECT_STAGE_LABELS[stage as ProjectStage] || stage;
};

// Color tokens for stage badges / indicators
export const PROJECT_STAGE_COLORS: Record<string, { dot: string; bg: string; text: string; border: string }> = {
  STOPPED: { dot: "bg-muted-foreground", bg: "bg-muted", text: "text-muted-foreground", border: "border-border" },
  CANCELED: { dot: "bg-destructive", bg: "bg-destructive/10", text: "text-destructive", border: "border-destructive/20" },
  WAITING_INITIAL_PAYMENT: { dot: "bg-chart-4", bg: "bg-chart-4/15", text: "text-chart-4", border: "border-chart-4/30" },
  WAITING_CLIENT_INFO: { dot: "bg-chart-4", bg: "bg-chart-4/15", text: "text-chart-4", border: "border-chart-4/30" },
  READY_TO_START: { dot: "bg-chart-2", bg: "bg-chart-2/15", text: "text-chart-2", border: "border-chart-2/30" },
  IN_PROGRESS_REV_00: { dot: "bg-primary", bg: "bg-primary/10", text: "text-primary", border: "border-primary/20" },
  PREVIEW_SENT_REV_00: { dot: "bg-chart-5", bg: "bg-chart-5/15", text: "text-chart-5", border: "border-chart-5/30" },
  IN_PROGRESS_REV_01: { dot: "bg-primary", bg: "bg-primary/10", text: "text-primary", border: "border-primary/20" },
  PREVIEW_SENT_REV_01: { dot: "bg-chart-5", bg: "bg-chart-5/15", text: "text-chart-5", border: "border-chart-5/30" },
  IN_PROGRESS_REV_02: { dot: "bg-primary", bg: "bg-primary/10", text: "text-primary", border: "border-primary/20" },
  PREVIEW_SENT_REV_02: { dot: "bg-chart-5", bg: "bg-chart-5/15", text: "text-chart-5", border: "border-chart-5/30" },
  IN_PROGRESS_REV_03: { dot: "bg-primary", bg: "bg-primary/10", text: "text-primary", border: "border-primary/20" },
  PREVIEW_SENT_REV_03: { dot: "bg-chart-5", bg: "bg-chart-5/15", text: "text-chart-5", border: "border-chart-5/30" },
  APPROVED: { dot: "bg-chart-2", bg: "bg-chart-2/15", text: "text-chart-2", border: "border-chart-2/30" },
  FINALIZING: { dot: "bg-chart-3", bg: "bg-chart-3/15", text: "text-chart-3", border: "border-chart-3/30" },
  COMPLETED: { dot: "bg-chart-2", bg: "bg-chart-2/15", text: "text-chart-2", border: "border-chart-2/30" },
  DELIVERED: { dot: "bg-chart-2", bg: "bg-chart-2/15", text: "text-chart-2", border: "border-chart-2/30" },
};

// Kanban board stages — the workflow stages shown as columns
export const KANBAN_STAGES = [
  "WAITING_INITIAL_PAYMENT",
  "WAITING_CLIENT_INFO",
  "READY_TO_START",
  "IN_PROGRESS_REV_00",
  "PREVIEW_SENT_REV_00",
  "IN_PROGRESS_REV_01",
  "PREVIEW_SENT_REV_01",
  "IN_PROGRESS_REV_02",
  "PREVIEW_SENT_REV_02",
  "IN_PROGRESS_REV_03",
  "PREVIEW_SENT_REV_03",
  "APPROVED",
  "FINALIZING",
  "COMPLETED",
] as const;

export const KANBAN_STAGE_COLORS: Record<string, { bg: string; border: string; header: string }> = {
  WAITING_INITIAL_PAYMENT: { bg: "bg-chart-4/5", border: "border-chart-4/20", header: "bg-chart-4/15" },
  WAITING_CLIENT_INFO: { bg: "bg-chart-4/5", border: "border-chart-4/20", header: "bg-chart-4/15" },
  READY_TO_START: { bg: "bg-chart-2/5", border: "border-chart-2/20", header: "bg-chart-2/15" },
  IN_PROGRESS_REV_00: { bg: "bg-primary/5", border: "border-primary/20", header: "bg-primary/15" },
  PREVIEW_SENT_REV_00: { bg: "bg-chart-5/5", border: "border-chart-5/20", header: "bg-chart-5/15" },
  IN_PROGRESS_REV_01: { bg: "bg-primary/5", border: "border-primary/20", header: "bg-primary/15" },
  PREVIEW_SENT_REV_01: { bg: "bg-chart-5/5", border: "border-chart-5/20", header: "bg-chart-5/15" },
  IN_PROGRESS_REV_02: { bg: "bg-primary/5", border: "border-primary/20", header: "bg-primary/15" },
  PREVIEW_SENT_REV_02: { bg: "bg-chart-5/5", border: "border-chart-5/20", header: "bg-chart-5/15" },
  IN_PROGRESS_REV_03: { bg: "bg-primary/5", border: "border-primary/20", header: "bg-primary/15" },
  PREVIEW_SENT_REV_03: { bg: "bg-chart-5/5", border: "border-chart-5/20", header: "bg-chart-5/15" },
  APPROVED: { bg: "bg-chart-2/5", border: "border-chart-2/20", header: "bg-chart-2/15" },
  FINALIZING: { bg: "bg-chart-3/5", border: "border-chart-3/20", header: "bg-chart-3/15" },
  COMPLETED: { bg: "bg-chart-2/5", border: "border-chart-2/20", header: "bg-chart-2/15" },
};

// Stages considered "completed" for financial grouping
export const COMPLETED_STAGES: ProjectStage[] = ["COMPLETED", "DELIVERED"];

// Stages considered "active" (not stopped/canceled/completed)
export const isActiveStage = (stage: string): boolean => {
  return !["STOPPED", "CANCELED", "COMPLETED", "DELIVERED"].includes(stage);
};
