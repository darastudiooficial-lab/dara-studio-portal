import { Link } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PenTool, FileText, Home, Calculator, ArrowRight } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";

const services = [
  {
    icon: PenTool,
    titleEn: "Architectural Design & Construction Documents",
    titlePt: "Design Arquitetônico e Documentos de Construção",
    descriptionEn:
      "Complete architectural packages including floor plans, elevations, sections, detailing, and construction-ready documentation aligned with U.S. codes and permitting requirements.",
    descriptionPt:
      "Pacotes arquitetônicos completos incluindo plantas baixas, elevações, cortes, detalhamento e documentação pronta para construção alinhada com códigos americanos.",
    slug: "technical_drafting",
  },
  {
    icon: Home,
    titleEn: "Wood Framing Design & Layout",
    titlePt: "Design e Layout de Estrutura Wood Frame",
    descriptionEn:
      "Technical framing layouts for residential wood construction, supporting builders and engineers with precise load path visualization and structural coordination.",
    descriptionPt:
      "Layouts técnicos de estrutura para construção residencial em madeira, apoiando construtores e engenheiros com visualização precisa de cargas e coordenação estrutural.",
    slug: "wood_frame_structures",
  },
  {
    icon: FileText,
    titleEn: "3D Visualization & Concept Development",
    titlePt: "Visualização 3D e Desenvolvimento de Conceito",
    descriptionEn:
      "High-quality 3D modeling and visual studies to support client presentations, design refinement, and city submissions.",
    descriptionPt:
      "Modelagem 3D de alta qualidade e estudos visuais para apoiar apresentações a clientes, refinamento de design e submissões municipais.",
    slug: "executive_project",
  },
  {
    icon: Calculator,
    titleEn: "Project Estimation & Documentation Review",
    titlePt: "Estimativa de Projeto e Revisão de Documentação",
    descriptionEn:
      "Preliminary quantity take-offs and documentation analysis to support financial planning and project feasibility.",
    descriptionPt:
      "Levantamentos preliminares de quantidades e análise de documentação para apoiar planejamento financeiro e viabilidade do projeto.",
    slug: "project_budgeting",
  },
];

const ServicesGrid = () => {
  const { language, t } = useLanguage();

  return (
    <section className="py-20 bg-card">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-4">
            {t("services.title")}
          </h2>
          <p className="text-muted-foreground">
            {t("services.subtitle")}
          </p>
        </div>

        {/* Services Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service) => (
            <Card
              key={service.slug}
              className="group hover:shadow-lg transition-all duration-300 border-border hover:border-primary/50"
            >
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-accent flex items-center justify-center mb-4 group-hover:bg-primary transition-colors">
                  <service.icon className="h-6 w-6 text-accent-foreground group-hover:text-primary-foreground transition-colors" />
                </div>
                <CardTitle className="text-xl">
                  {language === "en" ? service.titleEn : service.titlePt}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-muted-foreground mb-4">
                  {language === "en" ? service.descriptionEn : service.descriptionPt}
                </CardDescription>
                <Link
                  to="/servicos"
                  className="inline-flex items-center text-sm font-medium text-primary hover:underline"
                >
                  {t("services.learnMore")}
                  <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <Button size="lg" asChild>
            <Link to="/orcamento">
              {t("services.cta")}
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ServicesGrid;
