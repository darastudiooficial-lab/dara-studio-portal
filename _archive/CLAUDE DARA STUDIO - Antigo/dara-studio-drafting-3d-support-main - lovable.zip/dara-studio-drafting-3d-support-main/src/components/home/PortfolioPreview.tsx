import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Image as ImageIcon } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";

const PortfolioPreview = () => {
  const { t } = useLanguage();

  const portfolioItems = [
    { id: 1, titleKey: "portfolio.item1.title", categoryKey: "portfolio.item1.category", location: "Worcester, MA" },
    { id: 2, titleKey: "portfolio.item2.title", categoryKey: "portfolio.item2.category", location: "Boston, MA" },
    { id: 3, titleKey: "portfolio.item3.title", categoryKey: "portfolio.item3.category", location: "Cambridge, MA" },
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-6">
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-4">{t("portfolio.title")}</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">{t("portfolio.subtitle")}</p>
        </div>
        <p className="text-sm font-medium text-primary mb-8 text-center">{t("portfolio.badge")}</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {portfolioItems.map((item) => (
            <Card key={item.id} className="group overflow-hidden border-border hover:border-primary/50 transition-all duration-300">
              <CardContent className="p-0">
                <div className="aspect-[4/3] bg-muted flex items-center justify-center relative overflow-hidden">
                  <ImageIcon className="h-12 w-12 text-muted-foreground/50" />
                </div>
                <div className="p-5 space-y-3">
                  <Badge variant="secondary" className="text-xs font-medium">{t(item.categoryKey)}</Badge>
                  <h3 className="font-semibold text-lg text-foreground group-hover:text-primary transition-colors">{t(item.titleKey)}</h3>
                  <p className="text-sm text-muted-foreground">{item.location}</p>
                  <Button variant="link" className="p-0 h-auto text-primary font-medium" asChild>
                    <Link to={`/portfolio/${item.id}`}>{t("portfolio.viewProject")}<ArrowRight className="ml-1 h-4 w-4" /></Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="text-center mt-10">
          <Button variant="outline" asChild>
            <Link to="/portfolio">{t("portfolio.viewAll")}<ArrowRight className="ml-2 h-4 w-4" /></Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default PortfolioPreview;
