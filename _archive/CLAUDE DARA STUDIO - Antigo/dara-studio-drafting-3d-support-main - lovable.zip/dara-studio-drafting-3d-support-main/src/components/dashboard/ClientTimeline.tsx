import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import {
  CheckCircle2, Clock, DollarSign, FileText, Send,
  MessageSquare, Star, Package, Truck, ChevronDown, AlertTriangle,
} from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";
import {
  REV_EVENTS, FINAL_EVENTS, TimelineEvent, STATUS_CONFIG, ALERT_CONFIG,
  getRevisionStatus, getRevisionAlert, getOverallAlert,
  getTimelineProgress, getRevisionDelay,
} from "@/components/admin/timeline/timelineUtils";

interface Props {
  projectId: string;
  deliveryDate?: string;
}

export default function ClientTimeline({ projectId, deliveryDate }: Props) {
  const [events, setEvents] = useState<TimelineEvent[]>([]);
  const [maxRevision, setMaxRevision] = useState(3);
  const [openRevisions, setOpenRevisions] = useState<Record<number, boolean>>({ 0: true });
  const [finalizationOpen, setFinalizationOpen] = useState(true);
  const isMobile = useIsMobile();

  const fetchEvents = useCallback(async () => {
    const { data } = await supabase
      .from("project_timeline")
      .select("*")
      .eq("project_id", projectId)
      .order("revision_number")
      .order("created_at");
    const list = (data as TimelineEvent[]) || [];
    setEvents(list);
    const highestRev = list.reduce((m, e) => Math.max(m, e.revision_number), 3);
    setMaxRevision(highestRev < 3 ? 3 : highestRev);
  }, [projectId]);

  useEffect(() => { fetchEvents(); }, [fetchEvents]);

  const getEventRecord = (revNum: number, eventType: string) =>
    events.find(e => e.revision_number === revNum && e.event_type === eventType);

  // Find the "next step" for the client
  const getNextStep = (): string | null => {
    for (let rev = 0; rev <= maxRevision; rev++) {
      const alert = getRevisionAlert(rev, events);
      if (alert === "waiting_client") {
        return `Waiting for your feedback on REV ${String(rev).padStart(2, "0")}`;
      }
    }
    // Check if there's an in-progress revision
    for (let rev = 0; rev <= maxRevision; rev++) {
      const status = getRevisionStatus(rev, events);
      if (status === "in_progress") {
        const previewSent = events.find(e => e.revision_number === rev && e.event_type === "rev_preview_sent" && e.event_date);
        if (previewSent) return `Please review REV ${String(rev).padStart(2, "0")} preview`;
        return `REV ${String(rev).padStart(2, "0")} is being worked on`;
      }
    }
    return null;
  };

  const renderEvent = (ev: { type: string; label: string; icon: React.ElementType }, record: TimelineEvent | undefined) => {
    const Icon = ev.icon;
    const done = !!record?.event_date;
    return (
      <div key={ev.type} className={cn("flex items-center gap-3 px-3 py-2 rounded-md", done ? "bg-chart-2/5" : "bg-transparent")}>
        <div className={cn(
          "h-6 w-6 rounded-full flex items-center justify-center shrink-0",
          done ? "bg-chart-2/20 text-chart-2" : "bg-muted text-muted-foreground"
        )}>
          {done ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Icon className="h-3.5 w-3.5" />}
        </div>
        <p className={cn("text-sm flex-1", done ? "text-foreground font-medium" : "text-muted-foreground")}>{ev.label}</p>
        {record?.event_date && (
          <span className="text-xs text-muted-foreground shrink-0">
            {format(new Date(record.event_date), "MMM d, yyyy")}
          </span>
        )}
      </div>
    );
  };

  const renderRevisionBlock = (revNum: number) => {
    const revEvents = REV_EVENTS(revNum);
    const isExtra = revNum > 3;
    const revLabel = `REV ${String(revNum).padStart(2, "0")}`;
    const status = getRevisionStatus(revNum, events);
    const statusCfg = STATUS_CONFIG[status];
    const alert = getRevisionAlert(revNum, events);
    const completedCount = revEvents.filter(ev => getEventRecord(revNum, ev.type)?.event_date).length;
    const isOpen = openRevisions[revNum] ?? false;

    return (
      <Collapsible
        key={`rev-${revNum}`}
        open={isOpen}
        onOpenChange={(open) => setOpenRevisions(prev => ({ ...prev, [revNum]: open }))}
      >
        <Card className={cn(
          "border shadow-sm",
          isExtra && "border-l-4 border-l-chart-4",
          alert === "waiting_client" && "border-yellow-400/50 dark:border-yellow-600/50"
        )}>
          <CollapsibleTrigger asChild>
            <CardHeader className="pb-2 cursor-pointer hover:bg-muted/30 transition-colors">
              <CardTitle className="text-sm flex items-center gap-2">
                <Package className="h-4 w-4 text-muted-foreground" />
                {revLabel}
                {revNum === 0 && <Badge variant="secondary" className="text-[10px]">Initial</Badge>}
                {revNum === 3 && <Badge variant="secondary" className="text-[10px]">Final</Badge>}
                {isExtra && <Badge className="text-[10px] bg-chart-4/15 text-chart-4 border-chart-4/30">Extra</Badge>}
                <Badge className={cn("text-[10px] ml-1 border-0", statusCfg.classes)}>
                  {statusCfg.icon} {statusCfg.label}
                </Badge>
                {alert === "waiting_client" && (
                  <Badge className={cn("text-[10px] border-0", ALERT_CONFIG.waiting_client.classes)}>
                    Action Required
                  </Badge>
                )}
                <span className="ml-auto text-xs text-muted-foreground font-normal">{completedCount}/{revEvents.length}</span>
                <ChevronDown className={cn("h-4 w-4 text-muted-foreground transition-transform", isOpen && "rotate-180")} />
              </CardTitle>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="space-y-1 pt-0">
              {revEvents.map(ev => renderEvent(ev, getEventRecord(revNum, ev.type)))}
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>
    );
  };

  const renderFinalBlock = () => (
    <Collapsible open={finalizationOpen} onOpenChange={setFinalizationOpen}>
      <Card className="border shadow-sm">
        <CollapsibleTrigger asChild>
          <CardHeader className="pb-2 cursor-pointer hover:bg-muted/30 transition-colors">
            <CardTitle className="text-sm flex items-center gap-2">
              <Star className="h-4 w-4 text-chart-2" /> Completion
              <ChevronDown className={cn("h-4 w-4 text-muted-foreground ml-auto transition-transform", finalizationOpen && "rotate-180")} />
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="space-y-1 pt-0">
            {FINAL_EVENTS.map(ev => {
              const isAutoType = ev.type === "invoice_sent_auto" || ev.type === "payment_received_auto";
              if (isAutoType) {
                const autoRecords = events.filter(e => e.revision_number === -1 && e.event_type === ev.type);
                if (autoRecords.length > 0) {
                  return autoRecords.map(ar => (
                    <div key={ar.id} className="flex items-center gap-3 px-3 py-2 rounded-md bg-chart-2/5">
                      <div className="h-6 w-6 rounded-full flex items-center justify-center shrink-0 bg-chart-2/20 text-chart-2">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-foreground font-medium">{ev.label}</p>
                        {ar.notes && <p className="text-xs text-muted-foreground truncate">{ar.notes}</p>}
                      </div>
                      {ar.event_date && (
                        <span className="text-xs text-muted-foreground shrink-0">
                          {format(new Date(ar.event_date), "MMM d, yyyy")}
                        </span>
                      )}
                    </div>
                  ));
                }
                return (
                  <div key={ev.type} className="flex items-center gap-3 px-3 py-2 rounded-md bg-transparent opacity-50">
                    <div className="h-6 w-6 rounded-full flex items-center justify-center shrink-0 bg-muted text-muted-foreground">
                      <ev.icon className="h-3.5 w-3.5" />
                    </div>
                    <p className="text-sm text-muted-foreground">{ev.label}</p>
                  </div>
                );
              }
              return renderEvent(ev, events.find(e => e.revision_number === -1 && e.event_type === ev.type));
            })}
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );

  const overallAlert = getOverallAlert(events, deliveryDate);
  const alertCfg = ALERT_CONFIG[overallAlert];
  const progressPct = getTimelineProgress(events, maxRevision);
  const nextStep = getNextStep();
  const revisionNumbers = Array.from({ length: maxRevision + 1 }, (_, i) => i);

  return (
    <div className="space-y-4">
      {/* Overall status */}
      <Card className="border shadow-sm">
        <CardContent className="py-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Badge className={cn("text-xs border-0", alertCfg.classes)}>
                {alertCfg.icon} {alertCfg.label}
              </Badge>
              <span className="text-sm text-muted-foreground">Project Progress</span>
            </div>
            <span className="text-sm font-semibold">{progressPct}%</span>
          </div>
          <Progress value={progressPct} className="h-2" />
          {nextStep && (
            <div className="flex items-center gap-2 text-xs text-yellow-700 dark:text-yellow-400 bg-yellow-50 dark:bg-yellow-900/20 px-3 py-2 rounded-md">
              <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
              {nextStep}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Revision grid */}
      <div className={cn("grid gap-4", isMobile ? "grid-cols-1" : "grid-cols-1 lg:grid-cols-2")}>
        {revisionNumbers.map(revNum => renderRevisionBlock(revNum))}
        {renderFinalBlock()}
      </div>
    </div>
  );
}
