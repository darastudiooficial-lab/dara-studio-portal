import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Download, FolderOpen, FileText, ChevronRight, PenTool } from "lucide-react";
import { format } from "date-fns";

const DOCUMENT_CATEGORIES = [
  { value: "pre_construction", label: "Pre-Construction" },
  { value: "rev_00", label: "REV 00" },
  { value: "rev_01", label: "REV 01" },
  { value: "rev_02", label: "REV 02" },
  { value: "rev_03", label: "REV 03 (Final)" },
  { value: "final_delivery", label: "Final Delivery" },
  { value: "general", label: "General" },
] as const;

interface ClientProjectDocumentsProps {
  projectId: string;
}

const ClientProjectDocuments = ({ projectId }: ClientProjectDocumentsProps) => {
  const [files, setFiles] = useState<any[]>([]);
  const [drawings, setDrawings] = useState<any[]>([]);
  const [openFolders, setOpenFolders] = useState<Set<string>>(new Set(DOCUMENT_CATEGORIES.map(c => c.value)));

  const loadData = useCallback(async () => {
    const [fRes, dRes] = await Promise.all([
      supabase.from("project_files").select("*").eq("project_id", projectId).order("created_at", { ascending: false }),
      supabase.from("drawing_versions").select("*").eq("project_id", projectId).eq("is_current", true).order("created_at", { ascending: false }),
    ]);
    setFiles(fRes.data || []);
    setDrawings(dRes.data || []);
  }, [projectId]);

  useEffect(() => { loadData(); }, [loadData]);

  const toggleFolder = (cat: string) => {
    setOpenFolders(prev => {
      const next = new Set(prev);
      next.has(cat) ? next.delete(cat) : next.add(cat);
      return next;
    });
  };

  const grouped = DOCUMENT_CATEGORIES.reduce((acc, cat) => {
    acc[cat.value] = files.filter(f => (f.document_category || "general") === cat.value);
    return acc;
  }, {} as Record<string, any[]>);

  const totalCount = files.length + drawings.length;

  const formatSize = (bytes: number | null) => {
    if (!bytes) return "";
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  };

  if (totalCount === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="py-10 text-center text-muted-foreground">
          <FolderOpen className="h-8 w-8 mx-auto mb-2 opacity-40" />
          No files available yet
        </CardContent>
      </Card>
    );
  }

  const hasDrawings = drawings.length > 0;
  const nonEmptyFolders = DOCUMENT_CATEGORIES.filter(cat => grouped[cat.value].length > 0);

  return (
    <div className="space-y-4">
      {/* Drawings Section */}
      {hasDrawings && (
        <Card className="border-none shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Drawings</CardTitle>
          </CardHeader>
          <CardContent className="p-0 pb-2">
            {drawings.map(d => (
              <div key={d.id} className="flex items-center gap-3 px-4 py-2 hover:bg-muted/30 transition-colors">
                <PenTool className="h-4 w-4 text-primary shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{d.drawing_name}</p>
                  <p className="text-[11px] text-muted-foreground">
                    v{d.version_number} · {format(new Date(d.created_at), "MMM d, yyyy")}
                  </p>
                </div>
                <Button size="sm" variant="ghost" asChild>
                  <a href={d.file_url} target="_blank" rel="noopener noreferrer"><Download className="h-4 w-4" /></a>
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Document Folders */}
      {nonEmptyFolders.length > 0 && (
        <Card className="border-none shadow-sm">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm">Documents</CardTitle>
              <Badge variant="secondary" className="text-[10px]">{files.length} files</Badge>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border">
              {nonEmptyFolders.map(cat => {
                const catFiles = grouped[cat.value];
                const isOpen = openFolders.has(cat.value);
                return (
                  <Collapsible key={cat.value} open={isOpen} onOpenChange={() => toggleFolder(cat.value)}>
                    <CollapsibleTrigger className="flex items-center gap-3 w-full px-4 py-3 hover:bg-muted/50 transition-colors text-left">
                      <ChevronRight className={`h-4 w-4 text-muted-foreground transition-transform ${isOpen ? "rotate-90" : ""}`} />
                      <FolderOpen className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium text-foreground flex-1">{cat.label}</span>
                      <Badge variant="outline" className="text-[10px]">{catFiles.length}</Badge>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <div className="pb-2">
                        {catFiles.map(f => (
                          <div key={f.id} className="flex items-center gap-3 px-12 py-2 hover:bg-muted/30 transition-colors">
                            <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-foreground truncate">{f.file_name}</p>
                              <p className="text-[11px] text-muted-foreground">
                                {formatSize(f.file_size)} · {format(new Date(f.created_at), "MMM d, yyyy")}
                              </p>
                            </div>
                            <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" asChild>
                              <a href={f.file_url} target="_blank" rel="noopener noreferrer"><Download className="h-3.5 w-3.5" /></a>
                            </Button>
                          </div>
                        ))}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ClientProjectDocuments;
