import { UseFormRegister, FieldErrors, UseFormWatch, UseFormSetValue } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { AlertTriangle } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";
import { FormData, PROJECT_TYPES, PROJECT_LEVELS, BUILDING_STATUS_OPTIONS, REQUIRED_SPACES, DARA_SERVICES } from "./types";

interface StepProjectProps {
  register: UseFormRegister<FormData>;
  errors: FieldErrors<FormData>;
  watch: UseFormWatch<FormData>;
  setValue: UseFormSetValue<FormData>;
}

const projectTypeKeys = [
  "projectType.singleFamily", "projectType.multiFamily", "projectType.commercial",
  "projectType.renovation", "projectType.addition", "projectType.adu",
  "projectType.deck", "projectType.garage", "projectType.other",
];

const buildingStatusKeys = [
  { value: "occupied", key: "buildingStatus.occupied" },
  { value: "under_construction", key: "buildingStatus.underConstruction" },
  { value: "vacant", key: "buildingStatus.vacant" },
  { value: "new_construction", key: "buildingStatus.newConstruction" },
];

const levelKeys = [
  { id: "basement", key: "level.basement" },
  { id: "first_floor", key: "level.firstFloor" },
  { id: "second_floor", key: "level.secondFloor" },
  { id: "attic_loft", key: "level.atticLoft" },
  { id: "garage_level", key: "level.garageLevel" },
];

const spacesCategoryKeys: Record<string, string> = {
  privateSpaces: "spaces.private",
  bathrooms: "spaces.bathrooms",
  socialAreas: "spaces.social",
  kitchenSupport: "spaces.kitchen",
  workWellness: "spaces.work",
  circulationStorage: "spaces.circulation",
  technicalAreas: "spaces.technical",
  outdoorAreas: "spaces.outdoor",
};

const daraServiceCategoryKeys: Record<string, string> = {
  architecture: "daraService.architecture",
  interiors: "daraService.interiors",
  visualization: "daraService.visualization",
  documentation: "daraService.documentation",
  construction: "daraService.construction",
  additional: "daraService.additional",
};

const StepProject = ({ register, errors, watch, setValue }: StepProjectProps) => {
  const { t } = useLanguage();
  const projectType = watch("projectType");
  const requiredSpaces = watch("requiredSpaces") || [];
  const selectedDaraServices = watch("selectedDaraServices") || [];
  const projectLevels = watch("projectLevels") || [];

  const handleSpaceChange = (spaceId: string, checked: boolean) => {
    const current = requiredSpaces || [];
    setValue("requiredSpaces", checked ? [...current, spaceId] : current.filter(s => s !== spaceId));
  };

  const handleDaraServiceChange = (serviceId: string, checked: boolean) => {
    const current = selectedDaraServices || [];
    setValue("selectedDaraServices", checked ? [...current, serviceId] : current.filter(s => s !== serviceId));
  };

  const handleLevelChange = (levelId: string, checked: boolean) => {
    const current = projectLevels || [];
    setValue("projectLevels", checked ? [...current, levelId] : current.filter(l => l !== levelId));
  };

  return (
    <div className="space-y-8">
      {/* STEP 1 — PROJECT INFORMATION */}
      <section className="space-y-6">
        <div className="flex items-center gap-3">
          <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-semibold">1</span>
          <h3 className="text-lg font-semibold text-foreground">{t("form.projectInfo")}</h3>
        </div>

        <div>
          <Label className="text-base font-medium">{t("form.projectType")} *</Label>
          <p className="text-sm text-muted-foreground mb-3">{t("form.selectOne")}</p>
          <RadioGroup value={watch("projectType")} onValueChange={(value) => setValue("projectType", value)} className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {projectTypeKeys.map((key) => {
              const label = t(key);
              return (
                <div key={key} className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted/50 transition-colors">
                  <RadioGroupItem value={label} id={key} />
                  <Label htmlFor={key} className="cursor-pointer text-sm font-normal">{label}</Label>
                </div>
              );
            })}
          </RadioGroup>
          {errors.projectType && <p className="text-sm text-destructive mt-1">{errors.projectType.message}</p>}
        </div>

        {projectType === t("projectType.other") && (
          <div>
            <Label htmlFor="otherProjectType">{t("form.ifOtherDescribe")}</Label>
            <Input id="otherProjectType" placeholder={t("form.describeProjectType")} {...register("otherProjectType")} className="mt-1" />
          </div>
        )}

        <div>
          <Label className="text-base font-medium">{t("form.hasExistingPlans")} *</Label>
          <RadioGroup value={watch("hasExistingProject")} onValueChange={(value) => setValue("hasExistingProject", value as "yes" | "no")} className="mt-2 flex gap-6">
            <div className="flex items-center space-x-2"><RadioGroupItem value="yes" id="hasProject-yes" /><Label htmlFor="hasProject-yes" className="cursor-pointer">{t("form.yes")}</Label></div>
            <div className="flex items-center space-x-2"><RadioGroupItem value="no" id="hasProject-no" /><Label htmlFor="hasProject-no" className="cursor-pointer">{t("form.no")}</Label></div>
          </RadioGroup>
          {errors.hasExistingProject && <p className="text-sm text-destructive mt-1">{errors.hasExistingProject.message}</p>}
        </div>

        <div>
          <Label className="text-base font-medium">{t("form.hasEngineer")}</Label>
          <RadioGroup value={watch("hasEngineer")} onValueChange={(value) => setValue("hasEngineer", value as "yes" | "no")} className="mt-2 flex flex-wrap gap-4">
            <div className="flex items-center space-x-2"><RadioGroupItem value="yes" id="engineer-yes" /><Label htmlFor="engineer-yes" className="cursor-pointer">{t("form.haveOne")}</Label></div>
            <div className="flex items-center space-x-2"><RadioGroupItem value="no" id="engineer-no" /><Label htmlFor="engineer-no" className="cursor-pointer">{t("form.needReferral")}</Label></div>
          </RadioGroup>
        </div>

        <div>
          <Label className="text-base font-medium">{t("form.buildingStatus")}</Label>
          <RadioGroup value={watch("buildingStatus")} onValueChange={(value) => setValue("buildingStatus", value)} className="mt-2 grid grid-cols-2 gap-2">
            {buildingStatusKeys.map((option) => (
              <div key={option.value} className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted/50 transition-colors">
                <RadioGroupItem value={option.value} id={`status-${option.value}`} />
                <Label htmlFor={`status-${option.value}`} className="cursor-pointer text-sm">{t(option.key)}</Label>
              </div>
            ))}
          </RadioGroup>
        </div>
      </section>

      <Separator />

      {/* STEP 2 — PROJECT SIZE & LEVELS */}
      <section className="space-y-6">
        <div className="flex items-center gap-3">
          <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-semibold">2</span>
          <h3 className="text-lg font-semibold text-foreground">{t("form.projectSizeLevels")}</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="existingArea">{t("form.existingArea")}</Label>
            <p className="text-sm text-muted-foreground mb-1">{t("form.sqftOptional")}</p>
            <Input id="existingArea" placeholder="e.g., 1,800" {...register("existingArea")} />
          </div>
          <div>
            <Label htmlFor="estimatedSize">{t("form.proposedArea")} *</Label>
            <p className="text-sm text-muted-foreground mb-1">{t("form.proposedAreaDesc")}</p>
            <Input id="estimatedSize" placeholder="e.g., 2,500 sq ft" {...register("estimatedSize")} />
            {errors.estimatedSize && <p className="text-sm text-destructive mt-1">{errors.estimatedSize.message}</p>}
          </div>
        </div>
        <div>
          <Label className="text-base font-medium">{t("form.projectLevels")}</Label>
          <div className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-2">
            {levelKeys.map((level) => (
              <div key={level.id} className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted/50 transition-colors">
                <Checkbox id={level.id} checked={projectLevels.includes(level.id)} onCheckedChange={(checked) => handleLevelChange(level.id, checked as boolean)} />
                <Label htmlFor={level.id} className="cursor-pointer text-sm font-normal">{t(level.key)}</Label>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Separator />

      {/* STEP 3 — FILE UPLOADS & REFERENCES */}
      <section className="space-y-6">
        <div className="flex items-center gap-3">
          <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-semibold">3</span>
          <h3 className="text-lg font-semibold text-foreground">{t("form.fileUploads")}</h3>
        </div>
        <div>
          <Label htmlFor="referenceNotes">{t("form.uploadDesc")}</Label>
          <p className="text-sm text-muted-foreground mb-2">{t("form.acceptsFormats")}</p>
          <Textarea id="referenceNotes" placeholder={t("form.referenceNotesPlaceholder")} className="min-h-[80px]" {...register("referenceNotes")} />
        </div>
        <div>
          <Label htmlFor="referenceLinks">{t("form.referenceLinks")}</Label>
          <p className="text-sm text-muted-foreground mb-2">{t("form.referenceLinksDesc")}</p>
          <Textarea id="referenceLinks" placeholder={t("form.referenceLinksPlaceholder")} className="min-h-[60px]" {...register("referenceLinks")} />
        </div>
      </section>

      <Separator />

      {/* STEP 4 — PROGRAM OF REQUIREMENTS */}
      <section className="space-y-6">
        <div className="flex items-center gap-3">
          <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-semibold">4</span>
          <h3 className="text-lg font-semibold text-foreground">{t("form.programRequirements")}</h3>
        </div>
        <p className="text-sm text-muted-foreground -mt-4">{t("form.programRequirementsDesc")}</p>

        {Object.entries(REQUIRED_SPACES).map(([key, category]) => (
          <div key={key} className="space-y-2">
            <h4 className="font-medium text-foreground text-sm">{t(spacesCategoryKeys[key])}</h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1">
              {category.spaces.map((space) => (
                <div key={space.id} className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted/50 transition-colors">
                  <Checkbox id={space.id} checked={requiredSpaces.includes(space.id)} onCheckedChange={(checked) => handleSpaceChange(space.id, checked as boolean)} />
                  <Label htmlFor={space.id} className="cursor-pointer text-sm font-normal">{space.label}</Label>
                </div>
              ))}
            </div>
          </div>
        ))}

        <div>
          <Label htmlFor="otherSpace">{t("form.other")}</Label>
          <Input id="otherSpace" placeholder={t("form.otherPlaceholder")} {...register("otherSpace")} className="mt-1" />
        </div>
      </section>

      <Separator />

      {/* STEP 5 — SERVICES OFFERED BY DARA */}
      <section className="space-y-6">
        <div className="flex items-center gap-3">
          <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-semibold">5</span>
          <h3 className="text-lg font-semibold text-foreground">{t("form.servicesOffered")}</h3>
        </div>
        <div className="-mt-4">
          <p className="text-sm font-medium text-foreground">{t("form.designDrafting")}</p>
          <p className="text-sm text-muted-foreground">{t("form.selectServices")}</p>
        </div>

        {Object.entries(DARA_SERVICES).map(([key, category]) => (
          <div key={key} className="space-y-2">
            <h4 className="font-medium text-primary text-sm uppercase tracking-wide">{t(daraServiceCategoryKeys[key])}</h4>
            <div className="grid grid-cols-1 gap-1">
              {category.services.map((service) => (
                <div key={service.id} className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted/50 transition-colors">
                  <Checkbox id={service.id} checked={selectedDaraServices.includes(service.id)} onCheckedChange={(checked) => handleDaraServiceChange(service.id, checked as boolean)} />
                  <Label htmlFor={service.id} className="cursor-pointer text-sm font-normal">{service.label}</Label>
                </div>
              ))}
            </div>
          </div>
        ))}

        <div className="bg-muted/50 border border-border rounded-lg p-4 mt-6">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-500 mt-0.5 flex-shrink-0" />
            <div>
              <h5 className="font-semibold text-foreground text-sm mb-2">{t("form.disclaimer")}</h5>
              <p className="text-sm text-muted-foreground leading-relaxed">{t("form.disclaimerText")}</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default StepProject;
