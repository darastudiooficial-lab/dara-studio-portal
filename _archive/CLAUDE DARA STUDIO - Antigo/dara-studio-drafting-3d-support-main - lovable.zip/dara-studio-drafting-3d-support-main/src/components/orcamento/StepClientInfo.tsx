import { UseFormRegister, FieldErrors, UseFormWatch, UseFormSetValue } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useLanguage } from "@/hooks/useLanguage";
import { FormData } from "./types";

interface StepClientInfoProps {
  register: UseFormRegister<FormData>;
  errors: FieldErrors<FormData>;
  watch: UseFormWatch<FormData>;
  setValue: UseFormSetValue<FormData>;
}

const clientTypeKeys = [
  { value: "cliente_final", key: "clientType.homeowner" },
  { value: "construtor", key: "clientType.contractor" },
  { value: "arquiteto", key: "clientType.architect" },
  { value: "engenheiro", key: "clientType.engineer" },
  { value: "real_estate", key: "clientType.realEstate" },
];

const StepClientInfo = ({ register, errors, watch, setValue }: StepClientInfoProps) => {
  const { t } = useLanguage();
  const clientType = watch("clientType");
  const isContractor = clientType === "construtor";

  return (
    <div className="space-y-4">
      <div>
        <Label className="text-base font-semibold">{t("form.iAmA")} *</Label>
        <RadioGroup value={watch("clientType")} onValueChange={(value) => setValue("clientType", value as FormData["clientType"])} className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
          {clientTypeKeys.map((type) => (
            <div key={type.value} className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted/50 transition-colors">
              <RadioGroupItem value={type.value} id={`client-${type.value}`} />
              <Label htmlFor={`client-${type.value}`} className="cursor-pointer text-sm font-normal">{t(type.key)}</Label>
            </div>
          ))}
        </RadioGroup>
        {errors.clientType && <p className="text-sm text-destructive mt-1">{errors.clientType.message}</p>}
      </div>

      <div className="pt-4 border-t border-border">
        <h4 className="font-medium text-foreground mb-4">{t("form.contactInfo")}</h4>
        <div className="space-y-4">
          <div>
            <Label htmlFor="fullName">{t("form.fullName")} *</Label>
            <Input id="fullName" placeholder={t("form.fullNamePlaceholder")} {...register("fullName")} className="mt-1" />
            {errors.fullName && <p className="text-sm text-destructive mt-1">{errors.fullName.message}</p>}
          </div>
          <div>
            <Label htmlFor="email">{t("form.email")} *</Label>
            <Input id="email" type="email" placeholder="your@email.com" {...register("email")} className="mt-1" />
            {errors.email && <p className="text-sm text-destructive mt-1">{errors.email.message}</p>}
          </div>
          <div>
            <Label htmlFor="phone">{t("form.phone")} *</Label>
            <Input id="phone" placeholder="(555) 123-4567" {...register("phone")} className="mt-1" />
            {errors.phone && <p className="text-sm text-destructive mt-1">{errors.phone.message}</p>}
          </div>
        </div>
      </div>

      {clientType && clientType !== "cliente_final" && (
        <div className="space-y-4 pt-4 border-t border-border">
          <h4 className="font-medium text-foreground">
            {t("form.companyInfo")} {isContractor && <span className="text-destructive">*</span>}
          </h4>
          <div>
            <Label htmlFor="companyName">{t("form.companyName")} {isContractor ? "*" : t("form.optional")}</Label>
            <Input id="companyName" placeholder={t("form.companyNamePlaceholder")} {...register("companyName")} className="mt-1" />
            {errors.companyName && <p className="text-sm text-destructive mt-1">{errors.companyName.message}</p>}
          </div>
          <div>
            <Label htmlFor="companyAddress">{t("form.companyAddress")}</Label>
            <Input id="companyAddress" placeholder={t("form.companyAddressPlaceholder")} {...register("companyAddress")} className="mt-1" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="companyInstagram">{t("form.instagram")}</Label>
              <Input id="companyInstagram" placeholder="@yourcompany" {...register("companyInstagram")} className="mt-1" />
            </div>
            <div>
              <Label htmlFor="companyPhone">{t("form.companyPhone")}</Label>
              <Input id="companyPhone" placeholder="(555) 123-4567" {...register("companyPhone")} className="mt-1" />
            </div>
          </div>
          <div>
            <Label htmlFor="companyEmail">{t("form.companyEmail")}</Label>
            <Input id="companyEmail" type="email" placeholder="contact@company.com" {...register("companyEmail")} className="mt-1" />
          </div>
        </div>
      )}
    </div>
  );
};

export default StepClientInfo;
