import { UseFormRegister, FieldErrors } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FormData } from "./types";
import { useLanguage } from "@/hooks/useLanguage";

interface StepLocationProps {
  register: UseFormRegister<FormData>;
  errors: FieldErrors<FormData>;
}

const StepLocation = ({ register, errors }: StepLocationProps) => {
  const { t } = useLanguage();
  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="projectAddress">{t("form.projectAddress")} *</Label>
        <Input id="projectAddress" placeholder={t("form.streetAddress")} {...register("projectAddress")} className="mt-1" />
        {errors.projectAddress && <p className="text-sm text-destructive mt-1">{errors.projectAddress.message}</p>}
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="projectCity">{t("form.city")} *</Label>
          <Input id="projectCity" placeholder={t("form.city")} {...register("projectCity")} className="mt-1" />
          {errors.projectCity && <p className="text-sm text-destructive mt-1">{errors.projectCity.message}</p>}
        </div>
        <div>
          <Label htmlFor="projectState">{t("form.state")} *</Label>
          <Input id="projectState" placeholder={t("form.statePlaceholder")} {...register("projectState")} className="mt-1" />
          {errors.projectState && <p className="text-sm text-destructive mt-1">{errors.projectState.message}</p>}
        </div>
      </div>
      <div>
        <Label htmlFor="projectZipCode">{t("form.zipCode")}</Label>
        <Input id="projectZipCode" placeholder={t("form.zipPlaceholder")} {...register("projectZipCode")} className="mt-1" />
      </div>
    </div>
  );
};

export default StepLocation;
