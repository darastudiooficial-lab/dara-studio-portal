import { z } from "zod";

export const CLIENT_TYPES = [
  { value: "cliente_final", label: "Homeowner" },
  { value: "construtor", label: "General Contractor" },
  { value: "arquiteto", label: "Architect" },
  { value: "engenheiro", label: "Engineer" },
  { value: "real_estate", label: "Real Estate Developer" },
] as const;

export const PROJECT_TYPES = [
  "Single-Family Residential",
  "Multi-Family Residential",
  "Commercial",
  "Renovation / Remodel",
  "Addition / Extension",
  "ADU (Accessory Dwelling Unit)",
  "Deck",
  "Garage (Attached / Detached)",
  "Other",
] as const;

export const PROJECT_LEVELS = [
  { id: "basement", label: "Basement" },
  { id: "first_floor", label: "First Floor" },
  { id: "second_floor", label: "Second Floor" },
  { id: "attic_loft", label: "Attic / Loft" },
  { id: "garage_level", label: "Garage Level" },
] as const;

export const BUILDING_STATUS_OPTIONS = [
  { value: "occupied", label: "Occupied" },
  { value: "under_construction", label: "Under Construction" },
  { value: "vacant", label: "Vacant" },
  { value: "new_construction", label: "N/A (New Construction)" },
] as const;

export const REQUIRED_SPACES = {
  privateSpaces: {
    title: "Private Spaces",
    spaces: [
      { id: "primary_suite", label: "Primary Suite" },
      { id: "secondary_bedroom", label: "Secondary Bedroom" },
      { id: "guest_bedroom", label: "Guest Bedroom" },
      { id: "flexible_room", label: "Flexible / Multi-Purpose Room" },
    ],
  },
  bathrooms: {
    title: "Bathrooms",
    spaces: [
      { id: "primary_bathroom", label: "Primary Bathroom" },
      { id: "full_bathroom", label: "Full Bathroom" },
      { id: "secondary_bathroom", label: "Secondary Bathroom" },
      { id: "powder_room", label: "Powder Room" },
    ],
  },
  socialAreas: {
    title: "Social Areas",
    spaces: [
      { id: "living_room", label: "Living Room" },
      { id: "family_room", label: "Family Room / TV Room" },
      { id: "dining_room", label: "Dining Room" },
      { id: "game_room", label: "Game Room" },
      { id: "library", label: "Library / Lounge" },
    ],
  },
  kitchenSupport: {
    title: "Kitchen & Support Spaces",
    spaces: [
      { id: "kitchen", label: "Kitchen" },
      { id: "pantry", label: "Pantry" },
      { id: "laundry", label: "Laundry Room" },
      { id: "mudroom", label: "Mudroom / Service Entry" },
      { id: "utility_room", label: "Utility / Storage Room" },
    ],
  },
  workWellness: {
    title: "Work & Wellness",
    spaces: [
      { id: "home_office", label: "Home Office" },
      { id: "home_gym", label: "Home Gym / Wellness Area" },
    ],
  },
  circulationStorage: {
    title: "Circulation & Storage",
    spaces: [
      { id: "entry_hall", label: "Entry Hall / Foyer" },
      { id: "hallways", label: "Hallways / Circulation" },
      { id: "walk_in_closet", label: "Walk-In Closet" },
      { id: "linen_closet", label: "Linen Closet" },
    ],
  },
  technicalAreas: {
    title: "Technical Areas",
    spaces: [
      { id: "mechanical_room", label: "Mechanical Room (HVAC / Boiler)" },
      { id: "electrical_panel", label: "Electrical Panel / Technical Room" },
      { id: "water_heater", label: "Water Heater Closet" },
    ],
  },
  outdoorAreas: {
    title: "Outdoor Areas",
    spaces: [
      { id: "porch_terrace", label: "Porch / Terrace" },
      { id: "covered_porch", label: "Covered Porch" },
      { id: "screened_porch", label: "Screened Porch" },
      { id: "deck", label: "Deck" },
      { id: "yard_patio", label: "Yard / Patio" },
      { id: "garage", label: "Garage" },
      { id: "exterior_storage", label: "Exterior Storage" },
      { id: "trash_recycling", label: "Trash & Recycling Area" },
    ],
  },
} as const;

export const TIMELINE_OPTIONS = [
  { id: "asap", label: "ASAP" },
  { id: "within_30_days", label: "Within 30 days" },
  { id: "1_3_months", label: "1–3 months" },
  { id: "3_plus_months", label: "3+ months" },
  { id: "flexible", label: "Flexible" },
] as const;

export const BUDGET_OPTIONS = [
  { id: "under_2500", label: "Under $2,500" },
  { id: "2500_5000", label: "$2,500 – $5,000" },
  { id: "5000_10000", label: "$5,000 – $10,000" },
  { id: "10000_plus", label: "$10,000+" },
  { id: "not_sure", label: "Not sure yet" },
] as const;

export const REFERRAL_OPTIONS = [
  { id: "google", label: "Google" },
  { id: "referral", label: "Referral" },
  { id: "social_media", label: "Social Media" },
  { id: "contractor", label: "Contractor" },
  { id: "returning_client", label: "Returning Client" },
  { id: "other", label: "Other" },
] as const;

export const DARA_SERVICES = {
  architecture: {
    title: "ARCHITECTURAL DESIGN & DRAFTING",
    services: [
      { id: "residential_arch", label: "Residential architectural design layouts" },
      { id: "floor_plans", label: "Technical floor plans for design coordination and permitting support" },
      { id: "sections_elevations", label: "Sections and elevations for visualization and documentation" },
      { id: "construction_details", label: "Construction details (design intent only)" },
      { id: "layout_studies", label: "Layout and space organization studies" },
      { id: "addition_renovation", label: "Addition and renovation design concepts" },
    ],
  },
  interiors: {
    title: "INTERIOR DESIGN & SPACE PLANNING",
    services: [
      { id: "interior_design", label: "Interior design concept development" },
      { id: "furniture_layout", label: "Furniture layout and space planning" },
      { id: "kitchen_bath", label: "Kitchen and bathroom design layouts" },
      { id: "custom_millwork", label: "Custom millwork design drawings" },
      { id: "finishes_materials", label: "Finishes and materials selection assistance" },
      { id: "fixtures_specification", label: "Fixtures, hardware, and plumbing specification support" },
    ],
  },
  visualization: {
    title: "3D VISUALIZATION",
    services: [
      { id: "exterior_renders", label: "Exterior renderings for presentation purposes" },
      { id: "interior_renders", label: "Interior renderings for design validation" },
    ],
  },
  documentation: {
    title: "TECHNICAL DRAFTING & DOCUMENTATION",
    services: [
      { id: "pdf_to_cad", label: "PDF to CAD conversion (technical redrawing)" },
      { id: "vectorization", label: "Vectorization of existing or legacy drawings" },
      { id: "technical_sheets", label: "Technical drawing set for coordination and review" },
    ],
  },
  construction: {
    title: "CONSTRUCTION COORDINATION SUPPORT",
    services: [
      { id: "project_adjustments", label: "Design adjustments for existing construction conditions" },
      { id: "as_built", label: "As-built drawings based on provided field information" },
    ],
  },
  additional: {
    title: "ADDITIONAL DESIGN SERVICES",
    services: [
      { id: "outdoor_design", label: "Outdoor living design concepts (deck, pool, patio)" },
      { id: "presentation_boards", label: "Presentation boards for clients and investors" },
    ],
  },
} as const;

export const formSchema = z.object({
  // Step 1 - Project Location
  projectAddress: z.string().min(1, "Address is required"),
  projectCity: z.string().min(1, "City is required"),
  projectState: z.string().min(1, "State is required"),
  projectZipCode: z.string().optional(),
  
  // Step 2 - Project Type & Info
  projectType: z.string().min(1, "Project type is required"),
  otherProjectType: z.string().optional(),
  hasExistingProject: z.enum(["yes", "no"], {
    required_error: "Please indicate if you have existing plans",
  }),
  hasEngineer: z.enum(["yes", "no"]).optional(),
  buildingStatus: z.string().optional(),
  
  // Project Size & Levels
  existingArea: z.string().optional(),
  estimatedSize: z.string().min(1, "Estimated project area is required"),
  projectLevels: z.array(z.string()).optional(),
  
  // File Uploads & References
  referenceNotes: z.string().optional(),
  referenceLinks: z.string().optional(),
  
  // Program of Requirements
  requiredSpaces: z.array(z.string()).optional(),
  otherSpace: z.string().optional(),
  
  // DARA Services
  selectedDaraServices: z.array(z.string()).optional(),
  
  // Legacy fields (kept for compatibility)
  totalArea: z.string().optional(),
  numberOfFloors: z.string().optional(),
  desiredServices: z.array(z.string()).optional(),
  
  // Step 3 - Client Info
  clientType: z.enum(["cliente_final", "construtor", "arquiteto", "engenheiro", "real_estate"], {
    required_error: "Please select your client type",
  }),
  fullName: z.string().min(2, "Full name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(10, "Invalid phone number"),
  // Company fields (required for construtor)
  companyName: z.string().optional(),
  companyAddress: z.string().optional(),
  companyInstagram: z.string().optional(),
  companyPhone: z.string().optional(),
  companyEmail: z.string().optional(),
  
  // Step 4 - Additional Details
  deadline: z.string().optional(),
  budget: z.string().optional(),
  description: z.string().optional(),
  howDidYouFindUs: z.string().optional(),
  acceptTerms: z.boolean().refine(val => val === true, {
    message: "You must accept the terms",
  }),
}).refine((data) => {
  // Company name is required for General Contractor
  if (data.clientType === "construtor" && !data.companyName) {
    return false;
  }
  return true;
}, {
  message: "Company name is required for General Contractors",
  path: ["companyName"],
});

export type FormData = z.infer<typeof formSchema>;

export const STEPS = [
  { id: 1, title: "Location" },
  { id: 2, title: "Project" },
  { id: 3, title: "Your Info" },
  { id: 4, title: "Details" },
] as const;

// Helper function to get all spaces as flat array for submission
export const getAllSpacesFlat = () => {
  const allSpaces: { id: string; label: string }[] = [];
  Object.values(REQUIRED_SPACES).forEach(category => {
    allSpaces.push(...category.spaces);
  });
  return allSpaces;
};
