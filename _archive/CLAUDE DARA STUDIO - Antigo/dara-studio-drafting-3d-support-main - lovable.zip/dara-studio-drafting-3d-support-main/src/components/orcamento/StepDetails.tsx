import { UseFormRegister, FieldErrors, UseFormWatch, UseFormSetValue } from "react-hook-form";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useLanguage } from "@/hooks/useLanguage";
import { FormData } from "./types";

interface StepDetailsProps {
  register: UseFormRegister<FormData>;
  errors: FieldErrors<FormData>;
  watch: UseFormWatch<FormData>;
  setValue: UseFormSetValue<FormData>;
}

const timelineKeys = [
  { id: "asap", key: "timeline.asap" },
  { id: "within_30_days", key: "timeline.within30" },
  { id: "1_3_months", key: "timeline.1to3months" },
  { id: "3_plus_months", key: "timeline.3plusMonths" },
  { id: "flexible", key: "timeline.flexible" },
];

const budgetKeys = [
  { id: "under_2500", key: "budget.under2500" },
  { id: "2500_5000", key: "budget.2500to5000" },
  { id: "5000_10000", key: "budget.5000to10000" },
  { id: "10000_plus", key: "budget.10000plus" },
  { id: "not_sure", key: "budget.notSure" },
];

const referralKeys = [
  { id: "google", key: "referral.google" },
  { id: "referral", key: "referral.referral" },
  { id: "social_media", key: "referral.socialMedia" },
  { id: "contractor", key: "referral.contractor" },
  { id: "returning_client", key: "referral.returningClient" },
  { id: "other", key: "referral.other" },
];

const StepDetails = ({ register, errors, watch, setValue }: StepDetailsProps) => {
  const { t } = useLanguage();

  return (
    <div className="space-y-8">
      <div className="space-y-3">
        <Label className="text-base font-semibold">{t("form.desiredTimeline")}</Label>
        <p className="text-sm text-muted-foreground">{t("form.whenStart")}</p>
        <RadioGroup value={watch("deadline") || ""} onValueChange={(value) => setValue("deadline", value)} className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {timelineKeys.map((option) => (
            <div key={option.id} className="flex items-center space-x-2">
              <RadioGroupItem value={option.id} id={`timeline-${option.id}`} />
              <Label htmlFor={`timeline-${option.id}`} className="text-sm cursor-pointer">{t(option.key)}</Label>
            </div>
          ))}
        </RadioGroup>
      </div>

      <div className="space-y-3">
        <Label className="text-base font-semibold">{t("form.estimatedInvestment")}</Label>
        <p className="text-sm text-muted-foreground">{t("form.investmentDesc")}</p>
        <RadioGroup value={watch("budget") || ""} onValueChange={(value) => setValue("budget", value)} className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {budgetKeys.map((option) => (
            <div key={option.id} className="flex items-center space-x-2">
              <RadioGroupItem value={option.id} id={`budget-${option.id}`} />
              <Label htmlFor={`budget-${option.id}`} className="text-sm cursor-pointer">{t(option.key)}</Label>
            </div>
          ))}
        </RadioGroup>
        <p className="text-xs text-muted-foreground italic">{t("form.investmentNote")}</p>
      </div>

      <div className="space-y-3">
        <Label className="text-base font-semibold">{t("form.howHear")}</Label>
        <RadioGroup value={watch("howDidYouFindUs") || ""} onValueChange={(value) => setValue("howDidYouFindUs", value)} className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {referralKeys.map((option) => (
            <div key={option.id} className="flex items-center space-x-2">
              <RadioGroupItem value={option.id} id={`referral-${option.id}`} />
              <Label htmlFor={`referral-${option.id}`} className="text-sm cursor-pointer">{t(option.key)}</Label>
            </div>
          ))}
        </RadioGroup>
      </div>

      <div className="space-y-3">
        <Label htmlFor="description" className="text-base font-semibold">{t("form.additionalNotes")}</Label>
        <p className="text-sm text-muted-foreground">{t("form.additionalNotesDesc")}</p>
        <Textarea id="description" placeholder={t("form.additionalNotesPlaceholder")} {...register("description")} className="min-h-[120px]" />
      </div>

      <div className="border-t pt-6">
        <div className="flex items-start space-x-3">
          <Checkbox id="acceptTerms" checked={watch("acceptTerms")} onCheckedChange={(checked) => setValue("acceptTerms", checked as boolean)} className="mt-0.5" />
          <Label htmlFor="acceptTerms" className="text-sm cursor-pointer leading-relaxed">
            {t("form.agreement")}{" "}
            <span className="text-primary underline">{t("form.termsOfUse")}</span> {t("form.and")}{" "}
            <span className="text-primary underline">{t("form.privacyPolicy")}</span>. *
          </Label>
        </div>
        {errors.acceptTerms && <p className="text-sm text-destructive mt-2">{errors.acceptTerms.message}</p>}
      </div>
    </div>
  );
};

export default StepDetails;
