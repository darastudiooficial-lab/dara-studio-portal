import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import {
  Download, Upload, FolderOpen, FileText, ChevronRight, Trash2, Plus,
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

const DOCUMENT_CATEGORIES = [
  { value: "pre_construction", label: "Pre-Construction", icon: "📁" },
  { value: "rev_00", label: "REV 00", icon: "📁" },
  { value: "rev_01", label: "REV 01", icon: "📁" },
  { value: "rev_02", label: "REV 02", icon: "📁" },
  { value: "rev_03", label: "REV 03 (Final)", icon: "📁" },
  { value: "final_delivery", label: "Final Delivery", icon: "📁" },
  { value: "general", label: "General", icon: "📁" },
] as const;

type DocCategory = typeof DOCUMENT_CATEGORIES[number]["value"];

interface ProjectDocumentsProps {
  projectId: string;
}

const ProjectDocuments = ({ projectId }: ProjectDocumentsProps) => {
  const [files, setFiles] = useState<any[]>([]);
  const [openFolders, setOpenFolders] = useState<Set<string>>(new Set(["pre_construction", "rev_00"]));
  const [uploading, setUploading] = useState(false);
  const [uploadCategory, setUploadCategory] = useState<DocCategory>("general");
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);

  const loadFiles = useCallback(async () => {
    const { data } = await supabase
      .from("project_files")
      .select("*")
      .eq("project_id", projectId)
      .order("created_at", { ascending: false });
    setFiles(data || []);
  }, [projectId]);

  useEffect(() => { loadFiles(); }, [loadFiles]);

  const toggleFolder = (cat: string) => {
    setOpenFolders(prev => {
      const next = new Set(prev);
      next.has(cat) ? next.delete(cat) : next.add(cat);
      return next;
    });
  };

  const handleUpload = async () => {
    if (!selectedFiles || selectedFiles.length === 0) return;
    setUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      for (const file of Array.from(selectedFiles)) {
        const ext = file.name.split(".").pop();
        const path = `${projectId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
        const { error: uploadError } = await supabase.storage.from("project-files").upload(path, file);
        if (uploadError) { toast.error(`Upload failed: ${file.name}`); continue; }
        const { data: urlData } = supabase.storage.from("project-files").getPublicUrl(path);
        await supabase.from("project_files").insert({
          project_id: projectId,
          file_name: file.name,
          file_url: urlData.publicUrl,
          file_type: file.type || ext,
          file_size: file.size,
          uploaded_by: user?.id || null,
          document_category: uploadCategory,
        });
      }
      toast.success("Files uploaded");
      setSelectedFiles(null);
      loadFiles();
    } catch { toast.error("Upload error"); }
    setUploading(false);
  };

  const handleDelete = async (fileId: string) => {
    const { error } = await supabase.from("project_files").delete().eq("id", fileId);
    if (error) { toast.error("Delete failed"); return; }
    toast.success("File deleted");
    loadFiles();
  };

  const handleCategoryChange = async (fileId: string, newCategory: string) => {
    const { error } = await supabase.from("project_files").update({ document_category: newCategory }).eq("id", fileId);
    if (error) { toast.error("Update failed"); return; }
    loadFiles();
  };

  const grouped = DOCUMENT_CATEGORIES.reduce((acc, cat) => {
    acc[cat.value] = files.filter(f => (f.document_category || "general") === cat.value);
    return acc;
  }, {} as Record<string, any[]>);

  const formatSize = (bytes: number | null) => {
    if (!bytes) return "—";
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-4">
      {/* Upload Bar */}
      <Card className="border-none shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center gap-3 flex-wrap">
            <Select value={uploadCategory} onValueChange={(v) => setUploadCategory(v as DocCategory)}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Select folder" />
              </SelectTrigger>
              <SelectContent>
                {DOCUMENT_CATEGORIES.map(c => (
                  <SelectItem key={c.value} value={c.value}>{c.icon} {c.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input
              type="file"
              multiple
              className="max-w-xs"
              onChange={e => setSelectedFiles(e.target.files)}
            />
            <Button onClick={handleUpload} disabled={uploading || !selectedFiles?.length} size="sm">
              <Upload className="h-3.5 w-3.5 mr-1.5" />
              {uploading ? "Uploading..." : "Upload"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Folder Tree */}
      <Card className="border-none shadow-sm">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Project Documents</CardTitle>
            <Badge variant="secondary">{files.length} files</Badge>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-border">
            {DOCUMENT_CATEGORIES.map(cat => {
              const catFiles = grouped[cat.value];
              const isOpen = openFolders.has(cat.value);
              return (
                <Collapsible key={cat.value} open={isOpen} onOpenChange={() => toggleFolder(cat.value)}>
                  <CollapsibleTrigger className="flex items-center gap-3 w-full px-4 py-3 hover:bg-muted/50 transition-colors text-left">
                    <ChevronRight className={`h-4 w-4 text-muted-foreground transition-transform ${isOpen ? "rotate-90" : ""}`} />
                    <FolderOpen className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium text-foreground flex-1">{cat.label}</span>
                    <Badge variant="outline" className="text-[10px]">{catFiles.length}</Badge>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    {catFiles.length === 0 ? (
                      <div className="px-12 py-4 text-xs text-muted-foreground italic">No files in this folder</div>
                    ) : (
                      <div className="pb-2">
                        {catFiles.map(f => (
                          <div key={f.id} className="flex items-center gap-3 px-12 py-2 hover:bg-muted/30 transition-colors group">
                            <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-foreground truncate">{f.file_name}</p>
                              <p className="text-[11px] text-muted-foreground">
                                {formatSize(f.file_size)} · {format(new Date(f.created_at), "MMM d, yyyy")}
                              </p>
                            </div>
                            <Select
                              value={f.document_category || "general"}
                              onValueChange={(v) => handleCategoryChange(f.id, v)}
                            >
                              <SelectTrigger className="w-32 h-7 text-[11px] opacity-0 group-hover:opacity-100 transition-opacity">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {DOCUMENT_CATEGORIES.map(c => (
                                  <SelectItem key={c.value} value={c.value} className="text-xs">{c.label}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" asChild>
                              <a href={f.file_url} target="_blank" rel="noopener noreferrer"><Download className="h-3.5 w-3.5" /></a>
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7 shrink-0 opacity-0 group-hover:opacity-100 text-destructive hover:text-destructive"
                              onClick={() => handleDelete(f.id)}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </CollapsibleContent>
                </Collapsible>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProjectDocuments;
