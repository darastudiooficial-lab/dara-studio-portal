import { LucideIcon } from "lucide-react";
import {
  CheckCircle2, Clock, DollarSign, FileText, Send,
  MessageSquare, Star, Package, Truck,
} from "lucide-react";

// ── Event definitions ──

export interface EventDef {
  type: string;
  label: string;
  icon: LucideIcon;
}

export const REV_EVENTS = (rev: number): EventDef[] => {
  if (rev === 0) return [
    { type: "estimate_created", label: "Estimate Created", icon: FileText },
    { type: "initial_invoice_sent", label: "Initial Invoice Sent", icon: Send },
    { type: "initial_payment_received", label: "Initial Payment Received", icon: DollarSign },
    { type: "rev_started", label: `REV 0${rev} Started`, icon: Clock },
    { type: "rev_preview_sent", label: `REV 0${rev} Preview Sent`, icon: Send },
    { type: "client_feedback", label: `Client Feedback REV 0${rev}`, icon: MessageSquare },
  ];
  return [
    { type: "rev_started", label: `REV ${String(rev).padStart(2, "0")} Started`, icon: Clock },
    { type: "rev_preview_sent", label: `REV ${String(rev).padStart(2, "0")} Preview Sent`, icon: Send },
    { type: "client_feedback", label: `Client Feedback REV ${String(rev).padStart(2, "0")}`, icon: MessageSquare },
  ];
};

export const FINAL_EVENTS: EventDef[] = [
  { type: "invoice_sent_auto", label: "Invoice Sent", icon: Send },
  { type: "payment_received_auto", label: "Payment Received", icon: DollarSign },
  { type: "project_approved", label: "Project Approved", icon: Star },
  { type: "final_documents", label: "Final Documents", icon: FileText },
  { type: "final_payment", label: "Final Payment", icon: DollarSign },
  { type: "project_completed", label: "Project Completed", icon: CheckCircle2 },
  { type: "project_delivered", label: "Project Delivered", icon: Truck },
];

// ── Types ──

export interface TimelineEvent {
  id: string;
  project_id: string;
  revision_number: number;
  event_type: string;
  event_date: string | null;
  notes: string | null;
  created_at: string;
}

export type RevStatus = "not_started" | "in_progress" | "completed";
export type AlertLevel = "on_track" | "waiting_client" | "delayed" | "overdue";

export const STATUS_CONFIG: Record<RevStatus, { label: string; icon: string; classes: string }> = {
  not_started: { label: "Not Started", icon: "⚪", classes: "bg-muted text-muted-foreground" },
  in_progress: { label: "In Progress", icon: "🟡", classes: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400" },
  completed: { label: "Completed", icon: "✅", classes: "bg-chart-2/15 text-chart-2" },
};

export const ALERT_CONFIG: Record<AlertLevel, { label: string; icon: string; classes: string }> = {
  on_track: { label: "On Track", icon: "🟢", classes: "bg-chart-2/15 text-chart-2" },
  waiting_client: { label: "Waiting Client", icon: "🟡", classes: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400" },
  delayed: { label: "Delayed", icon: "🔴", classes: "bg-destructive/15 text-destructive" },
  overdue: { label: "Overdue", icon: "⚫", classes: "bg-destructive/15 text-destructive" },
};

// ── Status logic ──

export function getRevisionStatus(revNum: number, events: TimelineEvent[]): RevStatus {
  const revEvents = REV_EVENTS(revNum);
  const completed = revEvents.filter(ev =>
    events.some(e => e.revision_number === revNum && e.event_type === ev.type && e.event_date)
  ).length;
  if (completed === 0) return "not_started";
  if (completed === revEvents.length) return "completed";
  return "in_progress";
}

// ── Alert logic ──

const WAITING_CLIENT_DAYS = 3;
const DELAYED_DAYS = 5;

export function getRevisionAlert(revNum: number, events: TimelineEvent[]): AlertLevel | null {
  const revEvents = REV_EVENTS(revNum);
  const status = getRevisionStatus(revNum, events);
  if (status === "completed" || status === "not_started") return null;

  const getRecord = (type: string) =>
    events.find(e => e.revision_number === revNum && e.event_type === type);

  // Check: Preview sent but no feedback
  const previewSent = getRecord("rev_preview_sent");
  const feedback = getRecord("client_feedback");
  if (previewSent?.event_date && !feedback?.event_date) {
    const daysSince = Math.floor((Date.now() - new Date(previewSent.event_date).getTime()) / (1000 * 60 * 60 * 24));
    if (daysSince >= WAITING_CLIENT_DAYS) return "waiting_client";
  }

  // Check: Rev started but no preview sent
  const revStarted = getRecord("rev_started");
  const previewSentCheck = getRecord("rev_preview_sent");
  if (revStarted?.event_date && !previewSentCheck?.event_date) {
    const daysSince = Math.floor((Date.now() - new Date(revStarted.event_date).getTime()) / (1000 * 60 * 60 * 24));
    if (daysSince >= DELAYED_DAYS) return "delayed";
  }

  return null;
}

export function getOverallAlert(events: TimelineEvent[], deliveryDate?: string): AlertLevel {
  // Check overdue
  if (deliveryDate) {
    const deadline = new Date(deliveryDate);
    const isCompleted = events.some(e => e.event_type === "project_completed" && e.event_date);
    const isDelivered = events.some(e => e.event_type === "project_delivered" && e.event_date);
    if (deadline < new Date() && !isCompleted && !isDelivered) return "overdue";
  }

  // Check all revisions for worst alert
  const maxRev = events.reduce((m, e) => Math.max(m, e.revision_number), 3);
  let worstAlert: AlertLevel = "on_track";
  for (let i = 0; i <= maxRev; i++) {
    const alert = getRevisionAlert(i, events);
    if (alert === "delayed") return "delayed";
    if (alert === "waiting_client") worstAlert = "waiting_client";
  }
  return worstAlert;
}

// ── Timeline progress ──

export function getTimelineProgress(events: TimelineEvent[], maxRevision: number): number {
  let totalEvents = 0;
  let completedEvents = 0;

  for (let i = 0; i <= maxRevision; i++) {
    const revEvents = REV_EVENTS(i);
    totalEvents += revEvents.length;
    completedEvents += revEvents.filter(ev =>
      events.some(e => e.revision_number === i && e.event_type === ev.type && e.event_date)
    ).length;
  }

  // Final events (non-auto only)
  const manualFinals = FINAL_EVENTS.filter(e => e.type !== "invoice_sent_auto" && e.type !== "payment_received_auto");
  totalEvents += manualFinals.length;
  completedEvents += manualFinals.filter(ev =>
    events.some(e => e.revision_number === -1 && e.event_type === ev.type && e.event_date)
  ).length;

  return totalEvents > 0 ? Math.round((completedEvents / totalEvents) * 100) : 0;
}

// ── Auto stage derivation ──

export function deriveStageFromTimeline(events: TimelineEvent[], maxRevision: number): string | null {
  const has = (rev: number, type: string) =>
    events.some(e => e.revision_number === rev && e.event_type === type && e.event_date);
  const hasFinal = (type: string) =>
    events.some(e => e.revision_number === -1 && e.event_type === type && e.event_date);

  // Check from end to start
  if (hasFinal("project_delivered")) return "DELIVERED";
  if (hasFinal("project_completed")) return "COMPLETED";
  if (hasFinal("project_approved")) return "APPROVED";

  // Check revisions from highest to lowest
  for (let rev = maxRevision; rev >= 0; rev--) {
    if (has(rev, "rev_preview_sent")) return `PREVIEW_SENT_REV_${String(rev).padStart(2, "0")}`;
    if (has(rev, "rev_started")) return `IN_PROGRESS_REV_${String(rev).padStart(2, "0")}`;
  }

  // Check initial events
  if (has(0, "initial_payment_received")) return "READY_TO_START";
  if (has(0, "initial_invoice_sent")) return "WAITING_INITIAL_PAYMENT";

  return null;
}

// ── Deadline helpers ──

export function getRevisionDelay(revNum: number, events: TimelineEvent[], expectedDaysPerRev: number = 3): { delayed: boolean; days: number } | null {
  const revStarted = events.find(e => e.revision_number === revNum && e.event_type === "rev_started" && e.event_date);
  const previewSent = events.find(e => e.revision_number === revNum && e.event_type === "rev_preview_sent" && e.event_date);

  if (!revStarted?.event_date) return null;
  if (previewSent?.event_date) return { delayed: false, days: 0 };

  const startDate = new Date(revStarted.event_date);
  const expected = new Date(startDate);
  expected.setDate(expected.getDate() + expectedDaysPerRev);

  const today = new Date();
  if (today > expected) {
    const delayDays = Math.floor((today.getTime() - expected.getTime()) / (1000 * 60 * 60 * 24));
    return { delayed: true, days: delayDays };
  }
  return { delayed: false, days: 0 };
}
