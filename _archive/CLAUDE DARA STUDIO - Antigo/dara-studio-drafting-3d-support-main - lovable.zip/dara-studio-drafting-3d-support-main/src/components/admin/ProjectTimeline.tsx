import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Progress } from "@/components/ui/progress";
import {
  Plus, CheckCircle2, Clock, DollarSign, FileText, Send,
  MessageSquare, Star, Package, Truck, ChevronDown, ChevronsUpDown,
  Trash2, RotateCcw, AlertTriangle,
} from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useIsMobile } from "@/hooks/use-mobile";
import {
  REV_EVENTS, FINAL_EVENTS, TimelineEvent, STATUS_CONFIG, ALERT_CONFIG,
  getRevisionStatus, getRevisionAlert, getOverallAlert,
  getTimelineProgress, deriveStageFromTimeline, getRevisionDelay,
} from "./timeline/timelineUtils";

interface Props {
  projectId: string;
  deliveryDate?: string;
  dates?: {
    start_date?: string;
    delivery_date?: string;
    preview_delivery_date?: string;
    revision_return_date?: string;
    final_delivery_date?: string;
  };
  onDateChange?: (field: string, value: string) => void;
  onStageSync?: (stage: string) => void;
}

export default function ProjectTimeline({ projectId, deliveryDate, dates, onDateChange, onStageSync }: Props) {
  const [events, setEvents] = useState<TimelineEvent[]>([]);
  const [maxRevision, setMaxRevision] = useState(3);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [extraRevAmount, setExtraRevAmount] = useState("");
  const [addEventDialog, setAddEventDialog] = useState(false);
  const [newEvent, setNewEvent] = useState({ revision_number: 0, event_type: "", event_date: "", notes: "" });
  const [openRevisions, setOpenRevisions] = useState<Record<number, boolean>>({ 0: true });
  const [finalizationOpen, setFinalizationOpen] = useState(true);
  const isMobile = useIsMobile();

  const fetchEvents = useCallback(async () => {
    const { data } = await supabase
      .from("project_timeline")
      .select("*")
      .eq("project_id", projectId)
      .order("revision_number")
      .order("created_at");
    const list = (data as TimelineEvent[]) || [];
    setEvents(list);
    const highestRev = list.reduce((m, e) => Math.max(m, e.revision_number), 3);
    setMaxRevision(highestRev < 3 ? 3 : highestRev);
  }, [projectId]);

  useEffect(() => { fetchEvents(); }, [fetchEvents]);

  // Auto-sync stage from timeline events
  useEffect(() => {
    if (!onStageSync || events.length === 0) return;
    const derivedStage = deriveStageFromTimeline(events, maxRevision);
    if (derivedStage) onStageSync(derivedStage);
  }, [events, maxRevision, onStageSync]);

  // Auto-log activity on event changes
  const logActivity = async (description: string) => {
    await supabase.from("activity_log").insert({
      project_id: projectId,
      log_type: "timeline_event",
      description,
    });
  };

  const toggleAllRevisions = (expand: boolean) => {
    const newState: Record<number, boolean> = {};
    for (let i = 0; i <= maxRevision; i++) newState[i] = expand;
    setOpenRevisions(newState);
    setFinalizationOpen(expand);
  };

  const markEvent = async (revNum: number, eventType: string) => {
    const existing = events.find(e => e.revision_number === revNum && e.event_type === eventType);
    if (existing) return; // Use delete button instead
    await supabase.from("project_timeline").insert({
      project_id: projectId,
      revision_number: revNum,
      event_type: eventType,
      event_date: format(new Date(), "yyyy-MM-dd"),
    });
    // Find label
    const allEvents = revNum === -1 ? FINAL_EVENTS : REV_EVENTS(revNum);
    const evDef = allEvents.find(e => e.type === eventType);
    await logActivity(`${evDef?.label || eventType} – ${format(new Date(), "MMM d")}`);
    toast.success("Event recorded");
    fetchEvents();
  };

  const deleteEvent = async (eventId: string, label: string) => {
    await supabase.from("project_timeline").delete().eq("id", eventId);
    await logActivity(`${label} removed – ${format(new Date(), "MMM d")}`);
    toast.success("Event deleted");
    fetchEvents();
  };

  const resetEvent = async (eventId: string, label: string) => {
    await supabase.from("project_timeline").update({ event_date: null }).eq("id", eventId);
    await logActivity(`${label} reset – ${format(new Date(), "MMM d")}`);
    toast.success("Event reset");
    fetchEvents();
  };

  const updateEventDate = async (eventId: string, date: string) => {
    await supabase.from("project_timeline").update({ event_date: date }).eq("id", eventId);
    fetchEvents();
  };

  const handleAddExtraRevision = async () => {
    const newRev = maxRevision + 1;
    const revEvents = REV_EVENTS(newRev);
    await supabase.from("project_timeline").insert(
      revEvents.map(e => ({
        project_id: projectId,
        revision_number: newRev,
        event_type: e.type,
        event_date: null,
        notes: null,
      }))
    );
    if (extraRevAmount && Number(extraRevAmount) > 0) {
      await supabase.from("payment_milestones").insert({
        project_id: projectId,
        stage: `Extra Revision REV ${String(newRev).padStart(2, "0")}`,
        percentage: 0,
        amount: Number(extraRevAmount),
        status: "pending",
      });
    }
    await logActivity(`Extra Revision REV ${String(newRev).padStart(2, "0")} added – ${format(new Date(), "MMM d")}`);
    toast.success(`Extra Revision REV ${String(newRev).padStart(2, "0")} added`);
    setDialogOpen(false);
    setExtraRevAmount("");
    setOpenRevisions(prev => ({ ...prev, [newRev]: true }));
    fetchEvents();
  };

  const handleAddCustomEvent = async () => {
    if (!newEvent.event_type.trim()) { toast.error("Event type required"); return; }
    await supabase.from("project_timeline").insert({
      project_id: projectId,
      revision_number: newEvent.revision_number,
      event_type: newEvent.event_type,
      event_date: newEvent.event_date || null,
      notes: newEvent.notes || null,
    });
    await logActivity(`Custom event: ${newEvent.event_type} – ${format(new Date(), "MMM d")}`);
    toast.success("Event added");
    setAddEventDialog(false);
    setNewEvent({ revision_number: 0, event_type: "", event_date: "", notes: "" });
    fetchEvents();
  };

  const getEventRecord = (revNum: number, eventType: string) =>
    events.find(e => e.revision_number === revNum && e.event_type === eventType);

  // Overall stats
  const overallAlert = getOverallAlert(events, deliveryDate || dates?.delivery_date);
  const alertCfg = ALERT_CONFIG[overallAlert];
  const progressPct = getTimelineProgress(events, maxRevision);

  const renderEventRow = (ev: { type: string; label: string; icon: React.ElementType }, revNum: number) => {
    const record = getEventRecord(revNum, ev.type);
    const Icon = ev.icon;
    return (
      <div
        key={ev.type}
        className={cn(
          "flex items-center gap-2 px-3 py-2 rounded-md transition-colors group",
          record?.event_date ? "bg-chart-2/5" : "bg-transparent hover:bg-muted/50"
        )}
      >
        {/* Click to mark */}
        <button
          className={cn(
            "h-6 w-6 rounded-full flex items-center justify-center shrink-0 transition-colors",
            record?.event_date
              ? "bg-chart-2/20 text-chart-2"
              : "bg-muted text-muted-foreground hover:bg-primary/20 hover:text-primary cursor-pointer"
          )}
          onClick={() => !record?.event_date && markEvent(revNum, ev.type)}
          disabled={!!record?.event_date}
        >
          {record?.event_date ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Icon className="h-3.5 w-3.5" />}
        </button>

        <div className="flex-1 min-w-0">
          <p className={cn("text-sm", record?.event_date ? "text-foreground font-medium" : "text-muted-foreground")}>
            {ev.label}
          </p>
        </div>

        {record?.event_date && (
          <span className="text-xs text-muted-foreground shrink-0 hidden sm:block">
            {format(new Date(record.event_date), "MMM d, yyyy")}
          </span>
        )}

        {record && (
          <>
            <Input
              type="date"
              className="w-[120px] h-7 text-xs hidden sm:block"
              value={record.event_date || ""}
              onClick={e => e.stopPropagation()}
              onChange={e => updateEventDate(record.id, e.target.value)}
            />
            <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                title="Reset event"
                onClick={() => resetEvent(record.id, ev.label)}
              >
                <RotateCcw className="h-3 w-3 text-muted-foreground" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                title="Delete event"
                onClick={() => deleteEvent(record.id, ev.label)}
              >
                <Trash2 className="h-3 w-3 text-destructive" />
              </Button>
            </div>
          </>
        )}
      </div>
    );
  };

  const renderRevisionBlock = (revNum: number) => {
    const revEvents = REV_EVENTS(revNum);
    const isExtra = revNum > 3;
    const revLabel = `REV ${String(revNum).padStart(2, "0")}`;
    const status = getRevisionStatus(revNum, events);
    const statusCfg = STATUS_CONFIG[status];
    const alert = getRevisionAlert(revNum, events);
    const delay = getRevisionDelay(revNum, events);
    const completedCount = revEvents.filter(ev => getEventRecord(revNum, ev.type)?.event_date).length;
    const isOpen = openRevisions[revNum] ?? false;

    return (
      <Collapsible
        key={`rev-${revNum}`}
        open={isOpen}
        onOpenChange={(open) => setOpenRevisions(prev => ({ ...prev, [revNum]: open }))}
      >
        <Card className={cn(
          "border shadow-sm",
          isExtra && "border-l-4 border-l-chart-4",
          alert === "delayed" && "border-destructive/50",
          alert === "waiting_client" && "border-yellow-400/50 dark:border-yellow-600/50"
        )}>
          <CollapsibleTrigger asChild>
            <CardHeader className="pb-2 cursor-pointer hover:bg-muted/30 transition-colors">
              <CardTitle className="text-sm flex items-center gap-2 flex-wrap">
                <Package className="h-4 w-4 text-muted-foreground" />
                {revLabel}
                {revNum === 0 && <Badge variant="secondary" className="text-[10px]">Início</Badge>}
                {revNum === 3 && <Badge variant="secondary" className="text-[10px]">Final</Badge>}
                {isExtra && <Badge className="text-[10px] bg-chart-4/15 text-chart-4 border-chart-4/30">Extra</Badge>}
                <Badge className={cn("text-[10px] border-0", statusCfg.classes)}>
                  {statusCfg.icon} {statusCfg.label}
                </Badge>
                {alert && (
                  <Badge className={cn("text-[10px] border-0", ALERT_CONFIG[alert].classes)}>
                    {ALERT_CONFIG[alert].icon} {ALERT_CONFIG[alert].label}
                  </Badge>
                )}
                {delay?.delayed && (
                  <span className="text-[10px] text-destructive font-medium">
                    +{delay.days}d late
                  </span>
                )}
                <span className="ml-auto text-xs text-muted-foreground font-normal">{completedCount}/{revEvents.length}</span>
                <ChevronDown className={cn("h-4 w-4 text-muted-foreground transition-transform", isOpen && "rotate-180")} />
              </CardTitle>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="space-y-0.5 pt-0">
              {revEvents.map(ev => renderEventRow(ev, revNum))}
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>
    );
  };

  const renderFinalBlock = () => (
    <Collapsible open={finalizationOpen} onOpenChange={setFinalizationOpen}>
      <Card className="border shadow-sm">
        <CollapsibleTrigger asChild>
          <CardHeader className="pb-2 cursor-pointer hover:bg-muted/30 transition-colors">
            <CardTitle className="text-sm flex items-center gap-2">
              <Star className="h-4 w-4 text-chart-2" /> Finalização
              <ChevronDown className={cn("h-4 w-4 text-muted-foreground ml-auto transition-transform", finalizationOpen && "rotate-180")} />
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="space-y-0.5 pt-0">
            {FINAL_EVENTS.map(ev => {
              const isAutoType = ev.type === "invoice_sent_auto" || ev.type === "payment_received_auto";
              const autoRecords = isAutoType ? events.filter(e => e.revision_number === -1 && e.event_type === ev.type) : [];
              const Icon = ev.icon;

              if (isAutoType && autoRecords.length > 0) {
                return autoRecords.map(ar => (
                  <div key={ar.id} className="flex items-center gap-2 px-3 py-2 rounded-md bg-chart-2/5">
                    <div className="h-6 w-6 rounded-full flex items-center justify-center shrink-0 bg-chart-2/20 text-chart-2">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-foreground font-medium">{ev.label}</p>
                      {ar.notes && <p className="text-xs text-muted-foreground truncate">{ar.notes}</p>}
                    </div>
                    {ar.event_date && (
                      <span className="text-xs text-muted-foreground shrink-0">
                        {format(new Date(ar.event_date), "MMM d, yyyy")}
                      </span>
                    )}
                  </div>
                ));
              }

              if (isAutoType) {
                return (
                  <div key={ev.type} className="flex items-center gap-2 px-3 py-2 rounded-md bg-transparent opacity-50">
                    <div className="h-6 w-6 rounded-full flex items-center justify-center shrink-0 bg-muted text-muted-foreground">
                      <Icon className="h-3.5 w-3.5" />
                    </div>
                    <p className="text-sm text-muted-foreground">{ev.label}</p>
                    <span className="text-[10px] text-muted-foreground ml-auto">Auto-tracked</span>
                  </div>
                );
              }

              return renderEventRow(ev, -1);
            })}
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );

  const revisionNumbers = Array.from({ length: maxRevision + 1 }, (_, i) => i);

  return (
    <div className="space-y-4">
      {/* Overall Status Bar */}
      <Card className="border shadow-sm">
        <CardContent className="py-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Badge className={cn("text-xs border-0", alertCfg.classes)}>
                {alertCfg.icon} {alertCfg.label}
              </Badge>
              <span className="text-sm text-muted-foreground">Timeline Progress</span>
            </div>
            <span className="text-sm font-semibold">{progressPct}%</span>
          </div>
          <Progress value={progressPct} className="h-2" />
          {overallAlert === "overdue" && (
            <div className="flex items-center gap-2 text-xs text-destructive">
              <AlertTriangle className="h-3.5 w-3.5" />
              Project is past deadline
            </div>
          )}
          {overallAlert === "waiting_client" && (
            <div className="flex items-center gap-2 text-xs text-yellow-700 dark:text-yellow-400">
              <Clock className="h-3.5 w-3.5" />
              Waiting for client feedback
            </div>
          )}
          {overallAlert === "delayed" && (
            <div className="flex items-center gap-2 text-xs text-destructive">
              <AlertTriangle className="h-3.5 w-3.5" />
              One or more revisions are delayed
            </div>
          )}
        </CardContent>
      </Card>

      {/* Date fields */}
      {dates && onDateChange && (
        <Card className="border shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Key Dates</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <Label className="text-xs text-muted-foreground">Start Date</Label>
                <Input type="date" className="mt-1" value={dates.start_date || ""} onChange={e => onDateChange("start_date", e.target.value)} />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Preview Delivery</Label>
                <Input type="date" className="mt-1" value={dates.preview_delivery_date || ""} onChange={e => onDateChange("preview_delivery_date", e.target.value)} />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Client Revision Return</Label>
                <Input type="date" className="mt-1" value={dates.revision_return_date || ""} onChange={e => onDateChange("revision_return_date", e.target.value)} />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Final Delivery</Label>
                <Input type="date" className="mt-1" value={dates.final_delivery_date || ""} onChange={e => onDateChange("final_delivery_date", e.target.value)} />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Project Deadline</Label>
                <Input type="date" className="mt-1" value={dates.delivery_date || ""} onChange={e => onDateChange("delivery_date", e.target.value)} />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Expand/Collapse All */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={() => toggleAllRevisions(true)} className="text-xs gap-1">
          <ChevronsUpDown className="h-3.5 w-3.5" /> Expand All
        </Button>
        <Button variant="ghost" size="sm" onClick={() => toggleAllRevisions(false)} className="text-xs gap-1">
          Collapse All
        </Button>
      </div>

      {/* Revision blocks in responsive grid */}
      <div className={cn("grid gap-4", isMobile ? "grid-cols-1" : "grid-cols-1 lg:grid-cols-2")}>
        {revisionNumbers.map(revNum => renderRevisionBlock(revNum))}
        {renderFinalBlock()}
      </div>

      {/* Actions */}
      <div className="flex gap-2">
        <Button variant="outline" onClick={() => setDialogOpen(true)}>
          <Plus className="h-3.5 w-3.5 mr-1" /> Add Extra Revision
        </Button>
        <Button variant="ghost" onClick={() => setAddEventDialog(true)}>
          <Plus className="h-3.5 w-3.5 mr-1" /> Add Custom Event
        </Button>
      </div>

      {/* Extra Revision Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Add Extra Revision (REV {String(maxRevision + 1).padStart(2, "0")})</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Invoice Amount (optional)</Label>
              <Input type="number" placeholder="e.g. 500" value={extraRevAmount} onChange={e => setExtraRevAmount(e.target.value)} className="mt-1" />
              <p className="text-xs text-muted-foreground mt-1">A payment milestone will be created for this extra revision.</p>
            </div>
            <Button className="w-full" onClick={handleAddExtraRevision}>Create Extra Revision</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Custom Event Dialog */}
      <Dialog open={addEventDialog} onOpenChange={setAddEventDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Add Custom Event</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Event Type</Label>
              <Input value={newEvent.event_type} onChange={e => setNewEvent(n => ({ ...n, event_type: e.target.value }))} placeholder="e.g. Client Meeting" className="mt-1" />
            </div>
            <div>
              <Label>Revision #</Label>
              <Select value={String(newEvent.revision_number)} onValueChange={v => setNewEvent(n => ({ ...n, revision_number: Number(v) }))}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="-1">Finalização</SelectItem>
                  {Array.from({ length: maxRevision + 1 }, (_, i) => (
                    <SelectItem key={i} value={String(i)}>REV {String(i).padStart(2, "0")}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Date</Label>
              <Input type="date" value={newEvent.event_date} onChange={e => setNewEvent(n => ({ ...n, event_date: e.target.value }))} className="mt-1" />
            </div>
            <div>
              <Label>Notes</Label>
              <Textarea value={newEvent.notes} onChange={e => setNewEvent(n => ({ ...n, notes: e.target.value }))} className="mt-1" />
            </div>
            <Button className="w-full" onClick={handleAddCustomEvent}>Add Event</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
