import { useState, forwardRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Info, ChevronDown, ChevronUp } from "lucide-react";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface ProcessStepProps {
  number: string;
  title: string;
  description: string;
  timeline?: string;
  note?: string;
  icon: LucideIcon;
  detailedInfo: string;
}

const ProcessStep = forwardRef<HTMLDivElement, ProcessStepProps>(({
  number,
  title,
  description,
  timeline,
  note,
  icon: Icon,
  detailedInfo,
}, ref) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <Card className="border-l-4 border-l-primary">
      <CardContent className="p-4 md:p-6">
        <div className="flex items-start gap-4">
          <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <Icon className="w-5 h-5 text-primary" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="text-sm font-bold text-primary">{number}.</span>
              <h3 className="font-semibold text-foreground">{title}</h3>
              {timeline && (
                <span className="text-xs bg-muted px-2 py-1 rounded-full text-muted-foreground">
                  {timeline}
                </span>
              )}
              <Button
                variant="ghost"
                size="sm"
                className="h-6 w-6 p-0 rounded-full ml-auto"
                onClick={() => setIsExpanded(!isExpanded)}
                aria-label={isExpanded ? "Hide details" : "Show details"}
              >
                {isExpanded ? (
                  <ChevronUp className="h-4 w-4 text-primary" />
                ) : (
                  <Info className="h-4 w-4 text-primary" />
                )}
              </Button>
            </div>
            <p className="text-muted-foreground">{description}</p>
            {note && (
              <p className="text-sm text-muted-foreground/80 italic mt-1">
                {note}
              </p>
            )}

            {/* Expandable detailed info */}
            <div
              className={cn(
                "overflow-hidden transition-all duration-300 ease-in-out",
                isExpanded ? "max-h-96 opacity-100 mt-4" : "max-h-0 opacity-0"
              )}
            >
              <div className="bg-muted/50 rounded-lg p-4 border border-border">
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {detailedInfo}
                </p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
});

ProcessStep.displayName = "ProcessStep";

export default ProcessStep;
