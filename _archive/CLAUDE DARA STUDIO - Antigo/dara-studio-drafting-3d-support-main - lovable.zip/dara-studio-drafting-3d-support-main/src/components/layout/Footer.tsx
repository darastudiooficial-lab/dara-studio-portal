import { Link } from "react-router-dom";
import { Mail, Phone, MapPin } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  const { t } = useLanguage();

  const services = [t("footer.service1"), t("footer.service2"), t("footer.service3"), t("footer.service4")];

  return (
    <footer className="bg-secondary text-secondary-foreground">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <span className="font-serif text-2xl font-bold text-primary-foreground">DA•RA Studio</span>
            <p className="text-sm text-secondary-foreground/80">{t("footer.tagline")}</p>
          </div>
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">{t("footer.quickLinks")}</h3>
            <ul className="space-y-2">
              <li><Link to="/servicos" className="text-sm text-secondary-foreground/80 hover:text-primary-foreground transition-colors">{t("footer.services")}</Link></li>
              <li><Link to="/portfolio" className="text-sm text-secondary-foreground/80 hover:text-primary-foreground transition-colors">{t("nav.portfolio")}</Link></li>
              <li><Link to="/orcamento" className="text-sm text-secondary-foreground/80 hover:text-primary-foreground transition-colors">{t("nav.requestQuote")}</Link></li>
              <li><Link to="/auth" className="text-sm text-secondary-foreground/80 hover:text-primary-foreground transition-colors">{t("nav.clientArea")}</Link></li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">{t("footer.services")}</h3>
            <ul className="space-y-2">
              {services.map((service) => (<li key={service} className="text-sm text-secondary-foreground/80">{service}</li>))}
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">{t("footer.contact")}</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm text-secondary-foreground/80"><Mail className="h-4 w-4" />darastudiooficial@gmail.com</li>
              <li className="flex items-center gap-2 text-sm text-secondary-foreground/80"><Phone className="h-4 w-4" />+1 (508) 523-6056</li>
              <li className="flex items-center gap-2 text-sm text-secondary-foreground/80"><MapPin className="h-4 w-4" />Worcester, MA</li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-secondary-foreground/20">
          <p className="text-center text-sm text-secondary-foreground/60">© {currentYear} DA•RA Studio. {t("footer.rights")}</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
