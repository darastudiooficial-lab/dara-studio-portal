import { ReactNode, forwardRef } from "react";
import Header from "./Header";
import Footer from "./Footer";

interface PublicLayoutProps {
  children: ReactNode;
}

const PublicLayout = forwardRef<HTMLDivElement, PublicLayoutProps>(({ children }, ref) => {
  return (
    <div ref={ref} className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
});

PublicLayout.displayName = "PublicLayout";

export default PublicLayout;
