import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export const useFreelancerRole = () => {
  const { user } = useAuth();
  const [isFreelancer, setIsFreelancer] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkRole = async () => {
      if (!user) {
        setIsFreelancer(false);
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "freelancer")
        .maybeSingle();

      setIsFreelancer(!!data && !error);
      setLoading(false);
    };

    checkRole();
  }, [user]);

  return { isFreelancer, loading };
};
