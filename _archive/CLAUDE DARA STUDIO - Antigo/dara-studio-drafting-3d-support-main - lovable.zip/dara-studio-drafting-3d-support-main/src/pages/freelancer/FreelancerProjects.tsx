import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/hooks/useLanguage";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { MapPin, Eye, Upload, FileText, FolderOpen } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

const statusColors: Record<string, string> = {
  pending: "bg-muted text-muted-foreground",
  in_progress: "bg-primary/10 text-primary",
  under_review: "bg-accent text-accent-foreground",
  completed: "bg-primary/20 text-primary",
  cancelled: "bg-destructive/10 text-destructive",
};

const FreelancerProjects = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [assignments, setAssignments] = useState<any[]>([]);
  const [selectedProject, setSelectedProject] = useState<any | null>(null);
  const [files, setFiles] = useState<any[]>([]);
  const [deliveries, setDeliveries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [deliveryName, setDeliveryName] = useState("");
  const [deliveryNotes, setDeliveryNotes] = useState("");
  const [deliveryUrl, setDeliveryUrl] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const fetch = async () => {
      if (!user) return;
      const { data } = await supabase.from("freelancer_assignments").select("*, projects(id, name, address, description, status, service_type, created_at)").eq("freelancer_id", user.id);
      setAssignments(data || []);
      setLoading(false);
    };
    fetch();
  }, [user]);

  const openProject = async (assignment: any) => {
    setSelectedProject(assignment);
    const projectId = assignment.projects?.id;
    if (!projectId) return;
    const [filesRes, deliveriesRes] = await Promise.all([
      supabase.from("project_files").select("*").eq("project_id", projectId),
      supabase.from("freelancer_deliveries").select("*").eq("project_id", projectId).eq("freelancer_id", user!.id),
    ]);
    setFiles(filesRes.data || []);
    setDeliveries(deliveriesRes.data || []);
  };

  const handleSubmitDelivery = async () => {
    if (!deliveryName || !deliveryUrl || !selectedProject?.projects?.id) { toast.error("Please fill in the file name and URL"); return; }
    setSubmitting(true);
    const { error } = await supabase.from("freelancer_deliveries").insert({ freelancer_id: user!.id, project_id: selectedProject.projects.id, file_name: deliveryName, file_url: deliveryUrl, notes: deliveryNotes || null });
    if (error) { toast.error("Failed to submit delivery"); } else {
      toast.success("Delivery submitted!");
      setDeliveryName(""); setDeliveryNotes(""); setDeliveryUrl("");
      const { data } = await supabase.from("freelancer_deliveries").select("*").eq("project_id", selectedProject.projects.id).eq("freelancer_id", user!.id);
      setDeliveries(data || []);
    }
    setSubmitting(false);
  };

  if (selectedProject) {
    const proj = selectedProject.projects;
    return (
      <div className="p-6 space-y-6">
        <Button variant="ghost" onClick={() => setSelectedProject(null)}>{t("freelancer.backToProjects")}</Button>
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><MapPin className="h-5 w-5" />{proj.name}</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div><span className="text-muted-foreground">{t("freelancer.address")}:</span> {proj.address || "N/A"}</div>
              <div><span className="text-muted-foreground">{t("freelancer.status")}:</span> <Badge className={statusColors[proj.status]}>{proj.status.replace("_", " ")}</Badge></div>
              <div><span className="text-muted-foreground">{t("freelancer.service")}:</span> {proj.service_type.replace(/_/g, " ")}</div>
              <div><span className="text-muted-foreground">{t("freelancer.deadline")}:</span> {selectedProject.deadline ? format(new Date(selectedProject.deadline), "MMM dd, yyyy") : "N/A"}</div>
            </div>
            {proj.description && <p className="text-sm text-muted-foreground mt-2">{proj.description}</p>}
            {selectedProject.notes && <div className="p-3 rounded-lg bg-muted/50 text-sm"><strong>{t("freelancer.notes")}:</strong> {selectedProject.notes}</div>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-lg">{t("freelancer.referenceFiles")}</CardTitle></CardHeader>
          <CardContent>
            {files.length === 0 ? <p className="text-sm text-muted-foreground">{t("freelancer.noFiles")}</p> : (
              <div className="space-y-2">
                {files.map((f) => (
                  <a key={f.id} href={f.file_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 p-2 rounded hover:bg-muted/50 text-sm text-foreground">
                    <FileText className="h-4 w-4 text-muted-foreground" />{f.file_name}
                  </a>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-lg">{t("freelancer.submitDelivery")}</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2"><Label>{t("freelancer.fileName")}</Label><Input value={deliveryName} onChange={(e) => setDeliveryName(e.target.value)} placeholder="e.g. Final Floor Plan v2" /></div>
            <div className="space-y-2"><Label>{t("freelancer.fileUrl")}</Label><Input value={deliveryUrl} onChange={(e) => setDeliveryUrl(e.target.value)} placeholder="https://drive.google.com/..." /></div>
            <div className="space-y-2"><Label>{t("freelancer.notesOptional")}</Label><Textarea value={deliveryNotes} onChange={(e) => setDeliveryNotes(e.target.value)} placeholder="..." /></div>
            <Button onClick={handleSubmitDelivery} disabled={submitting}><Upload className="h-4 w-4 mr-2" />{submitting ? t("freelancer.submitting") : t("freelancer.submitDelivery")}</Button>
          </CardContent>
        </Card>
        {deliveries.length > 0 && (
          <Card>
            <CardHeader><CardTitle className="text-lg">{t("freelancer.yourDeliveries")}</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-2">
                {deliveries.map((d) => (
                  <div key={d.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div><p className="font-medium text-sm text-foreground">{d.file_name}</p>{d.notes && <p className="text-xs text-muted-foreground">{d.notes}</p>}</div>
                    <a href={d.file_url} target="_blank" rel="noopener noreferrer"><Button variant="outline" size="sm"><Eye className="h-3 w-3 mr-1" /> {t("freelancer.view")}</Button></a>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-serif font-bold text-foreground">{t("freelancer.myProjects")}</h1>
      {loading ? <p className="text-muted-foreground">{t("freelancer.loading")}</p> : assignments.length === 0 ? (
        <Card><CardContent className="p-8 text-center"><FolderOpen className="h-12 w-12 mx-auto text-muted-foreground mb-4" /><p className="text-muted-foreground">{t("freelancer.noProjectsAssigned")}</p></CardContent></Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {assignments.map((a) => (
            <Card key={a.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => openProject(a)}>
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-foreground">{a.projects?.name || "Unknown"}</h3>
                  <Badge className={statusColors[a.projects?.status || "pending"]}>{(a.projects?.status || "pending").replace("_", " ")}</Badge>
                </div>
                {a.projects?.address && <p className="text-sm text-muted-foreground flex items-center gap-1 mb-2"><MapPin className="h-3 w-3" /> {a.projects.address}</p>}
                {a.deadline && <p className="text-xs text-muted-foreground">{t("freelancer.deadline")}: {format(new Date(a.deadline), "MMM dd, yyyy")}</p>}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default FreelancerProjects;
