import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/hooks/useLanguage";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FolderOpen, DollarSign, CalendarDays, Wallet } from "lucide-react";
import { format } from "date-fns";

const FreelancerHome = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [stats, setStats] = useState({
    activeProjects: 0,
    totalReceivable: 0,
    totalAlreadyPaid: 0,
    nextPaymentLabel: "—",
    upcomingDeadlines: [] as { projectName: string; deadline: string }[],
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      if (!user) return;
      const [assignmentsRes, paymentsRes] = await Promise.all([
        supabase
          .from("freelancer_assignments")
          .select("project_id, deadline, projects(name, status, display_address)")
          .eq("freelancer_id", user.id),
        supabase
          .from("freelancer_payments")
          .select("amount, status, due_date, agreed_amount, paid_amount")
          .eq("freelancer_id", user.id),
      ]);

      const assignments = assignmentsRes.data || [];
      const payments = paymentsRes.data || [];

      const activeProjects = assignments.filter(
        (a: any) => a.projects?.status !== "completed" && a.projects?.status !== "cancelled"
      ).length;

      const totalReceivable = payments.reduce((s, p: any) => {
        const agreed = Number(p.agreed_amount || p.amount || 0);
        const paid = Number(p.paid_amount || 0);
        return s + Math.max(agreed - paid, 0);
      }, 0);

      const totalAlreadyPaid = payments.reduce((s, p: any) => s + Number(p.paid_amount || 0), 0);

      // Next payment
      const pendingPayments = payments
        .filter((p: any) => {
          const agreed = Number(p.agreed_amount || p.amount || 0);
          const paid = Number(p.paid_amount || 0);
          return paid < agreed && p.due_date;
        })
        .sort((a, b) => new Date(a.due_date!).getTime() - new Date(b.due_date!).getTime());

      const nextPaymentLabel = pendingPayments[0]
        ? `$${Number((pendingPayments[0] as any).agreed_amount || pendingPayments[0].amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })} — ${format(new Date(pendingPayments[0].due_date!), "MMM dd")}`
        : "—";

      const upcomingDeadlines = assignments
        .filter((a: any) => a.deadline && new Date(a.deadline) > new Date())
        .sort((a: any, b: any) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime())
        .slice(0, 5)
        .map((a: any) => ({
          projectName: a.projects?.display_address || a.projects?.name || "Unknown",
          deadline: a.deadline!,
        }));

      setStats({ activeProjects, totalReceivable, totalAlreadyPaid, nextPaymentLabel, upcomingDeadlines });
      setLoading(false);
    };
    fetchStats();
  }, [user]);

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-serif font-bold text-foreground">
          {t("freelancer.welcome")}, {user?.user_metadata?.full_name?.split(" ")[0] || "Freelancer"}!
        </h1>
        <p className="text-xs text-muted-foreground">{t("freelancer.overviewDesc")}</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="flex items-center gap-4 p-6">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
              <FolderOpen className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("freelancer.activeProjects")}</p>
              <p className="text-2xl font-bold text-foreground">{stats.activeProjects}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-6">
            <div className="w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center">
              <Wallet className="h-6 w-6 text-destructive" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("freelancer.totalReceivable")}</p>
              <p className="text-2xl font-bold text-foreground">${stats.totalReceivable.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-6">
            <div className="w-12 h-12 rounded-lg bg-chart-2/10 flex items-center justify-center">
              <DollarSign className="h-6 w-6 text-chart-2" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("freelancer.totalAlreadyPaid")}</p>
              <p className="text-2xl font-bold text-foreground">${stats.totalAlreadyPaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-6">
            <div className="w-12 h-12 rounded-lg bg-chart-4/10 flex items-center justify-center">
              <CalendarDays className="h-6 w-6 text-chart-4" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("freelancer.nextPayment")}</p>
              <p className="text-lg font-bold text-foreground">{stats.nextPaymentLabel}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming Deadlines */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CalendarDays className="h-5 w-5" />
            {t("freelancer.upcomingDeadlines")}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {stats.upcomingDeadlines.length === 0 ? (
            <p className="text-muted-foreground text-sm">{t("freelancer.noUpcomingDeadlines")}</p>
          ) : (
            <div className="space-y-3">
              {stats.upcomingDeadlines.map((d, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <span className="font-medium text-foreground">{d.projectName}</span>
                  <Badge variant="outline">{format(new Date(d.deadline), "MMM dd, yyyy")}</Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default FreelancerHome;
