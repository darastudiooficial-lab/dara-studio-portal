import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/hooks/useLanguage";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { CalendarDays, MapPin } from "lucide-react";
import { format, isSameDay } from "date-fns";

interface Deadline {
  projectName: string;
  address: string | null;
  deadline: Date;
  status: string;
}

const FreelancerCalendar = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [deadlines, setDeadlines] = useState<Deadline[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      if (!user) return;
      const { data } = await supabase.from("freelancer_assignments").select("deadline, projects(name, address, status)").eq("freelancer_id", user.id).not("deadline", "is", null);
      const mapped = (data || []).map((a: any) => ({ projectName: a.projects?.name || "Unknown", address: a.projects?.address || null, deadline: new Date(a.deadline), status: a.projects?.status || "pending" }));
      setDeadlines(mapped);
      setLoading(false);
    };
    fetch();
  }, [user]);

  const deadlineDates = deadlines.map((d) => d.deadline);
  const selectedDeadlines = selectedDate ? deadlines.filter((d) => isSameDay(d.deadline, selectedDate)) : [];

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-serif font-bold text-foreground">{t("freelancer.calendar")}</h1>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-4">
            <Calendar mode="single" selected={selectedDate} onSelect={setSelectedDate} modifiers={{ deadline: deadlineDates }} modifiersClassNames={{ deadline: "bg-primary/20 text-primary font-bold rounded-full" }} className="w-full" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg"><CalendarDays className="h-5 w-5" />{selectedDate ? format(selectedDate, "MMMM dd, yyyy") : t("freelancer.selectDate")}</CardTitle>
          </CardHeader>
          <CardContent>
            {selectedDeadlines.length === 0 ? <p className="text-sm text-muted-foreground">{t("freelancer.noDeadlinesOnDate")}</p> : (
              <div className="space-y-3">
                {selectedDeadlines.map((d, i) => (
                  <div key={i} className="p-4 rounded-lg border border-border">
                    <p className="font-medium text-foreground">{d.projectName}</p>
                    {d.address && <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1"><MapPin className="h-3 w-3" /> {d.address}</p>}
                    <Badge variant="outline" className="mt-2">{d.status.replace("_", " ")}</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      <Card>
        <CardHeader><CardTitle className="text-lg">{t("freelancer.allUpcomingDeadlines")}</CardTitle></CardHeader>
        <CardContent>
          {loading ? <p className="text-sm text-muted-foreground">{t("freelancer.loading")}</p> : deadlines.filter(d => d.deadline >= new Date()).length === 0 ? (
            <p className="text-sm text-muted-foreground">{t("freelancer.noUpcoming")}</p>
          ) : (
            <div className="space-y-2">
              {deadlines.filter(d => d.deadline >= new Date()).sort((a, b) => a.deadline.getTime() - b.deadline.getTime()).map((d, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <span className="font-medium text-sm text-foreground">{d.projectName}</span>
                  <Badge variant="outline">{format(d.deadline, "MMM dd, yyyy")}</Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default FreelancerCalendar;
