import ProfileEditor from "@/components/profile/ProfileEditor";

const FreelancerProfile = () => {
  return <ProfileEditor />;
};

export default FreelancerProfile;
