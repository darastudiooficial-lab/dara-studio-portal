import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/hooks/useLanguage";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DollarSign, Wallet, Clock } from "lucide-react";
import { format } from "date-fns";

const getPaymentStatus = (agreed: number, paid: number) => {
  if (paid <= 0) return "pending";
  if (paid < agreed) return "partial";
  return "paid";
};

const statusConfig: Record<string, { label: string; className: string }> = {
  pending: { label: "Pending", className: "bg-destructive/15 text-destructive border-destructive/30" },
  partial: { label: "Partial", className: "bg-chart-4/15 text-chart-4 border-chart-4/30" },
  paid: { label: "Paid", className: "bg-chart-2/15 text-chart-2 border-chart-2/30" },
};

const FreelancerPayments = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [payments, setPayments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPayments = async () => {
      if (!user) return;
      const { data } = await supabase
        .from("freelancer_payments")
        .select("*, projects(name, display_address)")
        .eq("freelancer_id", user.id)
        .order("created_at", { ascending: false });
      setPayments(data || []);
      setLoading(false);
    };
    fetchPayments();
  }, [user]);

  // Compute totals
  const totalReceivable = payments.reduce((s, p) => {
    const agreed = Number((p as any).agreed_amount || p.amount || 0);
    const paid = Number((p as any).paid_amount || 0);
    return s + Math.max(agreed - paid, 0);
  }, 0);

  const totalAlreadyPaid = payments.reduce((s, p) => s + Number((p as any).paid_amount || 0), 0);

  // Next payment: first pending/partial with due_date
  const nextPayment = payments
    .filter(p => {
      const status = getPaymentStatus(Number((p as any).agreed_amount || p.amount || 0), Number((p as any).paid_amount || 0));
      return status !== "paid" && p.due_date;
    })
    .sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime())[0];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-serif font-bold text-foreground">{t("freelancer.payments")}</h1>
        <p className="text-xs text-muted-foreground">{t("freelancer.paymentHistory")}</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="flex items-center gap-4 p-6">
            <div className="w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center">
              <Wallet className="h-6 w-6 text-destructive" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("freelancer.totalReceivable")}</p>
              <p className="text-2xl font-bold text-foreground">${totalReceivable.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-6">
            <div className="w-12 h-12 rounded-lg bg-chart-2/10 flex items-center justify-center">
              <DollarSign className="h-6 w-6 text-chart-2" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("freelancer.totalAlreadyPaid")}</p>
              <p className="text-2xl font-bold text-foreground">${totalAlreadyPaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-6">
            <div className="w-12 h-12 rounded-lg bg-chart-4/10 flex items-center justify-center">
              <Clock className="h-6 w-6 text-chart-4" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("freelancer.nextPayment")}</p>
              <p className="text-lg font-bold text-foreground">
                {nextPayment
                  ? `$${Number((nextPayment as any).agreed_amount || nextPayment.amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })} — ${format(new Date(nextPayment.due_date), "MMM dd")}`
                  : "—"}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payment List */}
      <Card>
        <CardHeader>
          <CardTitle>{t("freelancer.paymentHistory")}</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-muted-foreground text-sm">{t("freelancer.loading")}</p>
          ) : payments.length === 0 ? (
            <p className="text-muted-foreground text-sm">{t("freelancer.noPayments")}</p>
          ) : (
            <div className="space-y-4">
              {payments.map((p) => {
                const agreed = Number((p as any).agreed_amount || p.amount || 0);
                const paid = Number((p as any).paid_amount || 0);
                const remaining = Math.max(agreed - paid, 0);
                const status = getPaymentStatus(agreed, paid);
                const config = statusConfig[status];
                const projectLabel = p.projects?.display_address || p.projects?.name || p.description || "Payment";

                return (
                  <div key={p.id} className="p-4 rounded-lg border border-border space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-semibold text-foreground">{t("freelancer.project")}: {projectLabel}</p>
                        {p.due_date && (
                          <p className="text-xs text-muted-foreground mt-1">
                            {t("freelancer.due")}: {format(new Date(p.due_date), "MMM dd, yyyy")}
                          </p>
                        )}
                        {(p as any).payment_method && (
                          <p className="text-xs text-muted-foreground">
                            {t("freelancer.paymentMethod")}: {(p as any).payment_method}
                          </p>
                        )}
                      </div>
                      <Badge className={`${config.className} border rounded-full px-3 py-1 text-xs font-semibold`}>
                        {status === "pending" ? t("freelancer.pending") : status === "partial" ? t("freelancer.partial") : t("freelancer.paid")}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">{t("freelancer.agreedAmount")}</p>
                        <p className="font-bold text-foreground">${agreed.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">{t("freelancer.paidAmount")}</p>
                        <p className="font-bold text-foreground">${paid.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">{t("freelancer.remainingAmount")}</p>
                        <p className="font-bold text-foreground">${remaining.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default FreelancerPayments;
