import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/hooks/useLanguage";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Download, CheckCircle, XCircle } from "lucide-react";

const FreelancerContracts = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [contracts, setContracts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      if (!user) return;
      const { data } = await supabase.from("freelancer_contracts").select("*, projects(name)").eq("freelancer_id", user.id).order("created_at", { ascending: false });
      setContracts(data || []);
      setLoading(false);
    };
    fetch();
  }, [user]);

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-serif font-bold text-foreground">{t("freelancer.contracts")}</h1>
      {loading ? <p className="text-muted-foreground">{t("freelancer.loading")}</p> : contracts.length === 0 ? (
        <Card><CardContent className="p-8 text-center"><FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" /><p className="text-muted-foreground">{t("freelancer.noContracts")}</p></CardContent></Card>
      ) : (
        <div className="space-y-3">
          {contracts.map((c) => (
            <Card key={c.id}>
              <CardContent className="flex items-center justify-between p-5">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center"><FileText className="h-5 w-5 text-muted-foreground" /></div>
                  <div><p className="font-medium text-foreground">{c.title}</p><p className="text-xs text-muted-foreground">{c.projects?.name || t("freelancer.unknownProject")}</p></div>
                </div>
                <div className="flex items-center gap-3">
                  {c.is_signed ? (
                    <Badge variant="outline" className="gap-1"><CheckCircle className="h-3 w-3" /> {t("freelancer.signed")}</Badge>
                  ) : (
                    <Badge variant="secondary" className="gap-1"><XCircle className="h-3 w-3" /> {t("freelancer.unsigned")}</Badge>
                  )}
                  {c.file_url && (
                    <a href={c.file_url} target="_blank" rel="noopener noreferrer">
                      <Button variant="outline" size="sm"><Download className="h-3 w-3 mr-1" /> {t("freelancer.download")}</Button>
                    </a>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default FreelancerContracts;
