// Re-export existing FreelancerHome as Dashboard
export { default } from "@/pages/freelancer/FreelancerHome";
