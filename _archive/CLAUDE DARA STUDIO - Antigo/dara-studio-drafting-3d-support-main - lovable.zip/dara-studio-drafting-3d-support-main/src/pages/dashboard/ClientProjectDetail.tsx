import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  ArrowLeft, MapPin, DollarSign, Clock, CheckCircle2, FileText,
  Download, Send, AlertCircle, Upload,
} from "lucide-react";
import { getStageLabel, PROJECT_STAGE_COLORS } from "@/constants/projectStages";
import ClientTimeline from "@/components/dashboard/ClientTimeline";
import ClientProjectDocuments from "@/components/dashboard/ClientProjectDocuments";

const ClientProjectDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [project, setProject] = useState<any>(null);
  const [milestones, setMilestones] = useState<any[]>([]);
  const [files, setFiles] = useState<any[]>([]);
  const [drawings, setDrawings] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    const fetchAll = async () => {
      const [pRes, mRes, fRes, dRes, msgRes] = await Promise.all([
        supabase.from("projects").select("*, companies(name)").eq("id", id).single(),
        supabase.from("payment_milestones").select("*").eq("project_id", id).order("created_at"),
        supabase.from("project_files").select("*").eq("project_id", id).order("created_at", { ascending: false }),
        supabase.from("drawing_versions").select("*").eq("project_id", id).eq("is_current", true).order("created_at", { ascending: false }),
        supabase.from("messages").select("*").eq("project_id", id).order("created_at", { ascending: true }),
      ]);
      if (pRes.data) setProject(pRes.data);
      setMilestones(mRes.data || []);
      setFiles(fRes.data || []);
      setDrawings(dRes.data || []);
      setMessages(msgRes.data || []);
      setLoading(false);
    };
    fetchAll();
  }, [id]);

  const sendMessage = async () => {
    if (!newMessage.trim() || !user || !id) return;
    setSending(true);
    const { error } = await supabase.from("messages").insert({
      project_id: id, content: newMessage.trim(), sender_id: user.id, is_from_admin: false,
    });
    if (error) { toast.error("Failed to send message"); }
    else {
      setMessages(prev => [...prev, { id: Date.now().toString(), content: newMessage.trim(), sender_id: user.id, is_from_admin: false, created_at: new Date().toISOString() }]);
      setNewMessage("");
      toast.success("Message sent");
    }
    setSending(false);
  };

  if (loading) {
    return <div className="p-6 lg:p-8 space-y-4"><Skeleton className="h-10 w-64" /><Skeleton className="h-48" /><Skeleton className="h-64" /></div>;
  }

  if (!project) {
    return (
      <div className="p-6 lg:p-8 text-center py-20">
        <AlertCircle className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
        <p className="text-muted-foreground">Project not found</p>
        <Button variant="outline" asChild className="mt-4"><Link to="/dashboard/projects">Back to Projects</Link></Button>
      </div>
    );
  }

  // Stage-based progress
  const stage = project.stage || "briefing";
  const stageLabel = getStageLabel(stage);
  const stageColors = PROJECT_STAGE_COLORS[stage] || { dot: "bg-muted-foreground", bg: "bg-muted", text: "text-muted-foreground", border: "border-border" };

  // Financial calculations
  const totalValue = Number(project.total_value || 0);
  const totalPaid = milestones.filter(m => m.status === "paid").reduce((s, m) => s + Number(m.amount), 0);
  const remaining = totalValue - totalPaid;
  const paymentProgress = totalValue > 0 ? Math.round((totalPaid / totalValue) * 100) : 0;
  const location = [project.display_address, project.city, project.state].filter(Boolean).join(", ");

  return (
    <div className="p-6 lg:p-8 space-y-6 max-w-5xl">
      {/* Back + Header */}
      <div>
        <Button variant="ghost" size="sm" asChild className="mb-3">
          <Link to="/dashboard/projects"><ArrowLeft className="mr-2 h-4 w-4" />Back to Projects</Link>
        </Button>
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-serif font-bold text-foreground">
              {project.display_address || project.name || "Untitled Project"}
            </h1>
            {location && (
              <div className="flex items-center gap-1 mt-1 text-muted-foreground">
                <MapPin className="h-3.5 w-3.5" /><span className="text-sm">{location}</span>
              </div>
            )}
          </div>
          <Badge className={`${stageColors.bg} ${stageColors.text} ${stageColors.border} border text-sm px-3 py-1`}>
            <span className={`h-2 w-2 rounded-full ${stageColors.dot} mr-2 inline-block`} />
            {stageLabel}
          </Badge>
        </div>
      </div>

      {/* Financial Summary */}
      {totalValue > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card className="border-none shadow-sm">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Project Value</p>
              <p className="text-xl font-bold text-foreground">${totalValue.toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card className="border-none shadow-sm">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Total Paid</p>
              <p className="text-xl font-bold text-chart-2">${totalPaid.toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card className="border-none shadow-sm">
            <CardContent className="p-4 text-center">
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Remaining</p>
              <p className="text-xl font-bold text-foreground">${remaining.toLocaleString()}</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Payment Progress */}
      {totalValue > 0 && (
        <Card className="border-none shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">Payment Progress</span>
              <span className="text-sm font-bold text-primary">{paymentProgress}%</span>
            </div>
            <Progress value={paymentProgress} className="h-2.5" />
          </CardContent>
        </Card>
      )}

      {/* Tabs */}
      <Tabs defaultValue="timeline">
        <TabsList>
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
          <TabsTrigger value="invoices">Invoices ({milestones.length})</TabsTrigger>
          <TabsTrigger value="files">Files ({files.length + drawings.length})</TabsTrigger>
          <TabsTrigger value="messages">Messages ({messages.length})</TabsTrigger>
        </TabsList>

        {/* Timeline Tab */}
        <TabsContent value="timeline" className="mt-4">
          {id && <ClientTimeline projectId={id} />}
        </TabsContent>

        {/* Invoices Tab */}
        <TabsContent value="invoices" className="mt-4">
          {milestones.length === 0 ? (
            <Card className="border-dashed"><CardContent className="py-10 text-center text-muted-foreground">No invoices yet</CardContent></Card>
          ) : (
            <Card className="border-none shadow-sm overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Milestone</TableHead><TableHead>Amount</TableHead><TableHead>Status</TableHead><TableHead></TableHead></TableRow>
                </TableHeader>
                <TableBody>
                  {milestones.map(m => (
                    <TableRow key={m.id}>
                      <TableCell className="font-medium">{m.stage} ({m.percentage}%)</TableCell>
                      <TableCell>${Number(m.amount).toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge variant={m.status === "paid" ? "default" : m.status === "overdue" ? "destructive" : "secondary"}>
                          {m.status === "paid" ? <><CheckCircle2 className="h-3 w-3 mr-1" />Paid</> : m.status === "overdue" ? <><AlertCircle className="h-3 w-3 mr-1" />Overdue</> : <><Clock className="h-3 w-3 mr-1" />Pending</>}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {m.status !== "paid" && (
                          <Button size="sm" variant="outline" className="text-xs">
                            <DollarSign className="h-3 w-3 mr-1" />Pay Online
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          )}
        </TabsContent>

        {/* Files Tab */}
        <TabsContent value="files" className="mt-4">
          <ClientProjectDocuments projectId={id!} />
        </TabsContent>

        {/* Messages Tab */}
        <TabsContent value="messages" className="mt-4">
          <Card className="border-none shadow-sm">
            <CardContent className="p-4">
              <div className="space-y-3 max-h-80 overflow-y-auto mb-4">
                {messages.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">No messages yet. Start a conversation below.</p>
                ) : (
                  messages.map(msg => (
                    <div key={msg.id} className={`flex ${msg.is_from_admin ? "justify-start" : "justify-end"}`}>
                      <div className={`max-w-[75%] rounded-xl px-4 py-2.5 ${msg.is_from_admin ? "bg-muted/50 text-foreground" : "bg-primary text-primary-foreground"}`}>
                        <p className="text-sm">{msg.content}</p>
                        <p className={`text-[10px] mt-1 ${msg.is_from_admin ? "text-muted-foreground" : "text-primary-foreground/70"}`}>
                          {new Date(msg.created_at).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
              <div className="flex gap-2">
                <Textarea placeholder="Type your message..." value={newMessage} onChange={e => setNewMessage(e.target.value)} rows={2} className="resize-none" />
                <Button onClick={sendMessage} disabled={sending || !newMessage.trim()} className="self-end">
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ClientProjectDetail;
