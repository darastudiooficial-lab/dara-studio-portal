import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { MessageSquare, ArrowRight, FolderOpen } from "lucide-react";

interface ProjectThread {
  project_id: string;
  project_name: string;
  lastMessage: string;
  lastDate: string;
  unread: number;
  total: number;
}

const Messages = () => {
  const { user } = useAuth();
  const [threads, setThreads] = useState<ProjectThread[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      if (!user) return;
      const { data: profile } = await supabase.from("profiles").select("company_id").eq("id", user.id).single();
      if (!profile?.company_id) { setLoading(false); return; }
      const { data: projects } = await supabase.from("projects")
        .select("id, name, display_address").eq("company_id", profile.company_id);
      if (!projects || projects.length === 0) { setLoading(false); return; }
      const ids = projects.map(p => p.id);
      const { data: msgs } = await supabase.from("messages").select("*").in("project_id", ids).order("created_at", { ascending: false });
      const projectMap = Object.fromEntries(projects.map(p => [p.id, p.display_address || p.name || "Untitled"]));
      const threadMap: Record<string, ProjectThread> = {};
      (msgs || []).forEach(m => {
        if (!threadMap[m.project_id]) {
          threadMap[m.project_id] = {
            project_id: m.project_id,
            project_name: projectMap[m.project_id] || "Unknown",
            lastMessage: m.content,
            lastDate: m.created_at,
            unread: 0,
            total: 0,
          };
        }
        threadMap[m.project_id].total++;
      });
      setThreads(Object.values(threadMap).sort((a, b) => new Date(b.lastDate).getTime() - new Date(a.lastDate).getTime()));
      setLoading(false);
    };
    fetch();
  }, [user]);

  if (loading) return <div className="p-6 lg:p-8 space-y-4"><Skeleton className="h-10 w-48" /><Skeleton className="h-64" /></div>;

  return (
    <div className="p-6 lg:p-8 space-y-6">
      <div>
        <h1 className="text-2xl font-serif font-bold text-foreground">Messages</h1>
        <p className="text-sm text-muted-foreground">Communicate with our team about your projects</p>
      </div>

      {threads.length === 0 ? (
        <Card className="border-dashed border-2">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <MessageSquare className="h-12 w-12 text-muted-foreground/40 mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">No messages yet</h3>
            <p className="text-sm text-muted-foreground text-center mb-4">Messages will appear here once you have active projects.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {threads.map(thread => (
            <Link key={thread.project_id} to={`/dashboard/projects/${thread.project_id}`}>
              <Card className="hover:shadow-md transition-shadow border-none shadow-sm cursor-pointer">
                <CardContent className="p-4 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <FolderOpen className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium text-foreground truncate">{thread.project_name}</h3>
                        <Badge variant="secondary" className="text-[10px]">{thread.total} msgs</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground truncate mt-0.5">{thread.lastMessage}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <span className="text-xs text-muted-foreground">{new Date(thread.lastDate).toLocaleDateString()}</span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
};

export default Messages;
