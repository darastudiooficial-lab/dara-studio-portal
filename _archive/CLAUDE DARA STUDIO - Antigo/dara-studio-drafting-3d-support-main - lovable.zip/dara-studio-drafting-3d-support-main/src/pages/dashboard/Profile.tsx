import ProfileEditor from "@/components/profile/ProfileEditor";

const Profile = () => {
  return <ProfileEditor />;
};

export default Profile;
