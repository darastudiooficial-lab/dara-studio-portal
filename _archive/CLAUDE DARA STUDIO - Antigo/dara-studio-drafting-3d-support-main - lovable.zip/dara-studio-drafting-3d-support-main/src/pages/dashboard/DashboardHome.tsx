import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/hooks/useLanguage";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import {
  FolderOpen, FileText, MessageSquare, Plus, AlertCircle,
  CheckCircle2, Clock, DollarSign, ArrowRight, Upload, TrendingUp,
} from "lucide-react";

interface Project {
  id: string;
  name: string | null;
  display_address: string | null;
  status: string;
  stage: string | null;
  total_value: number | null;
  created_at: string;
  updated_at: string;
}

interface DashboardStats {
  activeProjects: number;
  completedProjects: number;
  pendingInvoices: number;
  totalFiles: number;
  totalPaid: number;
  totalOutstanding: number;
}

const statusProgress: Record<string, number> = {
  pending: 10,
  in_progress: 50,
  under_review: 80,
  completed: 100,
  cancelled: 0,
};

const statusLabel: Record<string, string> = {
  pending: "Proposal",
  in_progress: "In Progress",
  under_review: "Review",
  completed: "Completed",
  cancelled: "Cancelled",
};

const statusIcon: Record<string, typeof Clock> = {
  pending: Clock,
  in_progress: TrendingUp,
  under_review: FileText,
  completed: CheckCircle2,
  cancelled: AlertCircle,
};

const DashboardHome = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [projects, setProjects] = useState<Project[]>([]);
  const [stats, setStats] = useState<DashboardStats>({
    activeProjects: 0, completedProjects: 0, pendingInvoices: 0,
    totalFiles: 0, totalPaid: 0, totalOutstanding: 0,
  });
  const [recentActivity, setRecentActivity] = useState<Array<{ id: string; text: string; date: string; type: string }>>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;
      try {
        setLoading(true);
        const { data: profile } = await supabase.from("profiles").select("company_id").eq("id", user.id).single();
        if (!profile?.company_id) { setLoading(false); return; }

        const { data: projectsData } = await supabase.from("projects")
          .select("id, name, display_address, status, stage, total_value, created_at, updated_at")
          .eq("company_id", profile.company_id).order("updated_at", { ascending: false });

        const prj = projectsData || [];
        setProjects(prj);

        const projectIds = prj.map(p => p.id);
        const active = prj.filter(p => p.status !== "completed" && p.status !== "cancelled").length;
        const completed = prj.filter(p => p.status === "completed").length;

        let pendingInvoices = 0;
        let totalPaid = 0;
        let totalOutstanding = 0;
        let totalFiles = 0;

        if (projectIds.length > 0) {
          const { data: milestones } = await supabase.from("payment_milestones")
            .select("amount, status").in("project_id", projectIds);
          if (milestones) {
            pendingInvoices = milestones.filter(m => m.status === "pending" || m.status === "overdue").length;
            totalPaid = milestones.filter(m => m.status === "paid").reduce((s, m) => s + Number(m.amount), 0);
            totalOutstanding = milestones.filter(m => m.status !== "paid").reduce((s, m) => s + Number(m.amount), 0);
          }

          const { count: filesCount } = await supabase.from("project_files")
            .select("*", { count: "exact", head: true }).in("project_id", projectIds);
          const { count: drawingsCount } = await supabase.from("drawing_versions")
            .select("*", { count: "exact", head: true }).in("project_id", projectIds);
          totalFiles = (filesCount || 0) + (drawingsCount || 0);

          // Recent activity from messages + files
          const activity: Array<{ id: string; text: string; date: string; type: string }> = [];
          const { data: recentMsgs } = await supabase.from("messages")
            .select("id, content, created_at, is_from_admin")
            .in("project_id", projectIds).order("created_at", { ascending: false }).limit(3);
          recentMsgs?.forEach(m => activity.push({
            id: m.id, text: m.is_from_admin ? "New message from team" : "You sent a message",
            date: m.created_at, type: "message",
          }));

          const { data: recentFiles } = await supabase.from("project_files")
            .select("id, file_name, created_at")
            .in("project_id", projectIds).order("created_at", { ascending: false }).limit(3);
          recentFiles?.forEach(f => activity.push({
            id: f.id, text: `File uploaded: ${f.file_name}`, date: f.created_at, type: "file",
          }));

          activity.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
          setRecentActivity(activity.slice(0, 5));
        }

        setStats({ activeProjects: active, completedProjects: completed, pendingInvoices, totalFiles, totalPaid, totalOutstanding });
      } catch (err) {
        console.error("Error fetching dashboard data:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [user]);

  if (loading) {
    return (
      <div className="p-6 lg:p-8 space-y-6">
        <Skeleton className="h-10 w-64" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">{[1,2,3,4].map(i => <Skeleton key={i} className="h-28" />)}</div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">{[1,2,3].map(i => <Skeleton key={i} className="h-64" />)}</div>
      </div>
    );
  }

  const firstName = user?.user_metadata?.full_name?.split(" ")[0] || "there";

  return (
    <div className="p-6 lg:p-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-serif font-bold text-foreground">Welcome back, {firstName}</h1>
          <p className="text-sm text-muted-foreground mt-1">Here's what's happening with your projects</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" asChild>
            <Link to="/dashboard/projects"><FolderOpen className="mr-2 h-4 w-4" />My Projects</Link>
          </Button>
          <Button asChild>
            <Link to="/dashboard/new-quote"><Plus className="mr-2 h-4 w-4" />New Project</Link>
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-none shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Active Projects</span>
              <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center">
                <FolderOpen className="h-4 w-4 text-primary" />
              </div>
            </div>
            <p className="text-3xl font-bold text-foreground">{stats.activeProjects}</p>
            <p className="text-xs text-muted-foreground mt-1">{stats.completedProjects} completed</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Pending Invoices</span>
              <div className="h-9 w-9 rounded-lg bg-destructive/10 flex items-center justify-center">
                <FileText className="h-4 w-4 text-destructive" />
              </div>
            </div>
            <p className="text-3xl font-bold text-foreground">{stats.pendingInvoices}</p>
            <p className="text-xs text-muted-foreground mt-1">${stats.totalOutstanding.toLocaleString()} outstanding</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Total Paid</span>
              <div className="h-9 w-9 rounded-lg bg-chart-1/10 flex items-center justify-center">
                <DollarSign className="h-4 w-4 text-chart-1" />
              </div>
            </div>
            <p className="text-3xl font-bold text-foreground">${stats.totalPaid.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground mt-1">All time</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Files</span>
              <div className="h-9 w-9 rounded-lg bg-secondary/10 flex items-center justify-center">
                <Upload className="h-4 w-4 text-secondary" />
              </div>
            </div>
            <p className="text-3xl font-bold text-foreground">{stats.totalFiles}</p>
            <p className="text-xs text-muted-foreground mt-1">Drawings & documents</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Projects List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-foreground">Your Projects</h2>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/dashboard/projects">View all <ArrowRight className="ml-1 h-3 w-3" /></Link>
            </Button>
          </div>

          {projects.length === 0 ? (
            <Card className="border-dashed border-2">
              <CardContent className="flex flex-col items-center justify-center py-16">
                <div className="h-16 w-16 rounded-2xl bg-muted/50 flex items-center justify-center mb-4">
                  <FolderOpen className="h-8 w-8 text-muted-foreground/50" />
                </div>
                <h3 className="text-lg font-medium text-foreground mb-2">No projects yet</h3>
                <p className="text-sm text-muted-foreground text-center mb-6 max-w-sm">
                  Submit a new project request and our team will get back to you with a proposal.
                </p>
                <Button asChild><Link to="/dashboard/new-quote"><Plus className="mr-2 h-4 w-4" />Submit Project Request</Link></Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {projects.slice(0, 5).map((project) => {
                const progress = statusProgress[project.status] || 10;
                const label = statusLabel[project.status] || "Pending";
                const Icon = statusIcon[project.status] || Clock;
                return (
                  <Link key={project.id} to={`/dashboard/projects/${project.id}`}>
                    <Card className="hover:shadow-md transition-shadow border-none shadow-sm cursor-pointer">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-3 mb-3">
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium text-foreground truncate">
                              {project.display_address || project.name || "Untitled Project"}
                            </h3>
                            <p className="text-xs text-muted-foreground mt-0.5">
                              Updated {new Date(project.updated_at).toLocaleDateString()}
                            </p>
                          </div>
                          <Badge variant={project.status === "completed" ? "default" : project.status === "cancelled" ? "destructive" : "secondary"} className="flex items-center gap-1 flex-shrink-0">
                            <Icon className="h-3 w-3" />{label}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-3">
                          <Progress value={progress} className="h-1.5 flex-1" />
                          <span className="text-xs font-medium text-muted-foreground w-8 text-right">{progress}%</span>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Recent Activity */}
          <Card className="border-none shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              {recentActivity.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4 text-center">No recent activity</p>
              ) : (
                <div className="space-y-3">
                  {recentActivity.map((activity) => (
                    <div key={activity.id} className="flex items-start gap-3">
                      <div className="h-7 w-7 rounded-full bg-muted/50 flex items-center justify-center flex-shrink-0 mt-0.5">
                        {activity.type === "message" ? (
                          <MessageSquare className="h-3.5 w-3.5 text-muted-foreground" />
                        ) : (
                          <Upload className="h-3.5 w-3.5 text-muted-foreground" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-foreground truncate">{activity.text}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(activity.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="border-none shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full justify-start" asChild>
                <Link to="/dashboard/new-quote"><Plus className="mr-2 h-4 w-4" />New Project Request</Link>
              </Button>
              <Button variant="outline" className="w-full justify-start" asChild>
                <Link to="/dashboard/invoices"><FileText className="mr-2 h-4 w-4" />View Invoices</Link>
              </Button>
              <Button variant="outline" className="w-full justify-start" asChild>
                <Link to="/dashboard/messages"><MessageSquare className="mr-2 h-4 w-4" />Send Message</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default DashboardHome;
