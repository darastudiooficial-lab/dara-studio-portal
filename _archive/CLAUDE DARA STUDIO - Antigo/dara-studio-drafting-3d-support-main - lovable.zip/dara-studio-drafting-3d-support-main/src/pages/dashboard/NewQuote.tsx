import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import { z } from "zod";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/hooks/useLanguage";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Send, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";

const quoteSchema = z.object({
  projectAddress: z.string().min(1, "Project address is required"),
  projectCity: z.string().min(1, "City is required"),
  projectState: z.string().min(1, "State is required"),
  projectType: z.string().min(1, "Project type is required"),
  estimatedSize: z.string().min(1, "Estimated size is required"),
  description: z.string().optional(),
});

type QuoteFormData = z.infer<typeof quoteSchema>;

const NewQuote = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const PROJECT_TYPES_KEYS = [
    "projectType.singleFamily", "projectType.multiFamily", "projectType.commercial",
    "projectType.renovation", "projectType.addition", "projectType.adu",
    "projectType.deck", "projectType.garage", "projectType.other",
  ];

  const { register, handleSubmit, setValue, formState: { errors } } = useForm<QuoteFormData>({
    resolver: zodResolver(quoteSchema),
    defaultValues: { projectAddress: "", projectCity: "", projectState: "", projectType: "", estimatedSize: "", description: "" },
  });

  const onSubmit = async (data: QuoteFormData) => {
    if (!user) { toast.error("You must be logged in"); return; }
    setIsSubmitting(true);
    try {
      const fullAddress = `${data.projectAddress}, ${data.projectCity}, ${data.projectState}`;
      const description = `PROJECT TYPE: ${data.projectType}\nESTIMATED SIZE: ${data.estimatedSize} sq ft\nADDRESS: ${fullAddress}\n\nADDITIONAL NOTES:\n${data.description || "None"}\n\nSubmitted from Client Portal by: ${user.email}`.trim();
      const { error } = await supabase.from("quote_requests").insert({
        full_name: user.user_metadata?.full_name || user.email || "Client",
        email: user.email || "",
        phone: null, company_name: null, service_type: "technical_drafting",
        project_address: fullAddress, description,
      });
      if (error) throw error;
      toast.success("Quote request submitted successfully!");
      navigate("/dashboard");
    } catch (err) {
      console.error("Error submitting quote:", err);
      toast.error("Failed to submit quote request.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="mb-6">
        <Button variant="ghost" asChild className="mb-4">
          <Link to="/dashboard"><ArrowLeft className="mr-2 h-4 w-4" />{t("dashboard.backToDashboard")}</Link>
        </Button>
        <h1 className="text-2xl font-serif font-bold text-foreground">{t("newQuote.title")}</h1>
        <p className="text-muted-foreground">{t("newQuote.subtitle")}</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>{t("newQuote.projectDetails")}</CardTitle>
          <CardDescription>{t("newQuote.projectDetailsDesc")}</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="projectAddress">{t("newQuote.projectAddress")} *</Label>
              <Input id="projectAddress" placeholder="123 Main Street" {...register("projectAddress")} />
              {errors.projectAddress && <p className="text-sm text-destructive">{errors.projectAddress.message}</p>}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="projectCity">{t("newQuote.city")} *</Label>
                <Input id="projectCity" placeholder="Boston" {...register("projectCity")} />
                {errors.projectCity && <p className="text-sm text-destructive">{errors.projectCity.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="projectState">{t("newQuote.state")} *</Label>
                <Input id="projectState" placeholder="MA" {...register("projectState")} />
                {errors.projectState && <p className="text-sm text-destructive">{errors.projectState.message}</p>}
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="projectType">{t("newQuote.projectType")} *</Label>
              <Select onValueChange={(value) => setValue("projectType", value)}>
                <SelectTrigger><SelectValue placeholder={t("newQuote.selectProjectType")} /></SelectTrigger>
                <SelectContent>
                  {PROJECT_TYPES_KEYS.map((key) => (<SelectItem key={key} value={t(key)}>{t(key)}</SelectItem>))}
                </SelectContent>
              </Select>
              {errors.projectType && <p className="text-sm text-destructive">{errors.projectType.message}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="estimatedSize">{t("newQuote.estimatedSize")} *</Label>
              <Input id="estimatedSize" placeholder="2000" type="number" {...register("estimatedSize")} />
              {errors.estimatedSize && <p className="text-sm text-destructive">{errors.estimatedSize.message}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">{t("newQuote.additionalNotes")}</Label>
              <Textarea id="description" placeholder={t("newQuote.additionalNotesPlaceholder")} rows={4} {...register("description")} />
            </div>
            <div className="flex justify-end gap-4 pt-4">
              <Button type="button" variant="outline" asChild><Link to="/dashboard">{t("newQuote.cancel")}</Link></Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (<><Loader2 className="mr-2 h-4 w-4 animate-spin" />{t("newQuote.submitting")}</>) : (<><Send className="mr-2 h-4 w-4" />{t("newQuote.submitRequest")}</>)}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default NewQuote;
