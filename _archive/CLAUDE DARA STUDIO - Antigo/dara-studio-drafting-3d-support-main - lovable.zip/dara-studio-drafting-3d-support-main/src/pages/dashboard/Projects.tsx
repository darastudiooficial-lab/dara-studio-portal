import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  FolderOpen, Plus, Clock, TrendingUp, FileText, CheckCircle2, AlertCircle, MapPin,
} from "lucide-react";

interface Project {
  id: string;
  name: string | null;
  display_address: string | null;
  city: string | null;
  state: string | null;
  status: string;
  total_value: number | null;
  service_type: string;
  created_at: string;
  updated_at: string;
}

const statusProgress: Record<string, number> = {
  pending: 10, in_progress: 50, under_review: 80, completed: 100, cancelled: 0,
};
const statusLabel: Record<string, string> = {
  pending: "Proposal", in_progress: "In Progress", under_review: "Review", completed: "Completed", cancelled: "Cancelled",
};
const statusIcon: Record<string, typeof Clock> = {
  pending: Clock, in_progress: TrendingUp, under_review: FileText, completed: CheckCircle2, cancelled: AlertCircle,
};

const Projects = () => {
  const { user } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      if (!user) return;
      const { data: profile } = await supabase.from("profiles").select("company_id").eq("id", user.id).single();
      if (!profile?.company_id) { setLoading(false); return; }
      const { data } = await supabase.from("projects")
        .select("id, name, display_address, city, state, status, total_value, service_type, created_at, updated_at")
        .eq("company_id", profile.company_id).order("updated_at", { ascending: false });
      setProjects(data || []);
      setLoading(false);
    };
    fetch();
  }, [user]);

  if (loading) {
    return <div className="p-6 lg:p-8 space-y-4"><Skeleton className="h-10 w-48" /><div className="space-y-3">{[1,2,3].map(i => <Skeleton key={i} className="h-24" />)}</div></div>;
  }

  const active = projects.filter(p => p.status !== "completed" && p.status !== "cancelled");
  const completed = projects.filter(p => p.status === "completed");
  const all = projects;

  const renderProjects = (list: Project[]) => {
    if (list.length === 0) {
      return (
        <Card className="border-dashed border-2">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <FolderOpen className="h-12 w-12 text-muted-foreground/40 mb-4" />
            <p className="text-muted-foreground">No projects found</p>
          </CardContent>
        </Card>
      );
    }
    return (
      <div className="space-y-3">
        {list.map(project => {
          const progress = statusProgress[project.status] || 10;
          const label = statusLabel[project.status] || "Pending";
          const Icon = statusIcon[project.status] || Clock;
          const location = [project.city, project.state].filter(Boolean).join(", ");
          return (
            <Link key={project.id} to={`/dashboard/projects/${project.id}`}>
              <Card className="hover:shadow-md transition-shadow border-none shadow-sm cursor-pointer">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-foreground">
                        {project.display_address || project.name || "Untitled Project"}
                      </h3>
                      {location && (
                        <div className="flex items-center gap-1 mt-1 text-muted-foreground">
                          <MapPin className="h-3 w-3" /><span className="text-xs">{location}</span>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      {project.total_value ? (
                        <span className="text-sm font-medium text-foreground">${Number(project.total_value).toLocaleString()}</span>
                      ) : null}
                      <Badge variant={project.status === "completed" ? "default" : project.status === "cancelled" ? "destructive" : "secondary"} className="flex items-center gap-1">
                        <Icon className="h-3 w-3" />{label}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Progress value={progress} className="h-1.5 flex-1" />
                    <span className="text-xs font-medium text-muted-foreground w-8 text-right">{progress}%</span>
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>
    );
  };

  return (
    <div className="p-6 lg:p-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-serif font-bold text-foreground">My Projects</h1>
          <p className="text-sm text-muted-foreground">{projects.length} total projects</p>
        </div>
        <Button asChild><Link to="/dashboard/new-quote"><Plus className="mr-2 h-4 w-4" />New Project</Link></Button>
      </div>

      <Tabs defaultValue="active">
        <TabsList>
          <TabsTrigger value="active">Active ({active.length})</TabsTrigger>
          <TabsTrigger value="completed">Completed ({completed.length})</TabsTrigger>
          <TabsTrigger value="all">All ({all.length})</TabsTrigger>
        </TabsList>
        <TabsContent value="active" className="mt-4">{renderProjects(active)}</TabsContent>
        <TabsContent value="completed" className="mt-4">{renderProjects(completed)}</TabsContent>
        <TabsContent value="all" className="mt-4">{renderProjects(all)}</TabsContent>
      </Tabs>
    </div>
  );
};

export default Projects;
