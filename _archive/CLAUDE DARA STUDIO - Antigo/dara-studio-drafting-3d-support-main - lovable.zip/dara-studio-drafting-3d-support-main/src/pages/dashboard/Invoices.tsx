import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CheckCircle2, Clock, AlertCircle, ExternalLink, FileText, DollarSign } from "lucide-react";

interface Invoice {
  id: string;
  stage: string;
  amount: number;
  percentage: number;
  status: string;
  payment_date: string | null;
  project_id: string;
  project_name: string;
}

const Invoices = () => {
  const { user } = useAuth();
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalPaid, setTotalPaid] = useState(0);
  const [totalPending, setTotalPending] = useState(0);

  useEffect(() => {
    const fetch = async () => {
      if (!user) return;
      const { data: profile } = await supabase.from("profiles").select("company_id").eq("id", user.id).single();
      if (!profile?.company_id) { setLoading(false); return; }
      const { data: projects } = await supabase.from("projects")
        .select("id, name, display_address").eq("company_id", profile.company_id);
      if (!projects || projects.length === 0) { setLoading(false); return; }
      const ids = projects.map(p => p.id);
      const { data: milestones } = await supabase.from("payment_milestones")
        .select("*").in("project_id", ids).order("created_at");
      const projectMap = Object.fromEntries(projects.map(p => [p.id, p.display_address || p.name || "Untitled"]));
      const inv: Invoice[] = (milestones || []).map(m => ({
        ...m, project_name: projectMap[m.project_id] || "Unknown",
      }));
      setInvoices(inv);
      setTotalPaid(inv.filter(i => i.status === "paid").reduce((s, i) => s + Number(i.amount), 0));
      setTotalPending(inv.filter(i => i.status !== "paid").reduce((s, i) => s + Number(i.amount), 0));
      setLoading(false);
    };
    fetch();
  }, [user]);

  if (loading) return <div className="p-6 lg:p-8 space-y-4"><Skeleton className="h-10 w-48" /><Skeleton className="h-64" /></div>;

  return (
    <div className="p-6 lg:p-8 space-y-6">
      <div>
        <h1 className="text-2xl font-serif font-bold text-foreground">Invoices</h1>
        <p className="text-sm text-muted-foreground">{invoices.length} total invoices</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-none shadow-sm">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-chart-1/10 flex items-center justify-center">
              <DollarSign className="h-5 w-5 text-chart-1" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Total Paid</p>
              <p className="text-lg font-bold text-foreground">${totalPaid.toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-destructive/10 flex items-center justify-center">
              <Clock className="h-5 w-5 text-destructive" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Outstanding</p>
              <p className="text-lg font-bold text-foreground">${totalPending.toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <FileText className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Total Invoices</p>
              <p className="text-lg font-bold text-foreground">{invoices.length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {invoices.length === 0 ? (
        <Card className="border-dashed"><CardContent className="py-10 text-center text-muted-foreground">No invoices yet</CardContent></Card>
      ) : (
        <Card className="border-none shadow-sm overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Invoice</TableHead>
                <TableHead>Project</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invoices.map(inv => (
                <TableRow key={inv.id}>
                  <TableCell className="font-medium">{inv.stage} ({inv.percentage}%)</TableCell>
                  <TableCell className="text-muted-foreground">{inv.project_name}</TableCell>
                  <TableCell className="font-medium">${Number(inv.amount).toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge variant={inv.status === "paid" ? "default" : inv.status === "overdue" ? "destructive" : "secondary"}>
                      {inv.status === "paid" ? <><CheckCircle2 className="h-3 w-3 mr-1" />Paid</> : inv.status === "overdue" ? <><AlertCircle className="h-3 w-3 mr-1" />Overdue</> : <><Clock className="h-3 w-3 mr-1" />Pending</>}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {inv.status !== "paid" && (
                      <Button size="sm" variant="outline" className="text-xs">
                        <ExternalLink className="h-3 w-3 mr-1" />Pay Online
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  );
};

export default Invoices;
