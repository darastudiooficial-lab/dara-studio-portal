import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Download, FileText, PenTool, FolderOpen, ChevronRight } from "lucide-react";
import { format } from "date-fns";

const DOCUMENT_CATEGORIES = [
  { value: "pre_construction", label: "Pre-Construction" },
  { value: "rev_00", label: "REV 00" },
  { value: "rev_01", label: "REV 01" },
  { value: "rev_02", label: "REV 02" },
  { value: "rev_03", label: "REV 03 (Final)" },
  { value: "final_delivery", label: "Final Delivery" },
  { value: "general", label: "General" },
] as const;

interface FileItem {
  id: string;
  name: string;
  type: "drawing" | "file";
  project_name: string;
  date: string;
  url: string;
  version?: number;
  size?: number | null;
  document_category?: string;
}

const Files = () => {
  const { user } = useAuth();
  const [files, setFiles] = useState<FileItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [openFolders, setOpenFolders] = useState<Set<string>>(new Set(DOCUMENT_CATEGORIES.map(c => c.value)));

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;
      const { data: profile } = await supabase.from("profiles").select("company_id").eq("id", user.id).single();
      if (!profile?.company_id) { setLoading(false); return; }
      const { data: projects } = await supabase.from("projects")
        .select("id, name, display_address").eq("company_id", profile.company_id);
      if (!projects || projects.length === 0) { setLoading(false); return; }
      const ids = projects.map(p => p.id);
      const projectMap = Object.fromEntries(projects.map(p => [p.id, p.display_address || p.name || "Untitled"]));

      const [fRes, dRes] = await Promise.all([
        supabase.from("project_files").select("*").in("project_id", ids).order("created_at", { ascending: false }),
        supabase.from("drawing_versions").select("*").in("project_id", ids).eq("is_current", true).order("created_at", { ascending: false }),
      ]);

      const items: FileItem[] = [];
      (fRes.data || []).forEach(f => items.push({
        id: f.id, name: f.file_name, type: "file", project_name: projectMap[f.project_id] || "Unknown",
        date: f.created_at, url: f.file_url, size: f.file_size,
        document_category: (f as any).document_category || "general",
      }));
      (dRes.data || []).forEach(d => items.push({
        id: d.id, name: d.drawing_name, type: "drawing", project_name: projectMap[d.project_id] || "Unknown",
        date: d.created_at, url: d.file_url, version: d.version_number,
        document_category: "drawings",
      }));
      setFiles(items);
      setLoading(false);
    };
    fetchData();
  }, [user]);

  const toggleFolder = (cat: string) => {
    setOpenFolders(prev => {
      const next = new Set(prev);
      next.has(cat) ? next.delete(cat) : next.add(cat);
      return next;
    });
  };

  if (loading) return <div className="p-6 lg:p-8 space-y-4"><Skeleton className="h-10 w-48" /><Skeleton className="h-64" /></div>;

  const drawingFiles = files.filter(f => f.type === "drawing");
  const docFiles = files.filter(f => f.type === "file");

  const grouped = DOCUMENT_CATEGORIES.reduce((acc, cat) => {
    acc[cat.value] = docFiles.filter(f => (f.document_category || "general") === cat.value);
    return acc;
  }, {} as Record<string, FileItem[]>);

  const nonEmptyFolders = DOCUMENT_CATEGORIES.filter(cat => grouped[cat.value].length > 0);

  const formatSize = (bytes: number | null | undefined) => {
    if (!bytes) return "";
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  };

  return (
    <div className="p-6 lg:p-8 space-y-6">
      <div>
        <h1 className="text-2xl font-serif font-bold text-foreground">Files</h1>
        <p className="text-sm text-muted-foreground">{files.length} files available</p>
      </div>

      {files.length === 0 ? (
        <Card className="border-dashed border-2">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <FolderOpen className="h-12 w-12 text-muted-foreground/40 mb-4" />
            <p className="text-muted-foreground">No files available yet</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {/* Drawings */}
          {drawingFiles.length > 0 && (
            <Card className="border-none shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Drawings</CardTitle>
              </CardHeader>
              <CardContent className="p-0 pb-2">
                {drawingFiles.map(f => (
                  <div key={f.id} className="flex items-center gap-3 px-4 py-2 hover:bg-muted/30 transition-colors">
                    <PenTool className="h-4 w-4 text-primary shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{f.name}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {f.version && `v${f.version} · `}{f.project_name} · {format(new Date(f.date), "MMM d, yyyy")}
                      </p>
                    </div>
                    <Button size="sm" variant="ghost" asChild>
                      <a href={f.url} target="_blank" rel="noopener noreferrer"><Download className="h-4 w-4" /></a>
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Document Folders */}
          {nonEmptyFolders.length > 0 && (
            <Card className="border-none shadow-sm">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm">Documents</CardTitle>
                  <Badge variant="secondary" className="text-[10px]">{docFiles.length} files</Badge>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y divide-border">
                  {nonEmptyFolders.map(cat => {
                    const catFiles = grouped[cat.value];
                    const isOpen = openFolders.has(cat.value);
                    return (
                      <Collapsible key={cat.value} open={isOpen} onOpenChange={() => toggleFolder(cat.value)}>
                        <CollapsibleTrigger className="flex items-center gap-3 w-full px-4 py-3 hover:bg-muted/50 transition-colors text-left">
                          <ChevronRight className={`h-4 w-4 text-muted-foreground transition-transform ${isOpen ? "rotate-90" : ""}`} />
                          <FolderOpen className="h-4 w-4 text-primary" />
                          <span className="text-sm font-medium text-foreground flex-1">{cat.label}</span>
                          <Badge variant="outline" className="text-[10px]">{catFiles.length}</Badge>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="pb-2">
                            {catFiles.map(f => (
                              <div key={f.id} className="flex items-center gap-3 px-12 py-2 hover:bg-muted/30 transition-colors">
                                <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                                <div className="flex-1 min-w-0">
                                  <p className="text-sm font-medium text-foreground truncate">{f.name}</p>
                                  <p className="text-[11px] text-muted-foreground">
                                    {formatSize(f.size)} · {f.project_name} · {format(new Date(f.date), "MMM d, yyyy")}
                                  </p>
                                </div>
                                <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" asChild>
                                  <a href={f.url} target="_blank" rel="noopener noreferrer"><Download className="h-3.5 w-3.5" /></a>
                                </Button>
                              </div>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
};

export default Files;
