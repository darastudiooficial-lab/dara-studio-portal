import { useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useLanguage } from "@/hooks/useLanguage";
import PublicLayout from "@/components/layout/PublicLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Home, LogIn, Mail, MapPin } from "lucide-react";

interface ThankYouState {
  projectAddress: string;
  projectName: string;
  email: string;
}

const ThankYou = () => {
  const { t } = useLanguage();
  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state as ThankYouState | null;

  useEffect(() => {
    // Redirect if accessed directly without state
    if (!state) {
      navigate("/");
    }
  }, [state, navigate]);

  if (!state) {
    return null;
  }

  return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto">
          <Card className="text-center">
            <CardHeader className="pb-4">
              <div className="mx-auto mb-4">
                <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                  <CheckCircle className="w-10 h-10 text-primary" />
                </div>
              </div>
              <CardTitle className="text-2xl md:text-3xl font-serif">
                {t("thankyou.title")}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-lg text-muted-foreground">
                {t("thankyou.message")}
              </p>

              {/* Project Details */}
              <div className="bg-accent/50 rounded-lg p-6 space-y-4">
                <p className="text-sm text-muted-foreground">
                  {t("thankyou.projectCreated")}
                </p>
                <div className="flex items-center justify-center gap-2 text-lg font-semibold">
                  <MapPin className="h-5 w-5 text-primary" />
                  <span>{state.projectAddress}</span>
                </div>
              </div>

              {/* Timeline */}
              <div className="flex items-center justify-center gap-2 text-muted-foreground">
                <Mail className="h-4 w-4" />
                <p>{t("thankyou.proposalTime")}</p>
              </div>

              {/* Portal Access Info */}
              <div className="bg-primary/5 rounded-lg p-4 border border-primary/20">
                <p className="text-sm">
                  {t("thankyou.portalAccess")}
                </p>
                <p className="text-sm font-medium mt-2 text-primary">
                  {state.email}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
                <Button variant="outline" asChild>
                  <Link to="/">
                    <Home className="w-4 h-4 mr-2" />
                    {t("thankyou.goHome")}
                  </Link>
                </Button>
                <Button asChild>
                  <Link to="/auth">
                    <LogIn className="w-4 h-4 mr-2" />
                    {t("thankyou.goPortal")}
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PublicLayout>
  );
};

export default ThankYou;
