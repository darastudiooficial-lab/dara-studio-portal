import { useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import PublicLayout from "@/components/layout/PublicLayout";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, ArrowRight, Send } from "lucide-react";

import {
  TOTAL_STEPS,
  STEP_LABELS,
  PROJECT_TYPES,
  CLIENT_TYPES,
  SIZE_OPTIONS,
  SIZE_OPTIONS_BR,
  FLOOR_OPTIONS,
  RUSH_OPTIONS,
  OPTIONAL_SERVICES,
  DRAFTING_SERVICES,
  DESIGN_SERVICES,
  CONSTRUCTION_TYPE,
  SITE_CONDITIONS,
  PROFESSIONAL_TYPES,
} from "@/components/estimate/types";
import { useEstimateCalculator } from "@/components/estimate/useEstimateCalculator";
import { useConfidenceScore } from "@/components/estimate/useConfidenceScore";
import EstimatePreview from "@/components/estimate/EstimatePreview";
import StepLocation from "@/components/estimate/steps/StepLocation";
import StepClientInfo from "@/components/estimate/steps/StepClientInfo";
import StepOverview from "@/components/estimate/steps/StepOverview";
import StepDetails from "@/components/estimate/steps/StepDetails";
import StepProjectType from "@/components/estimate/steps/StepProjectType";
// StepConditions removed from flow
import StepServices from "@/components/estimate/steps/StepServices";
import StepProgram from "@/components/estimate/steps/StepProgram";
import StepUpload from "@/components/estimate/steps/StepUpload";
import StepTimeline from "@/components/estimate/steps/StepTimeline";
import StepAgreement from "@/components/estimate/steps/StepAgreement";

const EstimateRequest = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const [form, setForm] = useState({
    country: "",
    city: "",
    state: "",
    fullName: "",
    email: "",
    phone: "",
    clientType: "",
    companyName: "",
    companyAddress: "",
    projectDescription: "",
    projectSize: "",
    customSqft: undefined as number | undefined,
    floors: [] as string[],
    lotSize: "",
    projectType: "",
    constructionType: "",
    siteCondition: "",
    draftingServices: [] as string[],
    designServices: [] as string[],
    optionalServices: [] as string[],
    rooms: {} as Record<string, number>,
    specialRequirements: "",
    rushService: "",
    agreeTerms: false,
    notes: "",
  });

  const setField = useCallback((field: string, value: any) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => { const next = { ...prev }; delete next[field]; return next; });
  }, []);

  const estimate = useEstimateCalculator({
    country: form.country,
    projectType: form.projectType,
    projectSize: form.projectSize,
    customSqft: form.customSqft,
    floors: form.floors,
    rushService: form.rushService,
    optionalServices: form.optionalServices,
    draftingServices: form.draftingServices,
  });

  const confidence = useConfidenceScore({
    city: form.city,
    state: form.state,
    projectType: form.projectType,
    projectSize: form.projectSize,
    customSqft: form.customSqft,
    rooms: form.rooms,
    filesCount: files.length,
    timeline: form.rushService || "standard",
  });

  // New step order:
  // 1=Location, 2=About You, 3=Details, 4=Project Type, 5=Services, 
  // 6=Program, 7=Files, 8=Overview, 9=Rush Fees, 10=Review
  const validateStep = (): boolean => {
    const errs: Record<string, string> = {};
    switch (step) {
      case 1:
        if (!form.country) errs.country = "Required";
        if (!form.city) errs.city = "Required";
        if (!form.state) errs.state = "Required";
        break;
      case 2:
        if (!form.fullName || form.fullName.length < 2) errs.fullName = "Name is required";
        if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) errs.email = "Valid email required";
        if (!form.phone || form.phone.length < 7) errs.phone = "Phone is required";
        if (!form.clientType) errs.clientType = "Required";
        if (PROFESSIONAL_TYPES.includes(form.clientType)) {
          if (!form.companyName) errs.companyName = "Company name is required";
          if (!form.companyAddress) errs.companyAddress = "Company address is required";
        }
        break;
      case 3:
        if (!form.projectSize) errs.projectSize = "Required";
        if (form.projectSize === "custom" && (!form.customSqft || form.customSqft < 10)) errs.customSqft = "Enter valid size";
        if (form.floors.length === 0) errs.floors = "Select at least one option";
        break;
      case 4:
        if (!form.projectType) errs.projectType = "Required";
        break;
      case 5: break;
      case 6: break;
      case 7: break;
      case 8: break;
      case 9: break;
      case 10:
        if (!form.agreeTerms) errs.agreeTerms = "You must agree to continue";
        break;
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const next = () => { if (validateStep() && step < TOTAL_STEPS) setStep(step + 1); };
  const prev = () => { if (step > 1) setStep(step - 1); };

  const onSubmit = async () => {
    if (!validateStep()) return;
    setIsSubmitting(true);

    try {
      const fileUrls: string[] = [];
      for (const file of files) {
        const path = `leads/${Date.now()}-${file.name}`;
        const { error: uploadErr } = await supabase.storage.from("project-files").upload(path, file);
        if (!uploadErr) {
          const { data: urlData } = supabase.storage.from("project-files").getPublicUrl(path);
          fileUrls.push(urlData.publicUrl);
        }
      }

      const projLabel = PROJECT_TYPES.find((p) => p.value === form.projectType)?.label || form.projectType;
      const clientLabel = CLIENT_TYPES.find((c) => c.value === form.clientType)?.label || form.clientType;
      const sizeOpts = form.country === "BR" ? SIZE_OPTIONS_BR : SIZE_OPTIONS;
      const sizeLabel = sizeOpts.find((s) => s.value === form.projectSize)?.label || `${form.customSqft} sqft`;
      const floorLabels = form.floors.map(f => FLOOR_OPTIONS.find(fo => fo.value === f)?.label).filter(Boolean).join(", ");
      const rushLabel = RUSH_OPTIONS.find(r => r.value === form.rushService)?.label || "Standard";
      const constructionLabel = CONSTRUCTION_TYPE.find((c) => c.value === form.constructionType)?.label || "";
      const siteLabel = SITE_CONDITIONS.find((s) => s.value === form.siteCondition)?.label || "";
      const draftingLabels = form.draftingServices.map((id) => DRAFTING_SERVICES.find((s) => s.id === id)?.label).filter(Boolean).join(", ");
      const designLabels = form.designServices.map((id) => DESIGN_SERVICES.find((s) => s.id === id)?.label).filter(Boolean).join(", ");
      const optLabels = form.optionalServices.map((id) => OPTIONAL_SERVICES.find((s) => s.id === id)?.label).filter(Boolean).join(", ");

      const roomsSummary = Object.entries(form.rooms).filter(([, v]) => v > 0).map(([k, v]) => `${k}: ${v}`).join(", ");

      const description = `
COUNTRY: ${form.country === "BR" ? "Brazil" : "United States"}
CLIENT TYPE: ${clientLabel}
${form.companyName ? `COMPANY: ${form.companyName}` : ""}
${form.companyAddress ? `COMPANY ADDRESS: ${form.companyAddress}` : ""}
PROJECT LOCATION: ${form.city}, ${form.state}

PROJECT TYPE: ${projLabel}
PROJECT SIZE: ${sizeLabel}
FLOORS: ${floorLabels}
${constructionLabel ? `CONSTRUCTION: ${constructionLabel}` : ""}
${siteLabel ? `SITE: ${siteLabel}` : ""}

DRAFTING SERVICES: ${draftingLabels || "None selected"}
DESIGN SERVICES: ${designLabels || "None selected"}
3D SERVICES: ${optLabels || "None selected"}

${roomsSummary ? `PROGRAM: ${roomsSummary}` : ""}
${form.specialRequirements ? `SPECIAL REQUIREMENTS: ${form.specialRequirements}` : ""}

DELIVERY: ${rushLabel}

ESTIMATED FEE: $${estimate.low.toLocaleString()} – $${estimate.high.toLocaleString()}
CONFIDENCE: ${confidence}%

${form.projectDescription ? `DESCRIPTION: ${form.projectDescription}` : ""}
${fileUrls.length > 0 ? `UPLOADED FILES:\n${fileUrls.join("\n")}` : ""}
${form.notes ? `NOTES: ${form.notes}` : ""}
      `.trim();

      const { error } = await supabase.from("quote_requests").insert({
        full_name: form.fullName,
        email: form.email,
        phone: form.phone,
        company_name: form.companyName || null,
        service_type: "architecture" as const,
        project_address: `${form.city}, ${form.state}`,
        description,
        file_url: fileUrls[0] || null,
      });

      if (error) throw error;

      navigate("/thank-you", {
        state: {
          projectAddress: `${form.city}, ${form.state}`,
          projectName: `${form.fullName} – ${projLabel}`,
          email: form.email,
          estimatedPrice: `$${estimate.low.toLocaleString()} – $${estimate.high.toLocaleString()}`,
        },
      });
    } catch (err) {
      console.error("Submit error:", err);
      toast.error("Error submitting request. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const progress = (step / TOTAL_STEPS) * 100;

  return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-2">
            Get Your Project Estimate
          </h1>
          <p className="text-muted-foreground">
            Answer a few questions and receive a personalized estimate in minutes.
          </p>
        </div>

        {/* Progress */}
        <div className="max-w-4xl mx-auto mb-8">
          <Progress value={progress} className="h-2 mb-3" />
          <div className="flex justify-between text-xs text-muted-foreground">
            {STEP_LABELS.map((label, i) => (
              <span
                key={i}
                className={`hidden lg:block ${step === i + 1 ? "text-primary font-semibold" : step > i + 1 ? "text-primary/60" : ""}`}
              >
                {label}
              </span>
            ))}
            <span className="lg:hidden text-primary font-semibold">
              Step {step} of {TOTAL_STEPS}: {STEP_LABELS[step - 1]}
            </span>
          </div>
        </div>

        <div className="max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            <div className="rounded-xl border border-border bg-card p-6 md:p-8 min-h-[400px]">
              {step === 1 && <StepLocation country={form.country} city={form.city} state={form.state} onFieldChange={setField} errors={errors} />}
              {step === 2 && (
                <StepClientInfo
                  fullName={form.fullName}
                  email={form.email}
                  phone={form.phone}
                  clientType={form.clientType}
                  companyName={form.companyName}
                  companyAddress={form.companyAddress}
                  onFieldChange={setField}
                  errors={errors}
                />
              )}
              {step === 3 && (
                <StepDetails
                  country={form.country}
                  projectSize={form.projectSize}
                  customSqft={form.customSqft}
                  floors={form.floors}
                  lotSize={form.lotSize}
                  onFieldChange={setField}
                  errors={errors}
                />
              )}
              {step === 4 && <StepProjectType value={form.projectType} onChange={(v) => setField("projectType", v)} error={errors.projectType} />}
              {step === 5 && (
                <StepServices
                  draftingServices={form.draftingServices}
                  designServices={form.designServices}
                  optionalServices={form.optionalServices}
                  onFieldChange={setField}
                  errors={errors}
                />
              )}
              {step === 6 && <StepProgram rooms={form.rooms} specialRequirements={form.specialRequirements} onFieldChange={setField} />}
              {step === 7 && <StepUpload files={files} onFilesChange={setFiles} />}
              {step === 8 && <StepOverview value={form.projectDescription} onChange={(v) => setField("projectDescription", v)} />}
              {step === 9 && (
                <StepTimeline
                  rushService={form.rushService}
                  uploadedFileNames={files.map(f => f.name)}
                  onFieldChange={setField}
                  error={errors.rushService}
                />
              )}
              {step === 10 && <StepAgreement agreeTerms={form.agreeTerms} notes={form.notes} onFieldChange={setField} errors={errors} />}

              {/* Navigation */}
              <div className="flex justify-between pt-8">
                <Button type="button" variant="outline" onClick={prev} disabled={step === 1}>
                  <ArrowLeft className="w-4 h-4 mr-2" /> Back
                </Button>
                {step < TOTAL_STEPS ? (
                  <Button type="button" onClick={next}>
                    Next <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                ) : (
                  <Button onClick={onSubmit} disabled={isSubmitting}>
                    {isSubmitting ? "Submitting..." : (
                      <>Submit Request <Send className="w-4 h-4 ml-2" /></>
                    )}
                  </Button>
                )}
              </div>
            </div>
          </div>

          {/* Live Estimate Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <EstimatePreview
                low={estimate.low}
                high={estimate.high}
                total={estimate.total}
                currency={estimate.currency}
                breakdown={estimate.breakdown}
                confidence={confidence}
                canCalculate={estimate.canCalculate}
                complexityLabel={estimate.complexityLabel}
              />
            </div>
          </div>
        </div>
      </div>
    </PublicLayout>
  );
};

export default EstimateRequest;
