import PublicLayout from "@/components/layout/PublicLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  CheckCircle2, 
  FileCheck, 
  Pencil, 
  FileText, 
  Headphones,
  Check,
  X,
  Shield,
  MessageSquare,
  Award
} from "lucide-react";
import ProcessStep from "@/components/how-we-work/ProcessStep";
import { useLanguage } from "@/hooks/useLanguage";

const HowWeWork = () => {
  const { t } = useLanguage();

  const processSteps = [
    {
      number: "1",
      title: t("process.step1.title"),
      description: t("process.step1.desc"),
      icon: FileCheck,
      detailedInfo: t("process.step1.detail"),
    },
    {
      number: "2",
      title: t("process.step2.title"),
      description: t("process.step2.desc"),
      timeline: t("process.step2.timeline"),
      note: t("process.step2.note"),
      icon: Pencil,
      detailedInfo: t("process.step2.detail"),
    },
    {
      number: "3",
      title: t("process.step3.title"),
      description: t("process.step3.desc"),
      note: t("process.step3.note"),
      icon: FileText,
      detailedInfo: t("process.step3.detail"),
    },
    {
      number: "4",
      title: t("process.step4.title"),
      description: t("process.step4.desc"),
      timeline: t("process.step4.timeline"),
      note: t("process.step4.note"),
      icon: CheckCircle2,
      detailedInfo: t("process.step4.detail"),
    },
    {
      number: "5",
      title: t("process.step5.title"),
      description: t("process.step5.desc"),
      icon: Headphones,
      detailedInfo: t("process.step5.detail"),
    },
  ];

  const includedItems = Array.from({ length: 9 }, (_, i) => t(`included.${i + 1}`));
  const notIncludedItems = Array.from({ length: 11 }, (_, i) => t(`notIncluded.${i + 1}`));
  const clientResponsibilities = Array.from({ length: 3 }, (_, i) => t(`responsibility.${i + 1}`));
  const communicationFeatures = Array.from({ length: 4 }, (_, i) => t(`communication.${i + 1}`));
  const whyDara = Array.from({ length: 5 }, (_, i) => t(`whyDara.${i + 1}`));

  return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">
              {t("howWeWork.title")}
            </h1>
            <p className="text-lg text-muted-foreground">
              {t("howWeWork.subtitle")}
            </p>
          </div>

          {/* Our Process */}
          <section className="mb-12">
            <h2 className="text-2xl font-serif font-semibold text-foreground mb-2">
              {t("howWeWork.ourProcess")}
            </h2>
            <p className="text-muted-foreground mb-6">
              {t("howWeWork.ourProcessDesc")}
            </p>
            
            <div className="space-y-4">
              {processSteps.map((step) => (
                <ProcessStep
                  key={step.number}
                  number={step.number}
                  title={step.title}
                  description={step.description}
                  timeline={step.timeline}
                  note={step.note}
                  icon={step.icon}
                  detailedInfo={step.detailedInfo}
                />
              ))}
            </div>
          </section>

          <Separator className="my-8" />

          {/* What's Included */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <Check className="w-6 h-6 text-primary" />
              <h2 className="text-2xl font-serif font-semibold text-foreground">
                {t("howWeWork.whatsIncluded")}
              </h2>
            </div>
            <p className="text-muted-foreground mb-4">
              {t("howWeWork.whatsIncludedDesc")}
            </p>
            
            <Card>
              <CardContent className="p-6">
                <ul className="grid md:grid-cols-2 gap-3">
                  {includedItems.map((item, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      <span className="text-foreground">{item}</span>
                    </li>
                  ))}
                </ul>
                <p className="text-sm text-muted-foreground mt-4 italic">
                  {t("howWeWork.drawingsNote")}
                </p>
              </CardContent>
            </Card>
          </section>

          {/* What's Not Included */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <X className="w-6 h-6 text-destructive" />
              <h2 className="text-2xl font-serif font-semibold text-foreground">
                {t("howWeWork.whatsNotIncluded")}
              </h2>
            </div>
            <p className="text-muted-foreground mb-4">
              {t("howWeWork.whatsNotIncludedDesc")}
            </p>
            
            <Card className="border-destructive/20 bg-destructive/5">
              <CardContent className="p-6">
                <ul className="grid md:grid-cols-2 gap-3">
                  {notIncludedItems.map((item, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <X className="w-4 h-4 text-destructive mt-0.5 flex-shrink-0" />
                      <span className="text-foreground">{item}</span>
                    </li>
                  ))}
                </ul>
                <p className="text-sm text-muted-foreground mt-4 italic">
                  {t("howWeWork.licensedNote")}
                </p>
              </CardContent>
            </Card>
          </section>

          <Separator className="my-8" />

          {/* Compliance & Responsibility */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <Shield className="w-6 h-6 text-primary" />
              <h2 className="text-2xl font-serif font-semibold text-foreground">
                {t("howWeWork.compliance")}
              </h2>
            </div>
            <p className="text-muted-foreground mb-4">
              {t("howWeWork.complianceDesc")}
            </p>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">{t("howWeWork.clientResponsible")}</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {clientResponsibilities.map((item, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      <span className="text-foreground">{item}</span>
                    </li>
                  ))}
                </ul>
                <p className="text-sm text-muted-foreground mt-4 italic">
                  {t("howWeWork.complianceNote")}
                </p>
              </CardContent>
            </Card>
          </section>

          {/* Meetings & Communication */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <MessageSquare className="w-6 h-6 text-primary" />
              <h2 className="text-2xl font-serif font-semibold text-foreground">
                {t("howWeWork.meetings")}
              </h2>
            </div>
            <p className="text-muted-foreground mb-4">
              {t("howWeWork.meetingsDesc")}
            </p>
            
            <Card>
              <CardContent className="p-6">
                <ul className="grid md:grid-cols-2 gap-3">
                  {communicationFeatures.map((item, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      <span className="text-foreground">{item}</span>
                    </li>
                  ))}
                </ul>
                <p className="text-sm text-muted-foreground mt-4">
                  {t("howWeWork.meetingsNote")}
                </p>
              </CardContent>
            </Card>
          </section>

          <Separator className="my-8" />

          {/* Why DA•RA Studio */}
          <section className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <Award className="w-6 h-6 text-primary" />
              <h2 className="text-2xl font-serif font-semibold text-foreground">
                {t("howWeWork.whyDara")}
              </h2>
            </div>
            
            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="p-6">
                <ul className="grid md:grid-cols-2 gap-3">
                  {whyDara.map((item, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                      <span className="text-foreground font-medium">{item}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </section>
        </div>
      </div>
    </PublicLayout>
  );
};

export default HowWeWork;
