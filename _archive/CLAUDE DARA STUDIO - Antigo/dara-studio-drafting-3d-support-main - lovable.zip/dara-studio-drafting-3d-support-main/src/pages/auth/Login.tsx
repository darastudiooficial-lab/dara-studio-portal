// Re-export existing Auth page as Login
export { default } from "@/pages/Auth";
