// Re-export existing FreelancerAuth page as FreelancerLogin
export { default } from "@/pages/FreelancerAuth";
