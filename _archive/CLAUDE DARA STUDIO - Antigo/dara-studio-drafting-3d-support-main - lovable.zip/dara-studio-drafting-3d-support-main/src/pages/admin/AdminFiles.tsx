import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Search, FolderOpen, Download, FileIcon, ChevronRight, Building2 } from "lucide-react";
import { format } from "date-fns";

const CATEGORY_LABELS: Record<string, string> = {
  pre_construction: "📁 Pre-Construction",
  rev_00: "📁 REV 00",
  rev_01: "📁 REV 01",
  rev_02: "📁 REV 02",
  rev_03: "📁 REV 03 (Final)",
  final_delivery: "📁 Final Delivery",
  general: "📁 General",
};

const CATEGORY_ORDER = ["pre_construction", "rev_00", "rev_01", "rev_02", "rev_03", "final_delivery", "general"];

const AdminFiles = () => {
  const [files, setFiles] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [openProjects, setOpenProjects] = useState<Set<string>>(new Set());

  useEffect(() => {
    supabase.from("project_files").select("*, projects(name, companies(name))").order("created_at", { ascending: false })
      .then(({ data }) => setFiles(data || []));
  }, []);

  const filtered = files.filter(f =>
    (f.file_name || "").toLowerCase().includes(search.toLowerCase()) ||
    (f.projects?.name || "").toLowerCase().includes(search.toLowerCase()) ||
    (f.projects?.companies?.name || "").toLowerCase().includes(search.toLowerCase())
  );

  // Group by project
  const byProject = filtered.reduce((acc: Record<string, { project: any; files: any[] }>, f) => {
    const pid = f.project_id;
    if (!acc[pid]) {
      acc[pid] = { project: { id: pid, name: f.projects?.name || "Unnamed Project", company: f.projects?.companies?.name || "" }, files: [] };
    }
    acc[pid].files.push(f);
    return acc;
  }, {});

  const formatSize = (bytes: number | null) => {
    if (!bytes) return "—";
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  };

  const toggleProject = (pid: string) => {
    setOpenProjects(prev => {
      const next = new Set(prev);
      next.has(pid) ? next.delete(pid) : next.add(pid);
      return next;
    });
  };

  const downloadAll = (projectFiles: any[]) => {
    projectFiles.forEach((f, i) => {
      setTimeout(() => {
        const a = document.createElement("a");
        a.href = f.file_url;
        a.target = "_blank";
        a.rel = "noopener noreferrer";
        a.click();
      }, i * 300);
    });
  };

  const projectEntries = Object.entries(byProject).sort((a, b) => (a[1] as any).project.name.localeCompare((b[1] as any).project.name));

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-foreground">Project Files</h1>
          <p className="text-sm text-muted-foreground">All files organized by project and revision</p>
        </div>
        <Badge variant="secondary">{files.length} files • {projectEntries.length} projects</Badge>
      </div>

      <div className="relative max-w-xs">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search files, projects, companies..." className="pl-10" value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      {projectEntries.length === 0 && (
        <Card className="border-none shadow-sm">
          <CardContent className="py-12 text-center text-muted-foreground">
            <FolderOpen className="h-8 w-8 mx-auto mb-2 opacity-40" />
            No files yet
          </CardContent>
        </Card>
      )}

      <div className="space-y-3">
        {projectEntries.map(([pid, entry]) => {
          const { project, files: pFiles } = entry as { project: any; files: any[] };
          const isOpen = openProjects.has(pid);
          const categorized = CATEGORY_ORDER.reduce((acc: Record<string, any[]>, cat) => {
            const catFiles = pFiles.filter(f => (f.document_category || "general") === cat);
            if (catFiles.length > 0) acc[cat] = catFiles;
            return acc;
          }, {});

          return (
            <Collapsible key={pid} open={isOpen} onOpenChange={() => toggleProject(pid)}>
              <Card className="border shadow-sm">
                <CollapsibleTrigger asChild>
                  <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors py-3 px-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <ChevronRight className={`h-4 w-4 text-muted-foreground transition-transform ${isOpen ? "rotate-90" : ""}`} />
                        <div>
                          <CardTitle className="text-sm font-semibold">{project.name}</CardTitle>
                          {project.company && (
                            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                              <Building2 className="h-3 w-3" /> {project.company}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">{pFiles.length} files</Badge>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-7 gap-1.5 text-xs"
                          onClick={(e) => { e.stopPropagation(); downloadAll(pFiles); }}
                        >
                          <Download className="h-3 w-3" /> Download All
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <CardContent className="pt-0 pb-3 px-4 space-y-3">
                    {Object.entries(categorized).map(([cat, catFiles]) => (
                      <div key={cat} className="space-y-1">
                        <p className="text-xs font-medium text-muted-foreground pl-1">{CATEGORY_LABELS[cat] || cat}</p>
                        <div className="space-y-0.5">
                          {catFiles.map((f: any) => (
                            <div key={f.id} className="flex items-center justify-between py-1.5 px-2 rounded hover:bg-muted/50 group">
                              <div className="flex items-center gap-2 min-w-0 flex-1">
                                <FileIcon className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                                <span className="text-sm truncate">{f.file_name}</span>
                                <Badge variant="outline" className="text-[9px] flex-shrink-0">{f.file_type || "—"}</Badge>
                              </div>
                              <div className="flex items-center gap-3 text-xs text-muted-foreground flex-shrink-0">
                                <span>{formatSize(f.file_size)}</span>
                                <span>{format(new Date(f.created_at), "MMM d, yyyy")}</span>
                                <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity" asChild>
                                  <a href={f.file_url} target="_blank" rel="noopener noreferrer"><Download className="h-3 w-3" /></a>
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </CollapsibleContent>
              </Card>
            </Collapsible>
          );
        })}
      </div>
    </div>
  );
};

export default AdminFiles;
