import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Plus, Upload, Camera, HardHat, ExternalLink, Calendar } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

const AdminSiteUpdates = () => {
  const navigate = useNavigate();
  const [updates, setUpdates] = useState<any[]>([]);
  const [projects, setProjects] = useState<any[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [selectedProject, setSelectedProject] = useState("");
  const [description, setDescription] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [filterProject, setFilterProject] = useState("all");

  const fetchData = async () => {
    const [updRes, projRes] = await Promise.all([
      supabase.from("site_updates").select("*, projects(name, street_name, street_number, companies(name))").order("created_at", { ascending: false }),
      supabase.from("projects").select("id, name, street_name, street_number, companies(name)").order("created_at", { ascending: false }),
    ]);
    setUpdates(updRes.data || []);
    setProjects(projRes.data || []);
  };

  useEffect(() => { fetchData(); }, []);

  useEffect(() => {
    const channel = supabase
      .channel("site-updates-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "site_updates" }, () => fetchData())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  const getProjectLabel = (p: any) => {
    const addr = [p.street_number, p.street_name].filter(Boolean).join(" ");
    return addr || p.name || p.companies?.name || "—";
  };

  const handleUpload = async () => {
    if (!selectedProject || files.length === 0) {
      toast.error("Select a project and at least one file");
      return;
    }
    setUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      for (const file of files) {
        const ext = file.name.split(".").pop();
        const path = `${selectedProject}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
        const { error: uploadError } = await supabase.storage.from("site-updates").upload(path, file);
        if (uploadError) { toast.error(`Upload failed: ${file.name}`); continue; }
        const { data: urlData } = supabase.storage.from("site-updates").getPublicUrl(path);

        await supabase.from("site_updates").insert({
          project_id: selectedProject,
          uploaded_by: user?.id || null,
          media_url: urlData.publicUrl,
          description: description || null,
        });
      }
      toast.success(`${files.length} update(s) uploaded`);
      setDialogOpen(false);
      setFiles([]);
      setDescription("");
      fetchData();
    } catch {
      toast.error("Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const filtered = filterProject === "all"
    ? updates
    : updates.filter(u => u.project_id === filterProject);

  // Group by date
  const grouped: Record<string, any[]> = {};
  filtered.forEach(u => {
    const day = format(new Date(u.created_at), "yyyy-MM-dd");
    if (!grouped[day]) grouped[day] = [];
    grouped[day].push(u);
  });

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-foreground">Site Updates</h1>
          <p className="text-sm text-muted-foreground">Construction progress photos and updates</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={filterProject} onValueChange={setFilterProject}>
            <SelectTrigger className="w-[220px]">
              <SelectValue placeholder="Filter by project" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Projects</SelectItem>
              {projects.map(p => (
                <SelectItem key={p.id} value={p.id}>{getProjectLabel(p)}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="h-4 w-4 mr-2" /> New Update</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Upload Site Update</DialogTitle></DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Project *</Label>
                  <Select value={selectedProject || "none"} onValueChange={v => v !== "none" && setSelectedProject(v)}>
                    <SelectTrigger><SelectValue placeholder="Select project" /></SelectTrigger>
                    <SelectContent>
                      {projects.map(p => (
                        <SelectItem key={p.id} value={p.id}>{getProjectLabel(p)}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Photos / Videos *</Label>
                  <div className="mt-1">
                    <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer hover:bg-muted/50 transition-colors border-border">
                      <div className="flex flex-col items-center">
                        <Camera className="h-8 w-8 text-muted-foreground mb-2" />
                        <p className="text-sm text-muted-foreground">
                          {files.length > 0 ? `${files.length} file(s) selected` : "Tap to take photo or select files"}
                        </p>
                      </div>
                      <input
                        type="file"
                        className="hidden"
                        multiple
                        accept="image/*,video/*"
                        capture="environment"
                        onChange={e => setFiles(Array.from(e.target.files || []))}
                      />
                    </label>
                  </div>
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                    placeholder="Describe what's happening on site..."
                    className="mt-1"
                  />
                </div>
                <Button className="w-full" onClick={handleUpload} disabled={uploading}>
                  {uploading ? (
                    <>
                      <Upload className="h-4 w-4 mr-2 animate-spin" /> Uploading...
                    </>
                  ) : (
                    <>
                      <Upload className="h-4 w-4 mr-2" /> Upload Update
                    </>
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-none shadow-sm">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-primary/15">
              <HardHat className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{updates.length}</p>
              <p className="text-xs text-muted-foreground">Total Updates</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-chart-2/15">
              <Camera className="h-5 w-5 text-chart-2" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {new Set(updates.map(u => u.project_id)).size}
              </p>
              <p className="text-xs text-muted-foreground">Projects with Updates</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-chart-4/15">
              <Calendar className="h-5 w-5 text-chart-4" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {updates.filter(u => {
                  const d = new Date(u.created_at);
                  const now = new Date();
                  return d.toDateString() === now.toDateString();
                }).length}
              </p>
              <p className="text-xs text-muted-foreground">Today's Updates</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Timeline */}
      {Object.keys(grouped).length === 0 ? (
        <Card className="border-none shadow-sm">
          <CardContent className="text-center py-16">
            <HardHat className="h-12 w-12 mx-auto mb-3 text-muted-foreground/40" />
            <p className="text-muted-foreground">No site updates yet</p>
            <p className="text-xs text-muted-foreground/70 mt-1">Upload progress photos from the construction site</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {Object.entries(grouped).map(([date, items]) => (
            <div key={date}>
              <div className="flex items-center gap-2 mb-3">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium text-muted-foreground">
                  {format(new Date(date), "MMMM d, yyyy")}
                </span>
                <Badge variant="secondary" className="text-xs">{items.length}</Badge>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {items.map(update => {
                  const projectLabel = [update.projects?.street_number, update.projects?.street_name].filter(Boolean).join(" ") || update.projects?.name || "—";
                  const isVideo = update.media_url?.match(/\.(mp4|mov|webm|avi)$/i);
                  return (
                    <Card key={update.id} className="border-none shadow-sm overflow-hidden">
                      <div className="aspect-video bg-muted relative">
                        {isVideo ? (
                          <video src={update.media_url} controls className="w-full h-full object-cover" />
                        ) : (
                          <img src={update.media_url} alt="Site update" className="w-full h-full object-cover" />
                        )}
                      </div>
                      <CardContent className="p-3 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span
                            className="text-sm font-medium text-primary hover:underline cursor-pointer"
                            onClick={() => {
                              const proj = projects.find(p => p.id === update.project_id);
                              if (proj) navigate(`/adm/projects/${proj.id}`);
                            }}
                          >
                            {projectLabel}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {format(new Date(update.created_at), "h:mm a")}
                          </span>
                        </div>
                        {update.projects?.companies?.name && (
                          <p className="text-xs text-muted-foreground">{update.projects.companies.name}</p>
                        )}
                        {update.description && (
                          <p className="text-sm text-foreground">{update.description}</p>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AdminSiteUpdates;
