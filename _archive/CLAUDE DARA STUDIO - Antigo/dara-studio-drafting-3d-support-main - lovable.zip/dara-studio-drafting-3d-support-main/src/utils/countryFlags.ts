// Shared utility for country flags
export const getCountryFlag = (country: string | null | undefined): string => {
  if (country === "Brazil") return "🇧🇷";
  if (country === "USA") return "🇺🇸";
  return "";
};

export const getLanguageLabel = (lang: string | null | undefined): string => {
  if (lang === "pt") return "Portuguese";
  return "English";
};
