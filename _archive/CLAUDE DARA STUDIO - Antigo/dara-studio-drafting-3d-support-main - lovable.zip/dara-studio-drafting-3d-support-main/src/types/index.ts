// Shared type definitions
export {};
