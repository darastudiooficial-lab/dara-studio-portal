import { NavLink, useLocation } from "react-router-dom";
import { LayoutDashboard, FolderOpen, FileText, MessageSquare, User, Building2, LogOut, Plus } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/hooks/useLanguage";
import { Button } from "@/components/ui/button";
import { Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarHeader, SidebarFooter, useSidebar } from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";

const DashboardSidebar = () => {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const location = useLocation();
  const { signOut, user } = useAuth();
  const { t } = useLanguage();

  const mainNavItems = [
    { title: t("dashboard.home"), url: "/dashboard", icon: LayoutDashboard },
    { title: t("dashboard.myProjects"), url: "/dashboard/projects", icon: FolderOpen },
    { title: t("dashboard.quotesInvoices"), url: "/dashboard/quotes", icon: FileText },
    { title: t("dashboard.messages"), url: "/dashboard/messages", icon: MessageSquare },
  ];

  const settingsNavItems = [
    { title: t("dashboard.myProfile"), url: "/dashboard/profile", icon: User },
    { title: t("dashboard.companyInfo"), url: "/dashboard/company", icon: Building2 },
  ];

  const isActive = (path: string) => {
    if (path === "/dashboard") return location.pathname === "/dashboard";
    return location.pathname.startsWith(path);
  };

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border p-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
            <span className="text-primary-foreground font-semibold text-sm">{user?.email?.charAt(0).toUpperCase() || "C"}</span>
          </div>
          {!collapsed && (
            <div className="flex flex-col">
              <span className="font-semibold text-sm text-sidebar-foreground truncate max-w-[140px]">{user?.user_metadata?.full_name || "Client"}</span>
              <span className="text-xs text-sidebar-foreground/60 truncate max-w-[140px]">{user?.email}</span>
            </div>
          )}
        </div>
      </SidebarHeader>
      <SidebarContent>
        <div className="p-3">
          <Button asChild className="w-full" size={collapsed ? "icon" : "default"}>
            <NavLink to="/dashboard/new-quote">
              <Plus className={cn("h-4 w-4", !collapsed && "mr-2")} />
              {!collapsed && t("dashboard.newQuoteRequest")}
            </NavLink>
          </Button>
        </div>
        <SidebarGroup>
          <SidebarGroupLabel>{t("dashboard.menu")}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainNavItems.map((item) => (
                <SidebarMenuItem key={item.url}>
                  <SidebarMenuButton asChild isActive={isActive(item.url)} tooltip={item.title}>
                    <NavLink to={item.url}><item.icon className="h-4 w-4" /><span>{item.title}</span></NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        <SidebarGroup>
          <SidebarGroupLabel>{t("dashboard.settings")}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {settingsNavItems.map((item) => (
                <SidebarMenuItem key={item.url}>
                  <SidebarMenuButton asChild isActive={isActive(item.url)} tooltip={item.title}>
                    <NavLink to={item.url}><item.icon className="h-4 w-4" /><span>{item.title}</span></NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="border-t border-sidebar-border p-3">
        <Button variant="ghost" className="w-full justify-start text-sidebar-foreground/70 hover:text-sidebar-foreground" onClick={signOut}>
          <LogOut className={cn("h-4 w-4", !collapsed && "mr-2")} />
          {!collapsed && t("dashboard.signOut")}
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
};

export default DashboardSidebar;
