import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import { LanguageProvider } from "@/hooks/useLanguage";

// Public pages
import Index from "./pages/Index";
import Orcamento from "./pages/Orcamento";
import HowWeWork from "./pages/HowWeWork";
import Auth from "./pages/Auth";
import FreelancerAuth from "./pages/FreelancerAuth";
import ThankYou from "./pages/ThankYou";
import NotFound from "./pages/NotFound";

// Dashboard
import DashboardLayout from "./components/dashboard/DashboardLayout";
import DashboardHome from "./pages/dashboard/DashboardHome";
import Projects from "./pages/dashboard/Projects";
import Quotes from "./pages/dashboard/Quotes";
import Messages from "./pages/dashboard/Messages";
import Profile from "./pages/dashboard/Profile";
import Company from "./pages/dashboard/Company";
import NewQuote from "./pages/dashboard/NewQuote";

// Freelancer Workspace
import FreelancerLayout from "./components/freelancer/FreelancerLayout";
import FreelancerHome from "./pages/freelancer/FreelancerHome";
import FreelancerProjects from "./pages/freelancer/FreelancerProjects";
import FreelancerPayments from "./pages/freelancer/FreelancerPayments";
import FreelancerContracts from "./pages/freelancer/FreelancerContracts";
import FreelancerCalendar from "./pages/freelancer/FreelancerCalendar";
import FreelancerProfile from "./pages/freelancer/FreelancerProfile";

// Admin Panel
import AdminLayout from "./components/admin/AdminLayout";
import AdminLogin from "./pages/admin/AdminLogin";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminCompanies from "./pages/admin/AdminCompanies";
import AdminProjects from "./pages/admin/AdminProjects";
import AdminPayments from "./pages/admin/AdminPayments";
import AdminMilestones from "./pages/admin/AdminMilestones";
import AdminActivity from "./pages/admin/AdminActivity";
import AdminMap from "./pages/admin/AdminMap";
import AdminGantt from "./pages/admin/AdminGantt";
import AdminFreelancers from "./pages/admin/AdminFreelancers";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <LanguageProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AuthProvider>
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<Index />} />
              <Route path="/orcamento" element={<Orcamento />} />
              <Route path="/how-we-work" element={<HowWeWork />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/freelancer" element={<FreelancerAuth />} />
              <Route path="/thank-you" element={<ThankYou />} />

              {/* Admin Login */}
              <Route path="/adm/login" element={<AdminLogin />} />

              {/* Dashboard Routes (Protected) */}
              <Route path="/dashboard" element={<DashboardLayout />}>
                <Route index element={<DashboardHome />} />
                <Route path="projects" element={<Projects />} />
                <Route path="quotes" element={<Quotes />} />
                <Route path="messages" element={<Messages />} />
                <Route path="profile" element={<Profile />} />
                <Route path="company" element={<Company />} />
                <Route path="new-quote" element={<NewQuote />} />
              </Route>

              {/* Freelancer Workspace (Protected - Freelancer Role) */}
              <Route path="/work" element={<FreelancerLayout />}>
                <Route index element={<FreelancerHome />} />
                <Route path="projects" element={<FreelancerProjects />} />
                <Route path="payments" element={<FreelancerPayments />} />
                <Route path="contracts" element={<FreelancerContracts />} />
                <Route path="calendar" element={<FreelancerCalendar />} />
                <Route path="profile" element={<FreelancerProfile />} />
              </Route>

              {/* Admin Panel (Protected - Admin Role) */}
              <Route path="/adm" element={<AdminLayout />}>
                <Route index element={<AdminDashboard />} />
                <Route path="companies" element={<AdminCompanies />} />
                <Route path="projects" element={<AdminProjects />} />
                <Route path="gantt" element={<AdminGantt />} />
                <Route path="map" element={<AdminMap />} />
                <Route path="payments" element={<AdminPayments />} />
                <Route path="milestones" element={<AdminMilestones />} />
                <Route path="activity" element={<AdminActivity />} />
                <Route path="freelancers" element={<AdminFreelancers />} />
              </Route>

              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </LanguageProvider>
  </QueryClientProvider>
);

export default App;
