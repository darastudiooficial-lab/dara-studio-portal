export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      activity_log: {
        Row: {
          created_at: string
          description: string
          id: string
          log_date: string
          log_type: string
          project_id: string
        }
        Insert: {
          created_at?: string
          description: string
          id?: string
          log_date?: string
          log_type?: string
          project_id: string
        }
        Update: {
          created_at?: string
          description?: string
          id?: string
          log_date?: string
          log_type?: string
          project_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "activity_log_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_payments: {
        Row: {
          amount_paid: number
          amount_total: number
          created_at: string
          id: string
          installment_type: string
          net_received: number | null
          payment_date: string | null
          payment_method: string | null
          payment_notes: string | null
          price_table: string | null
          project_id: string
          status: string
          stripe_fee_percent: number | null
          third_party_costs: number | null
          updated_at: string
          value_brl: number | null
        }
        Insert: {
          amount_paid?: number
          amount_total?: number
          created_at?: string
          id?: string
          installment_type?: string
          net_received?: number | null
          payment_date?: string | null
          payment_method?: string | null
          payment_notes?: string | null
          price_table?: string | null
          project_id: string
          status?: string
          stripe_fee_percent?: number | null
          third_party_costs?: number | null
          updated_at?: string
          value_brl?: number | null
        }
        Update: {
          amount_paid?: number
          amount_total?: number
          created_at?: string
          id?: string
          installment_type?: string
          net_received?: number | null
          payment_date?: string | null
          payment_method?: string | null
          payment_notes?: string | null
          price_table?: string | null
          project_id?: string
          status?: string
          stripe_fee_percent?: number | null
          third_party_costs?: number | null
          updated_at?: string
          value_brl?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "admin_payments_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      companies: {
        Row: {
          address: string | null
          avatar_url: string | null
          city: string | null
          company_type: string | null
          country: string | null
          created_at: string
          email: string | null
          id: string
          instagram: string | null
          linkedin: string | null
          name: string
          neighborhood: string | null
          owner_name: string | null
          phone: string | null
          state: string | null
          status: string | null
          street_name: string | null
          street_number: string | null
          unit: string | null
          updated_at: string
          website: string | null
          zip_code: string | null
        }
        Insert: {
          address?: string | null
          avatar_url?: string | null
          city?: string | null
          company_type?: string | null
          country?: string | null
          created_at?: string
          email?: string | null
          id?: string
          instagram?: string | null
          linkedin?: string | null
          name: string
          neighborhood?: string | null
          owner_name?: string | null
          phone?: string | null
          state?: string | null
          status?: string | null
          street_name?: string | null
          street_number?: string | null
          unit?: string | null
          updated_at?: string
          website?: string | null
          zip_code?: string | null
        }
        Update: {
          address?: string | null
          avatar_url?: string | null
          city?: string | null
          company_type?: string | null
          country?: string | null
          created_at?: string
          email?: string | null
          id?: string
          instagram?: string | null
          linkedin?: string | null
          name?: string
          neighborhood?: string | null
          owner_name?: string | null
          phone?: string | null
          state?: string | null
          status?: string | null
          street_name?: string | null
          street_number?: string | null
          unit?: string | null
          updated_at?: string
          website?: string | null
          zip_code?: string | null
        }
        Relationships: []
      }
      freelancer_assignments: {
        Row: {
          assigned_at: string
          deadline: string | null
          freelancer_id: string
          id: string
          notes: string | null
          project_id: string
        }
        Insert: {
          assigned_at?: string
          deadline?: string | null
          freelancer_id: string
          id?: string
          notes?: string | null
          project_id: string
        }
        Update: {
          assigned_at?: string
          deadline?: string | null
          freelancer_id?: string
          id?: string
          notes?: string | null
          project_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "freelancer_assignments_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      freelancer_contracts: {
        Row: {
          created_at: string
          file_url: string | null
          freelancer_id: string
          id: string
          is_signed: boolean
          project_id: string
          signed_at: string | null
          title: string
        }
        Insert: {
          created_at?: string
          file_url?: string | null
          freelancer_id: string
          id?: string
          is_signed?: boolean
          project_id: string
          signed_at?: string | null
          title: string
        }
        Update: {
          created_at?: string
          file_url?: string | null
          freelancer_id?: string
          id?: string
          is_signed?: boolean
          project_id?: string
          signed_at?: string | null
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "freelancer_contracts_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      freelancer_deliveries: {
        Row: {
          created_at: string
          file_name: string
          file_url: string
          freelancer_id: string
          id: string
          notes: string | null
          project_id: string
        }
        Insert: {
          created_at?: string
          file_name: string
          file_url: string
          freelancer_id: string
          id?: string
          notes?: string | null
          project_id: string
        }
        Update: {
          created_at?: string
          file_name?: string
          file_url?: string
          freelancer_id?: string
          id?: string
          notes?: string | null
          project_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "freelancer_deliveries_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      freelancer_payments: {
        Row: {
          agreed_amount: number
          amount: number
          created_at: string
          description: string | null
          due_date: string | null
          freelancer_id: string
          id: string
          paid_amount: number
          payment_method: string | null
          project_id: string
          status: string
          updated_at: string
        }
        Insert: {
          agreed_amount?: number
          amount: number
          created_at?: string
          description?: string | null
          due_date?: string | null
          freelancer_id: string
          id?: string
          paid_amount?: number
          payment_method?: string | null
          project_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          agreed_amount?: number
          amount?: number
          created_at?: string
          description?: string | null
          due_date?: string | null
          freelancer_id?: string
          id?: string
          paid_amount?: number
          payment_method?: string | null
          project_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "freelancer_payments_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          content: string
          created_at: string
          id: string
          is_from_admin: boolean
          project_id: string
          sender_id: string | null
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          is_from_admin?: boolean
          project_id: string
          sender_id?: string | null
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          is_from_admin?: boolean
          project_id?: string
          sender_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "messages_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      milestones: {
        Row: {
          approved_date: string | null
          created_at: string
          id: string
          name: string
          notes: string | null
          project_id: string
          sent_date: string | null
          status: string
        }
        Insert: {
          approved_date?: string | null
          created_at?: string
          id?: string
          name: string
          notes?: string | null
          project_id: string
          sent_date?: string | null
          status?: string
        }
        Update: {
          approved_date?: string | null
          created_at?: string
          id?: string
          name?: string
          notes?: string | null
          project_id?: string
          sent_date?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "milestones_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      packages: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          slug: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          slug: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          slug?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          company_id: string | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          instagram: string | null
          phone: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          company_id?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          instagram?: string | null
          phone?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          company_id?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          instagram?: string | null
          phone?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      project_files: {
        Row: {
          created_at: string
          file_name: string
          file_size: number | null
          file_type: string | null
          file_url: string
          id: string
          project_id: string
          uploaded_by: string | null
        }
        Insert: {
          created_at?: string
          file_name: string
          file_size?: number | null
          file_type?: string | null
          file_url: string
          id?: string
          project_id: string
          uploaded_by?: string | null
        }
        Update: {
          created_at?: string
          file_name?: string
          file_size?: number | null
          file_type?: string | null
          file_url?: string
          id?: string
          project_id?: string
          uploaded_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "project_files_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      project_services: {
        Row: {
          id: string
          project_id: string
          service_id: string
        }
        Insert: {
          id?: string
          project_id: string
          service_id: string
        }
        Update: {
          id?: string
          project_id?: string
          service_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_services_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "project_services_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      projects: {
        Row: {
          address: string | null
          city: string | null
          company_id: string
          country: string | null
          cover_image: string | null
          created_at: string
          currency: string
          date_notes: Json | null
          delivery_date: string | null
          description: string | null
          display_address: string | null
          entry_payment_percent: number
          final_delivery_date: string | null
          id: string
          internal_notes: string | null
          is_portfolio: boolean
          latitude: number | null
          longitude: number | null
          name: string | null
          neighborhood: string | null
          package_id: string | null
          payment_effective_date: string | null
          payment_stage: string
          preview_delivery_date: string | null
          preview_sent_date: string | null
          revision_count: number
          revision_return_date: string | null
          service_type: Database["public"]["Enums"]["service_type"]
          square_feet: number | null
          stage: string | null
          start_date: string | null
          state: string | null
          status: Database["public"]["Enums"]["project_status"]
          street_name: string | null
          street_number: string | null
          total_value: number | null
          unit: string | null
          updated_at: string
          zip_code: string | null
        }
        Insert: {
          address?: string | null
          city?: string | null
          company_id: string
          country?: string | null
          cover_image?: string | null
          created_at?: string
          currency?: string
          date_notes?: Json | null
          delivery_date?: string | null
          description?: string | null
          display_address?: string | null
          entry_payment_percent?: number
          final_delivery_date?: string | null
          id?: string
          internal_notes?: string | null
          is_portfolio?: boolean
          latitude?: number | null
          longitude?: number | null
          name?: string | null
          neighborhood?: string | null
          package_id?: string | null
          payment_effective_date?: string | null
          payment_stage?: string
          preview_delivery_date?: string | null
          preview_sent_date?: string | null
          revision_count?: number
          revision_return_date?: string | null
          service_type?: Database["public"]["Enums"]["service_type"]
          square_feet?: number | null
          stage?: string | null
          start_date?: string | null
          state?: string | null
          status?: Database["public"]["Enums"]["project_status"]
          street_name?: string | null
          street_number?: string | null
          total_value?: number | null
          unit?: string | null
          updated_at?: string
          zip_code?: string | null
        }
        Update: {
          address?: string | null
          city?: string | null
          company_id?: string
          country?: string | null
          cover_image?: string | null
          created_at?: string
          currency?: string
          date_notes?: Json | null
          delivery_date?: string | null
          description?: string | null
          display_address?: string | null
          entry_payment_percent?: number
          final_delivery_date?: string | null
          id?: string
          internal_notes?: string | null
          is_portfolio?: boolean
          latitude?: number | null
          longitude?: number | null
          name?: string | null
          neighborhood?: string | null
          package_id?: string | null
          payment_effective_date?: string | null
          payment_stage?: string
          preview_delivery_date?: string | null
          preview_sent_date?: string | null
          revision_count?: number
          revision_return_date?: string | null
          service_type?: Database["public"]["Enums"]["service_type"]
          square_feet?: number | null
          stage?: string | null
          start_date?: string | null
          state?: string | null
          status?: Database["public"]["Enums"]["project_status"]
          street_name?: string | null
          street_number?: string | null
          total_value?: number | null
          unit?: string | null
          updated_at?: string
          zip_code?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "projects_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "projects_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "packages"
            referencedColumns: ["id"]
          },
        ]
      }
      quote_requests: {
        Row: {
          company_name: string | null
          created_at: string
          description: string | null
          email: string
          file_url: string | null
          full_name: string
          id: string
          phone: string | null
          processed: boolean
          project_address: string | null
          service_type: Database["public"]["Enums"]["service_type"]
        }
        Insert: {
          company_name?: string | null
          created_at?: string
          description?: string | null
          email: string
          file_url?: string | null
          full_name: string
          id?: string
          phone?: string | null
          processed?: boolean
          project_address?: string | null
          service_type: Database["public"]["Enums"]["service_type"]
        }
        Update: {
          company_name?: string | null
          created_at?: string
          description?: string | null
          email?: string
          file_url?: string | null
          full_name?: string
          id?: string
          phone?: string | null
          processed?: boolean
          project_address?: string | null
          service_type?: Database["public"]["Enums"]["service_type"]
        }
        Relationships: []
      }
      quotes: {
        Row: {
          amount: number
          company_id: string
          created_at: string
          description: string | null
          id: string
          payment_link: string | null
          project_id: string
          status: Database["public"]["Enums"]["quote_status"]
          title: string
          updated_at: string
          valid_until: string | null
        }
        Insert: {
          amount: number
          company_id: string
          created_at?: string
          description?: string | null
          id?: string
          payment_link?: string | null
          project_id: string
          status?: Database["public"]["Enums"]["quote_status"]
          title: string
          updated_at?: string
          valid_until?: string | null
        }
        Update: {
          amount?: number
          company_id?: string
          created_at?: string
          description?: string | null
          id?: string
          payment_link?: string | null
          project_id?: string
          status?: Database["public"]["Enums"]["quote_status"]
          title?: string
          updated_at?: string
          valid_until?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "quotes_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quotes_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      services: {
        Row: {
          created_at: string
          id: string
          name: string
          slug: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          slug: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          slug?: string
        }
        Relationships: []
      }
      support_messages: {
        Row: {
          created_at: string
          email: string
          id: string
          message: string
          name: string
          subject: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          message: string
          name: string
          subject?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          message?: string
          name?: string
          subject?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      user_belongs_to_company: {
        Args: { target_company_id: string; user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user" | "freelancer"
      project_status:
        | "pending"
        | "in_progress"
        | "under_review"
        | "completed"
        | "cancelled"
      quote_status: "draft" | "sent" | "approved" | "paid"
      service_type:
        | "technical_drafting"
        | "executive_project"
        | "wood_frame_structures"
        | "project_budgeting"
        | "remodeling"
        | "3d_kitchen"
        | "architecture"
        | "pdf_cad"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user", "freelancer"],
      project_status: [
        "pending",
        "in_progress",
        "under_review",
        "completed",
        "cancelled",
      ],
      quote_status: ["draft", "sent", "approved", "paid"],
      service_type: [
        "technical_drafting",
        "executive_project",
        "wood_frame_structures",
        "project_budgeting",
        "remodeling",
        "3d_kitchen",
        "architecture",
        "pdf_cad",
      ],
    },
  },
} as const
