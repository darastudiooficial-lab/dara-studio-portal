import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import PublicLayout from "@/components/layout/PublicLayout";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, ArrowRight, Send, Building2, User, FileText, MapPin } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";

import { formSchema, FormData, DARA_SERVICES, getAllSpacesFlat, PROJECT_LEVELS } from "@/components/orcamento/types";
import StepLocation from "@/components/orcamento/StepLocation";
import StepProject from "@/components/orcamento/StepProject";
import StepClientInfo from "@/components/orcamento/StepClientInfo";
import StepDetails from "@/components/orcamento/StepDetails";

const STEP_ICONS = [MapPin, FileText, User, Building2];

const Orcamento = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const { t } = useLanguage();

  const STEPS = [
    { id: 1, title: t("quote.step.location") },
    { id: 2, title: t("quote.step.project") },
    { id: 3, title: t("quote.step.client") },
    { id: 4, title: t("quote.step.details") },
  ];

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      projectAddress: "",
      projectCity: "",
      projectState: "",
      projectZipCode: "",
      projectType: "",
      otherProjectType: "",
      totalArea: "",
      numberOfFloors: "",
      hasExistingProject: undefined,
      buildingStatus: "",
      existingArea: "",
      estimatedSize: "",
      projectLevels: [],
      requiredSpaces: [],
      otherSpace: "",
      hasEngineer: undefined,
      referenceNotes: "",
      referenceLinks: "",
      selectedDaraServices: [],
      desiredServices: [],
      clientType: undefined,
      fullName: "",
      email: "",
      phone: "",
      companyName: "",
      companyAddress: "",
      companyInstagram: "",
      companyPhone: "",
      companyEmail: "",
      deadline: "",
      budget: "",
      description: "",
      howDidYouFindUs: "",
      acceptTerms: false,
    },
  });

  const { register, handleSubmit, formState: { errors }, watch, setValue, trigger } = form;

  const validateStep = async (step: number) => {
    let fieldsToValidate: (keyof FormData)[] = [];
    switch (step) {
      case 1: fieldsToValidate = ["projectAddress", "projectCity", "projectState"]; break;
      case 2: fieldsToValidate = ["projectType", "hasExistingProject", "estimatedSize"]; break;
      case 3:
        fieldsToValidate = ["clientType", "fullName", "email", "phone"];
        if (watch("clientType") === "construtor") fieldsToValidate.push("companyName");
        break;
      case 4: fieldsToValidate = ["acceptTerms"]; break;
    }
    return await trigger(fieldsToValidate);
  };

  const nextStep = async () => {
    const isValid = await validateStep(currentStep);
    if (isValid && currentStep < 4) setCurrentStep(currentStep + 1);
  };

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    try {
      const fullAddress = `${data.projectAddress}, ${data.projectCity}, ${data.projectState}${data.projectZipCode ? ` ${data.projectZipCode}` : ""}`;
      const allSpaces = getAllSpacesFlat();
      const spacesLabels = (data.requiredSpaces || []).map(id => allSpaces.find(s => s.id === id)?.label).filter(Boolean).join(", ");
      const levelsLabels = (data.projectLevels || []).map(id => PROJECT_LEVELS.find(l => l.id === id)?.label).filter(Boolean).join(", ");
      const daraServicesLabels = (data.selectedDaraServices || []).map(id => {
        for (const category of Object.values(DARA_SERVICES)) {
          const service = category.services.find(s => s.id === id);
          if (service) return service.label;
        }
        return null;
      }).filter(Boolean).join(", ");

      const description = `
CLIENT TYPE: ${data.clientType}
PROJECT TYPE: ${data.projectType}${data.otherProjectType ? ` - ${data.otherProjectType}` : ""}
HAS EXISTING PLANS: ${data.hasExistingProject === "yes" ? "Yes" : "No"}
HAS ENGINEER: ${data.hasEngineer === "yes" ? "Yes" : data.hasEngineer === "no" ? "Needs referral" : "Not specified"}
BUILDING STATUS: ${data.buildingStatus || "Not specified"}

--- PROJECT SIZE & LEVELS ---
EXISTING AREA: ${data.existingArea || "N/A"} sq ft
PROPOSED AREA: ${data.estimatedSize || "Not specified"} sq ft
PROJECT LEVELS: ${levelsLabels || "Not specified"}

--- PROGRAM OF REQUIREMENTS ---
${spacesLabels ? `REQUIRED SPACES: ${spacesLabels}` : "No spaces selected"}
${data.otherSpace ? `OTHER SPACES: ${data.otherSpace}` : ""}

--- REFERENCES ---
${data.referenceNotes ? `NOTES: ${data.referenceNotes}` : ""}
${data.referenceLinks ? `LINKS: ${data.referenceLinks}` : ""}

--- DARA SERVICES SELECTED ---
${daraServicesLabels || "None selected"}

--- TIMELINE & BUDGET ---
DESIRED DEADLINE: ${data.deadline || "Not specified"}
ESTIMATED BUDGET: ${data.budget || "Not specified"}
HOW FOUND US: ${data.howDidYouFindUs || "Not specified"}

--- COMPANY INFORMATION ---
COMPANY NAME: ${data.companyName || "N/A"}
COMPANY ADDRESS: ${data.companyAddress || "N/A"}
COMPANY INSTAGRAM: ${data.companyInstagram || "N/A"}
COMPANY PHONE: ${data.companyPhone || "N/A"}
COMPANY EMAIL: ${data.companyEmail || "N/A"}

--- ADDITIONAL NOTES ---
${data.description || "No additional notes"}
      `.trim();

      const { error } = await supabase.from("quote_requests").insert({
        full_name: data.fullName,
        email: data.email,
        phone: data.phone,
        company_name: data.companyName || null,
        service_type: "technical_drafting",
        project_address: fullAddress,
        description: description,
      });

      if (error) throw error;

      navigate("/thank-you", {
        state: {
          projectAddress: fullAddress,
          projectName: `${data.fullName} – ${fullAddress}`,
          email: data.email,
        },
      });
    } catch (error) {
      console.error("Error submitting quote request:", error);
      toast.error("Error submitting request. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const progress = (currentStep / 4) * 100;

  return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-2">
              {t("quote.title")}
            </h1>
            <p className="text-muted-foreground">
              {t("quote.subtitle")}
            </p>
          </div>

          {/* Progress Steps */}
          <div className="mb-8">
            <Progress value={progress} className="h-2 mb-4" />
            <div className="flex justify-between">
              {STEPS.map((step, index) => {
                const Icon = STEP_ICONS[index];
                const isActive = currentStep === step.id;
                const isCompleted = currentStep > step.id;
                return (
                  <div key={step.id} className={`flex flex-col items-center gap-1 ${isActive ? "text-primary" : isCompleted ? "text-primary/70" : "text-muted-foreground"}`}>
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${isActive ? "border-primary bg-primary text-primary-foreground" : isCompleted ? "border-primary bg-primary/20 text-primary" : "border-muted-foreground/30 bg-background"}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-medium hidden sm:block">{step.title}</span>
                  </div>
                );
              })}
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>{STEPS[currentStep - 1].title}</CardTitle>
              <CardDescription>
                {currentStep === 1 && t("quote.locationDesc")}
                {currentStep === 2 && t("quote.projectDesc")}
                {currentStep === 3 && t("quote.clientDesc")}
                {currentStep === 4 && t("quote.detailsDesc")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                {currentStep === 1 && <StepLocation register={register} errors={errors} />}
                {currentStep === 2 && <StepProject register={register} errors={errors} watch={watch} setValue={setValue} />}
                {currentStep === 3 && <StepClientInfo register={register} errors={errors} watch={watch} setValue={setValue} />}
                {currentStep === 4 && <StepDetails register={register} errors={errors} watch={watch} setValue={setValue} />}

                <div className="flex justify-between pt-4">
                  <Button type="button" variant="outline" onClick={prevStep} disabled={currentStep === 1}>
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    {t("quote.back")}
                  </Button>
                  {currentStep < 4 ? (
                    <Button type="button" onClick={nextStep}>
                      {t("quote.next")}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  ) : (
                    <Button type="submit" disabled={isSubmitting}>
                      {isSubmitting ? t("quote.submitting") : (
                        <>{t("quote.submit")}<Send className="w-4 h-4 ml-2" /></>
                      )}
                    </Button>
                  )}
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </PublicLayout>
  );
};

export default Orcamento;
