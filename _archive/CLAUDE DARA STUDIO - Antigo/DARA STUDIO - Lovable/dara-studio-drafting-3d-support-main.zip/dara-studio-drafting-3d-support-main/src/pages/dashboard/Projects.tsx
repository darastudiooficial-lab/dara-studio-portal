import { Card, CardContent } from "@/components/ui/card";
import { Construction } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";

const Projects = () => {
  const { t } = useLanguage();
  return (
    <div className="p-6">
      <h1 className="text-2xl font-serif font-bold text-foreground mb-2">{t("dashboard.myProjects")}</h1>
      <p className="text-muted-foreground mb-6">{t("dashboard.viewManageProjects")}</p>
      <Card className="border-dashed">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Construction className="h-12 w-12 text-muted-foreground/50 mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">{t("dashboard.comingSoon")}</h3>
          <p className="text-muted-foreground text-center">{t("dashboard.comingSoonDesc")}</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default Projects;
