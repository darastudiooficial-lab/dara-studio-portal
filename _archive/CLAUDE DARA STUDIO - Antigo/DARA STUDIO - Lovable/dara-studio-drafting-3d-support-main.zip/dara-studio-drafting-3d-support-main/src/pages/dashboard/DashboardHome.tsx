import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/hooks/useLanguage";
import ProjectCard from "@/components/dashboard/ProjectCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { FolderOpen, FileText, MessageSquare, Plus, AlertCircle } from "lucide-react";

interface Project {
  id: string;
  name: string;
  address: string | null;
  status: "pending" | "in_progress" | "under_review" | "completed" | "cancelled";
  service_type: string;
}

interface DashboardStats {
  projectsCount: number;
  quotesCount: number;
  messagesCount: number;
}

const DashboardHome = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [projects, setProjects] = useState<Project[]>([]);
  const [stats, setStats] = useState<DashboardStats>({ projectsCount: 0, quotesCount: 0, messagesCount: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDashboardData = async () => {
      if (!user) return;
      try {
        setLoading(true);
        setError(null);
        const { data: profile, error: profileError } = await supabase.from("profiles").select("company_id").eq("id", user.id).single();
        if (profileError || !profile?.company_id) {
          setProjects([]);
          setStats({ projectsCount: 0, quotesCount: 0, messagesCount: 0 });
          setLoading(false);
          return;
        }
        const { data: projectsData, error: projectsError } = await supabase.from("projects").select("*").eq("company_id", profile.company_id).order("created_at", { ascending: false });
        if (projectsError) throw projectsError;
        setProjects(projectsData || []);
        const { count: quotesCount } = await supabase.from("quotes").select("*", { count: "exact", head: true }).eq("company_id", profile.company_id);
        let messagesCount = 0;
        if (projectsData && projectsData.length > 0) {
          const projectIds = projectsData.map((p) => p.id);
          const { count } = await supabase.from("messages").select("*", { count: "exact", head: true }).in("project_id", projectIds);
          messagesCount = count || 0;
        }
        setStats({ projectsCount: projectsData?.length || 0, quotesCount: quotesCount || 0, messagesCount });
      } catch (err) {
        console.error("Error fetching dashboard data:", err);
        setError("Failed to load dashboard data");
      } finally {
        setLoading(false);
      }
    };
    fetchDashboardData();
  }, [user]);

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (<Skeleton key={i} className="h-24" />))}
        </div>
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (<Skeleton key={i} className="h-48" />))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-xl font-serif font-semibold text-foreground">{t("dashboard.welcomeBack")}, {user?.user_metadata?.full_name?.split(" ")[0] || "Client"}!</h1>
          <p className="text-sm text-muted-foreground">{t("dashboard.overview")}</p>
        </div>
        <Button asChild>
          <Link to="/dashboard/new-quote">
            <Plus className="mr-2 h-4 w-4" />
            {t("dashboard.newQuoteRequest")}
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t("dashboard.activeProjects")}</CardTitle>
            <FolderOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold">{stats.projectsCount}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t("dashboard.quotesInvoices")}</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold">{stats.quotesCount}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t("dashboard.messages")}</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold">{stats.messagesCount}</div></CardContent>
        </Card>
      </div>

      {error && (
        <Card className="border-destructive">
          <CardContent className="flex items-center gap-2 p-4 text-destructive">
            <AlertCircle className="h-4 w-4" /><span>{error}</span>
          </CardContent>
        </Card>
      )}

      <div>
        <h2 className="text-xl font-semibold text-foreground mb-4">{t("dashboard.yourProjects")}</h2>
        {projects.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <FolderOpen className="h-12 w-12 text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">{t("dashboard.noProjects")}</h3>
              <p className="text-muted-foreground text-center mb-4">{t("dashboard.noProjectsDesc")}</p>
              <Button asChild>
                <Link to="/dashboard/new-quote">
                  <Plus className="mr-2 h-4 w-4" />{t("dashboard.requestQuote")}
                </Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {projects.map((project) => (
              <ProjectCard key={project.id} id={project.id} name={project.name} address={project.address || "No address"} status={project.status} serviceType={project.service_type} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default DashboardHome;
