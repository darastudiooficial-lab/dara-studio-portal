import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useLanguage } from "@/hooks/useLanguage";

const PROJECT_STAGES = [
  "Lead", "Budget Sent", "Budget Approved",
  "Waiting Payment", "In Progress", "Preview Sent", "Revision",
  "Final Review", "Completed", "On Hold", "Cancelled", "Delayed",
];

const STAGE_COLORS: Record<string, string> = {
  "Lead": "bg-muted-foreground",
  "Budget Sent": "bg-chart-4",
  "Budget Approved": "bg-chart-2",
  "Waiting Payment": "bg-chart-3",
  "In Progress": "bg-chart-2",
  "Preview Sent": "bg-chart-4",
  "Revision": "bg-chart-5",
  "Final Review": "bg-primary",
  "Completed": "bg-chart-2",
  "On Hold": "bg-muted-foreground",
  "Cancelled": "bg-muted-foreground",
  "Delayed": "bg-destructive",
};

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t } = useLanguage();
  const [projects, setProjects] = useState<any[]>([]);
  const [companies, setCompanies] = useState<any[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      const [projRes, compRes] = await Promise.all([
        supabase.from("projects").select("id, stage, company_id, companies(name)"),
        supabase.from("companies").select("id, name"),
      ]);
      setProjects(projRes.data || []);
      setCompanies(compRes.data || []);
    };
    fetchData();
  }, []);

  // Group projects by stage
  const stageGroups: Record<string, any[]> = {};
  projects.forEach(p => {
    const stage = p.stage || "Lead";
    if (!stageGroups[stage]) stageGroups[stage] = [];
    stageGroups[stage].push(p);
  });

  // Group projects by company for workload view
  const companyGroups: Record<string, { name: string; projects: any[] }> = {};
  projects.forEach(p => {
    const cid = p.company_id;
    const cname = p.companies?.name || t("admin.noCompany");
    if (!companyGroups[cid]) companyGroups[cid] = { name: cname, projects: [] };
    companyGroups[cid].projects.push(p);
  });

  const totalProjects = projects.length;
  const completedCount = stageGroups["Completed"]?.length || 0;
  const activeStages = ["In Progress", "Preview Sent", "Revision", "Final Review"];
  const activeCount = activeStages.reduce((sum, s) => sum + (stageGroups[s]?.length || 0), 0);

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-foreground">{t("admin.welcome")}, {user?.user_metadata?.full_name?.split(" ")[0] || "Admin"}!</h1>
        <p className="text-sm text-muted-foreground">{t("admin.studioOverview")}</p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate("/adm/projects")}>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">{t("admin.totalProjects")}</p>
            <p className="text-3xl font-bold text-foreground">{totalProjects}</p>
          </CardContent>
        </Card>
        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate("/adm/projects")}>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">{t("admin.activeProjects")}</p>
            <p className="text-3xl font-bold text-chart-2">{activeCount}</p>
          </CardContent>
        </Card>
        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate("/adm/projects")}>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">{t("admin.completedProjects")}</p>
            <p className="text-3xl font-bold text-primary">{completedCount}</p>
          </CardContent>
        </Card>
      </div>

      {/* Workload by Company (ClickUp-style boxes) */}
      <div>
        <h2 className="text-lg font-semibold text-foreground mb-4">{t("admin.workloadByCompany")}</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Object.entries(companyGroups).map(([cid, group]) => {
            const done = group.projects.filter(p => p.stage === "Completed").length;
            const notDone = group.projects.length - done;
            const pct = group.projects.length > 0 ? Math.round((done / group.projects.length) * 100) : 0;

            // Count by stage
            const stageCounts: Record<string, number> = {};
            group.projects.forEach(p => {
              const s = p.stage || "Lead";
              stageCounts[s] = (stageCounts[s] || 0) + 1;
            });

            return (
              <Card key={cid} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate("/adm/projects")}>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-semibold text-foreground flex items-center justify-between">
                    <span className="truncate">{group.name}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <div>
                      <span className="text-muted-foreground">{notDone}</span>
                      <span className="text-xs text-muted-foreground ml-1">{t("admin.notDone")}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">{done}</span>
                      <span className="text-xs text-muted-foreground ml-1">{t("admin.done")}</span>
                    </div>
                    <div className="relative w-10 h-10">
                      <svg viewBox="0 0 36 36" className="w-10 h-10">
                        <path
                          d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                          fill="none"
                          stroke="hsl(var(--muted))"
                          strokeWidth="3"
                        />
                        <path
                          d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                          fill="none"
                          stroke="hsl(var(--chart-2))"
                          strokeWidth="3"
                          strokeDasharray={`${pct}, 100`}
                        />
                      </svg>
                      <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-foreground">
                        {pct}%
                      </span>
                    </div>
                  </div>
                  <Progress value={pct} className="h-1.5" />
                  <div className="space-y-1">
                    {Object.entries(stageCounts).map(([stage, count]) => (
                      <div key={stage} className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span className={`w-2 h-2 rounded-sm flex-shrink-0 ${STAGE_COLORS[stage] || "bg-muted-foreground"}`} />
                        <span className="uppercase">{stage}</span>
                        <span className="ml-auto font-medium text-foreground">({count})</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
          {Object.keys(companyGroups).length === 0 && (
            <Card className="col-span-full">
              <CardContent className="py-8 text-center text-muted-foreground">
                {t("admin.noProjects")}
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Projects grouped by stage (task board style) */}
      <div>
        <h2 className="text-lg font-semibold text-foreground mb-4">{t("admin.projectsByStage")}</h2>
        <div className="space-y-3">
          {PROJECT_STAGES.filter(s => (stageGroups[s]?.length || 0) > 0).map(stage => {
            const items = stageGroups[stage] || [];
            const color = STAGE_COLORS[stage] || "bg-muted-foreground";
            return (
              <div key={stage} className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card">
                <span className={`w-3 h-3 rounded-full flex-shrink-0 ${color}`} />
                <span className="text-sm font-semibold text-foreground uppercase min-w-[140px]">{stage}</span>
                <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">{items.length} {items.length === 1 ? "task" : "tasks"}</span>
                <div className="flex-1 flex flex-wrap gap-1 ml-4">
                  {items.slice(0, 8).map(p => (
                    <span key={p.id} className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded">
                      {p.companies?.name || "—"}
                    </span>
                  ))}
                  {items.length > 8 && <span className="text-xs text-muted-foreground">+{items.length - 8}</span>}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
